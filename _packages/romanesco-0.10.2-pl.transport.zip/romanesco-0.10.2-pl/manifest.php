<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.10.3

New features:
- Add ContentBlock for creating previous / next page navigation
- Add ContentBlock for creating a button group
- Add option to show an icon inside a button

Fixes and improvements:
- Responsive images through srcset and picture attributes
- Apply dividing options to Overview grids too

---

## Romanesco 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f5974acba975df2442ed0f47320a3f8d',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/94935fc244de11f35710cc3d30e1094c.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4370790bb4d429cdbf0cc5d9935481f1',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/0ca9941ee6c6e662ca6e7d4ff648a81a.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8710a308963432a803e4ac65facb26e',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/1eeff286ce1b64fdcb8f28c253c5ae55.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45801617b49814113985adfe40269967',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/1d17990752049c4bdc8e3c3f6e417afc.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '887165c705a60e2be16bf4d6b39abc27',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/a647f3f04fa671d1fa15852d826847bb.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aecd8315ea52889c6cc83af282cf7923',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/48131e9f39af26cd416fe3b10f629469.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e689df0d47c728ccff95655d249a845',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/7176b1f7e7d333a83e593800864280d2.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64232a1f8e7667705aa669d2def70c69',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/3882115f4f97e7433aa843acb5cb36ae.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ecf0841f1615d6721df94d74c938b55',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/0d8bce77967420836af3f3449cb74f6c.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760c8801cdf4e545ce837017d92ac7fb',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/6e7a9424c81a73e451f2f1a20f26a6e0.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1cc3e90dc2ac9ffc40c755a2f252c79',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/2550e5eaf85b0095ef75f864d088cdf1.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a9eef3092574cfe037de4068e3dc905',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/f767122a42f2330b4abbc4d461d95763.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52fac5cc03f051098a028769b043ce4',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/cf2ed3c5f4c3c971b2a3bf6e5075b13c.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c97ffb05b8f54f0ddb8fc73957f99208',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/fe61e641f1f49183169ba4e5f50e9342.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4189273f76116b7df2931e01998f6ac0',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/5f177ef4e474887438746c811216dd18.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa48194ab65fbdb7e01bbfa8216c6207',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/34182807ffeb83e49db89d951b3e31b9.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66fe1ad3a4551403c274e89aa31977a0',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/f401b20242f1f4878955e74d0cd2f7ff.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93631994e3545b8105af980179f219e6',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/f8ac946ecab8754d1dd3669d215c72bc.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6a26ae0217ac84e10f2569319c29e9c',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/9ebb49663eb53ced629ec1e404014e72.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1568b0e76e3fb3a00f8ad57f9e6e3edd',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/6fe478eef4531aa66ef721d18a9b0fbd.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7eb57d0b03a6a8fefcc9aee4942544b',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/f22efaee70126eae4ac21be85e46cc6b.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8621c823af5697d3cb4a85bed80e2157',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/35215cb893a0d8c7f1d1551629e5f1ec.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a975d891aab4fe0361c55f803ca189',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/9b8626782f2fcea71f4e26183c161bf2.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f825a804ed45abae895a4fa185e5360d',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/fc27da901ab9e863a977274e162d58a5.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a72cb142d4df0658bb32745f75ee7f7',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/a00e863a1a7b5a2029d7dae0ab9db962.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e98d49b787c2ee66bcd84dcb0d3b6f0',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/614e3c932b7b3b3c166d67e3a6df14a8.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a3cfe844cfa0848484abf11ef44f69f',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/8c50338f3d0bd601929f38d795adc2df.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5435c4dac0fe21dbead8f8057ce7918b',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/68091430f7163d35de19b2685ed46fd8.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9bb1624e3458760090204af6bf01793',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/666f152f11ebc2d40dee22002691c6c3.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '415f2bda41df7ebb7ac82afa2d6977cc',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/a882ce225b40d15d5bb489acbc0a363c.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40a3efd22a696d3c60aebf8da18650f0',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/fad10f9c6a09a02c191f58ea6154d368.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f6eb97a673bde13af90a104e7246dc0',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/bad0d4aa7d62974f73e5bb34f8d2e84f.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fc1ecdcc5f1ffde71334f3ad37e7e60',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/505065f488d6478289d2ba5ff915c99b.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2222a77f2a3f05bc7294cd039fb8f30b',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/2fbf0036798850ca8aa2d0e1f1e3773e.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaaf0bbf1ef3f658711e8b34f94e160c',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/830200439e75d77b63820fcfcc155da3.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3bfbc10a178d339d3c6f820f2f63dac',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/876135e2d8fc42808f9fea912b5fc28b.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c08eaec246a952fd4cce05b1c2d292ee',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/9420c97d6af209e3522c417762d2aefe.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aa95f594720cc01f8e1de468bc8d0d65',
      'native_key' => NULL,
      'filename' => 'modCategory/bffaa832354379b67fe57aa925d1b336.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);