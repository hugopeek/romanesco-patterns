<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '095239332b197249bc849285a451b370',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/ea286cd91669a7dc6ec23d6c009724f7.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '133ad893a57afd730273007a42285b26',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/97008e856b62fab63d2cd3e44d857aa7.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '509c861d05d66a67825c63af56f2984b',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/bd1239e2750634c72ce521affadce78a.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c0599adcbe1331b7613c2ef78ea4136',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/b122bd32109673284d7d2d6bdbc12072.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eee2d316ae1c97386082327a6aae1313',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/97fffd7b8c754d7cf1c5e1b24091c55a.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec4ac3eee014d7182a75d74349c4853a',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/5bcbc98b99fe0f76d36b4ab7187694d9.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2738880cc7ceb628c04b27fd08701a67',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/b709bde6099017c59e977742161f983d.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f420bcfdc35e6c488d6d43840cffe40c',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/fb635453485f0cd672f8462393afecc0.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bba477ea5832fa4e7fb83a04b787bc5',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/7aac25020eb949057b54c52375487511.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bec4282cc189c4df8a386cdfcce6f24',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/c9d3ed98e9d40ae189d4cdda6dab589e.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c30198a93840bce2854797989a43ec2e',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/77d590113d8190ceccdfc7ca8d9ca49e.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3817ff86b2f7baa56c682ca03fbdaf34',
      'native_key' => NULL,
      'filename' => 'modCategory/1c078abc59ef73b5a40fdf2c6db80040.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);