<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.14.7
Released on December 17, 2019

New features:
- Add Date and Date Range fields to FormBlocks

Fixes and improvements:
- Fix special characters breaking FB option labels
- Optimize FormBlocks validation processing
- Improve inheritance of FormBlocks label position settings
- Load home breadcrumb with tpl chunk
- Fix structured data errors in breadcrumbs
- Fix illegal regex sequences

## Romanesco Patterns 0.14.6
Released on November 19, 2019

New features:
- Add jsonGetObject snippet for templating JSON output with chunks
- Add ability to center content when stacked on mobile or tablet
- Add circular button option
- Add circular and bordered image options

Fixes and improvements:
- Refactor Global Backgrounds component
- Add ability to search for multiple instances of key in jsonGetValue
- Fix fallback icon in avatar when an article has no author
- Fix memory exhausted issues when rebuilding content with ContentBlocks
- Fix visibility toggles in front-end pattern library
- Limit reverse column order setting to mobile only
- Rename InjectInvertedClasses plugin to ManipulateDOM
- Rename MarkdownMimeType plugin to ProcessMarkdown
- Remove rows from grids that have a reversed column order on mobile
- Remove .md extension from Markdown links and turn them into button if desired
- Add language class to Markdown code blocks that do not specify a language
- Turn Markdown tables into Semantic UI tables

## Romanesco Patterns 0.14.5
Released on October 12, 2019

Hotfix: forward missing prefix to setBoxTypeTheme snippet

## Romanesco Patterns 0.14.4
Released on October 10, 2019

New features:
- Integrate visual regression tests (with BackstopJS)
- Add snippet for creating static HTML file of resource
- Add responsive options to main layouts and overviews

Fixes and improvements:
- Fix incorrect syntax in Google webfont requests
- Define exact aspect ratio for Overview images
- Add inverted class to logo in vertical menu
- Fix image URLs and display size in Markdown output
- Mute rogue path output in manager for Redactor too
- Remove http:// in Youtube embed placeholder URL
- Update resourceTVInputOptions to respect possible context settings
- Fix broken avatar image in compact article overviews
- Fix incorrect path in CSS to global backgrounds SVG
- Correctly retrieve (possible) context setting for FormBlocks container ID
- Correctly retrieve (possible) context setting for CB and TV options
- Load full off-canvas navigation if main menu is not a dropdown menu

## Romanesco Patterns 0.14.3
Released on July 16, 2019

New features:
- Allow credits to be added to an image or icon
- Add Free variant to Overview images (no fixed aspect ratio)
- Add Commento as commenting option

Fixes and improvements:
- Isolate content images and increase the distance from element below
- Show top level parent in vertical sub navigation
- Add alignment option to all Overview CBs
- Add text_size, show_subtitle and show_rating options to Testimonial overviews
- Make overviewRowImageBasic template more basic
- Improve sorting in Overviews (reverse sort direction, alphabetic sort order)
- Add basic icon chunk
- Add tertiary button style (Fomantic UI feature)
- Add option to place button on new line
- Fix issue with rogue 0 output from getImageDimensions breaking SUI build
- Fix quirk where TVs couldn\'t be rendered in layouts anymore
- Prevent leaking of data from srcset placeholder in overview images
- Allow theme additions to global backgrounds
- Return after a setBoxType override was found
- Lower minimum width for all image TVs
- Apply img_quality configuration setting to all images
- Only load certain assets (CSS/JS) when they are needed
- Small caching optimizations in Overview templates
- Rename and refactor Knowledge Base into Notes
- Tickets integration is now deprecated


## Romanesco Patterns 0.14.2
Released on April 15, 2019

Fixes and improvements:
- Prevent MIGXdb fields with default value of NULL from being set to 0
- Allow otherwise duplicate TV category names to be prefixed with _ in projects
- Add option to embed Google Analytics with gtag.js
- Add option to embed Matomo Analytics
- Fix not being able to set image type in Publication and Portfolio overviews
- Fix binary download types (such as PDFs) not having content
- Fix Global Backgrounds TV not loading its MIGX config from file
- Use nvm-exec to run Gulp from PHP (prevents gulp not found errors)
- Add fullname parameter to Registration template
- Point to correct math validator in Registration template
- Add empty error message div to forms (for SUI front-end validation)
- Allow recipient email TV to be empty in forms (i.e. when using a custom hook)
- Fix inheritance of form label layout settings
- Add label to honeypot fields
- Only load Youtube videos after play button is clicked


## Romanesco Patterns 0.14.1
Released on February 10, 2019

New features:
- Add TV input option for selecting Fibonacci numbers
- Add math question anti-spam option to forms
- Load Semantic UI styles inside CB preview containers

Fixes and improvements:
- Rearrange snippet folders and import a few new ones from projects
- Fix Overview headings displayed as regular links being too large
- Fix Registration template not validating password correctly
- Exclude resources with unchecked "Use alias in URI" from breadcrumbs
- Make icons work inside CB chunk previews
- Make check for detecting SeoTab plugin watertight


## Romanesco Patterns 0.14.0
Released on January 18, 2019

New features:
- Add main navigation with dropdown submenus
- Add template with Table of Contents menu (instead of submenu)
- Add template for Downloads
- Add Kanban layout for Content Purpose elements

Fixes and improvements:
- Update status grid to incorporate new / altered TV values
- Add optional anti-spam hook to forms
- Add option to select background for rich text segments too


## Romanesco Patterns 0.13.0
Released on November 15, 2018

New features:
- Add content purpose TVs
- Add TVs for external links, file attachments and related content
- Add ability to create input options
- Add ability to create crosslinks between resources
- Add re-purpose component, for creating content "flows" inside a central topic
- Add after save hooks for MIGXdb configs
- Add JSON import for input options

Fixes and improvements:
- Add chunk for dynamically generating TV input options from database rows
- Load project timeline through Backyard package and store data in db
- Rearrange TV categories and add rank
- Replace Grunt task for generating GPM config with PHP script
- Make tvToJSON output suitable for use in GPM configs
- Disable CSS background images for Tiled overviews
- Fix sidebar not showing on largest screen on Team and Client pages
- Fix link in Instagram social button


## Romanesco Patterns 0.12.3
Released on October 4, 2018

New features:
- Add OpenGraph metadata to head
- Add snippet for clipping characters from start or end of string
- Add plugin for injecting inverted classes into content (requires HtmlPageDom)
- Add options for controlling footer and bottom CTA content

Fixes and improvements:
- Include homepage in basic template list, so they also have Overview TVs
- Fix author image in compact article overview template
- Disable Disqus comment count in overviews (was acting buggy)
- Prevent decimals in calculated image dimensions from breaking variables file
- Allow overrides for head and footer chunks in all templates
- Fix issues when using multiple file upload fields in form
- Sort available forms by menuindex in Forms CB


## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)


## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c92669fd855d28921ce0cb9fb6f7fa67',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/e62baa12210031095c1740e2a3b203c1.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b1bb24aba3a6df47782ba6bd7f5dbb8',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/4364c5cd530e47a7b67ec6d25768c35b.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ac6956ec11f45c596f4d4a15e28f4cf',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/696768de10770fe5def4a1644e8e434f.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e21a3723098cef2972c41921d9ee590b',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/8ab4b887284e24449f8682cc110c12cf.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef3e91d9d8c6a0d07de5e555acaecc1a',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/1d702666493c00fde2e3def4dde330b8.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cd920f56fe56a425708299be669c680',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/85c5a6420839c771849ff17c0161e14a.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75967d12391f98ead583aa506b197c1e',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/62147c596d1182c89a95c93671ba4252.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59cb3ddad4e56b4f6e90546a0720d9c6',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/babe6b1a434c7107fd093a42e34c8742.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74cc20364c124d8f826454514b8f5d8',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/b233c21d9cb3238faa1645767415740b.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '530e6bf1167a26f5451cf94e93c705d6',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/f891773a897fef582f039612f4841a88.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a21635a74457c93ac605639bd80dd20',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/944010dc8f44a93253c14ab8091c4b42.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc658d9afa28c814fac9f5656da35d53',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/f325d30ceb1c7ee6c71d0c18c1438dfd.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '251c65a14e3e7d68d60ca3d141315f9b',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/981b6b5021edb93a253d483150ea9cf7.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79522210acfe17dbab7a9c872458490a',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/e2eaf045eeef3cab917e69c00e101c67.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c80f4ec65e43b75d9c1ace25f233fa16',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/8e7f0d62fefc7386b8228ab5ed378296.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db55766b7647ff6d73cfd79d03ac0494',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/d831a370a41a326a1c240bc17f9629a0.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6889b94f21c6cf2cf565385180e0e90',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/379c8ee4ae6c572a161037281f7f6ccd.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '243b15a1d8daf6abecb109ba7dcf694d',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/cc7f20cb2a577b6a3d2b12691e172a16.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '088e8760b92c35f147a6b85b78bfcaf6',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/5671eb5177d4e62e155c704162ba71ae.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f09706a87019a23bf109619d3e8d10e',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/811f91378448a94c6eab3a67c7b789f1.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0154bbefbeedb9466b18b9a00b073819',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/f7d55f458056592748639b046d5f3a04.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1371825379558debe0edd2e85609514',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/8249b3d9500acc98b8ea2f1be23318fa.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ada55e479432ff731f51e1f12c831db',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/985a9033a9a0ca71b2a5cef0c0036d18.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd77e2a9c29b0e9b74ec4c0f3e7d59d40',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/8eefcd2b5c47a3a534ecdcb43683c2ea.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c87e223df4feaf26522ac418fefd47e4',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/e65b233da1fa6fbb784a274fb0d5e922.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afd986cbcb441aa3ae615fd07cd467d0',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/8050a84e14540d4af233b95d4782291f.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0d3c92ef8d33fec96b60df5af2da043',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/ffdda00d0fb5e09747634dd386073b5a.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '925583d9ced423314ff16706bfc96ef6',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/ffdc2fb9269f9683baefef6e0ddf19b6.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8414f91a5b709d7030886d36efa3fa87',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/1e211ffaab8a8b64a7508e13e17e105d.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '531167ab9fd73c89d7c787fe8aa3f87a',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/1c0964fe2d4bef7891c2b665e491edf6.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8416f1cc65e3e8e2b9ef570aa7ef1352',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/ef7aadab0463f2b1eb8cb97e6c3cb8c7.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1033faa959bd1ead36500c445b2e46e4',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/99ca7ff3854fdf8b79fa578d7764cb01.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7b92e4faeee310b44ae51d4d6ab3f89',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/13546b6db3baefff6b8dc47de449a2a0.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93ae8e5a70735eb223daecd537b1d831',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/57cb1fa62182530e448d07f44a1c6b65.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51719f484847563df28ae289bce42f60',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/9935a0821f2b26f7ba0016530e2ba280.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '921dbfcb00c34443469fdc78f5208515',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/05b50e7360f39b5932c81d4ddc534e7f.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5febc8688d39f9ae7ddc5d5d46ccef80',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/188034c268d09bdf92ef4837697880d4.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b3a82c3723390c7264ee55aaf8d3e03',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/3a8ea5086ed660290ec77f7d532fa6a6.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '172bb3105e0f9849b16939daa2a634ea',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/eadf7de6a75de214269ea366f77cfa61.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '647ca71e38d0b1a46b37b9ec444d2083',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/2f21ccbaf01955e22948078729cbb77b.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73b34148d01050dc2339a74afae514cb',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/480efc876f93ca04ca6aa6094e86c421.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1db1366f200d74f35ba1be1688f2c7f1',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/428568917f5eebb39c227cfbe09d78b8.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e027b5c1e2cd741d2fb6821edd75f20',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/454baf1d2ee157e1c7ddd4d2dfe2ae19.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c861bfa9270e2c6d96fd979f3b5aaf4d',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/23e6a53c9d7d031b01a54e3ef1dd2ab6.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1636932331fdfc0deddd1435d94b51d',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/8a30c37268ad3c53d3467febcc1bc2b6.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb60b4baa9ac1a1b7481673566985484',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/96429b618d5f8fee37fcab90efe4fd30.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63988c17c91c0bf35f08f20a4eb10180',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/653a46a282f76db3a081d0a9e419e88f.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9d005cc416c0f4732862f155e449de3',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/7a1546142dcf16155ae32acfdd0cdd95.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43d5be977b14b88e9a93937bcc1c0552',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/0becc92136a8dbb960d4125955d2254c.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fe0927a8574fdc8472c66692311c93f',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/9f674cd8df3e03f4009e02d59aad9eda.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deacb686e9619ae2c5d2063572bf1230',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/d865b1e734fb9de987e3bdcbae7dd576.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '877cc544ebec70998b21ffea8385f829',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/bf1f657fa63e3a0feca85ee87c876876.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c47ced93837b6a86cd82595ebf4c17b',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/f2a7f6842409e051d340ce62e1e9831f.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3bf33ab9632680557e5ed3ea5bb9b32',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/1b25838d26be2fa6b3993ae74cbb81e9.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b0a7c1ddcebc4b9d9b36995cbdba50f',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/77a76594f9fe32d762e10db46b6de606.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '86dddaf186bf0d6f951cfc7a2e50c6d1',
      'native_key' => NULL,
      'filename' => 'modCategory/837318e7f7803639bd97f197f2f29f31.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);