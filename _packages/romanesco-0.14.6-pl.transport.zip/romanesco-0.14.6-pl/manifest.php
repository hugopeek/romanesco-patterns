<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.14.6
Released on November 19, 2019

New features:
- Add jsonGetObject snippet for templating JSON output with chunks
- Add ability to center content when stacked on mobile or tablet
- Add circular button option
- Add circular and bordered image options

Fixes and improvements:
- Refactor Global Backgrounds component
- Add ability to search for multiple instances of key in jsonGetValue
- Fix fallback icon in avatar when an article has no author
- Fix memory exhausted issues when rebuilding content with ContentBlocks
- Fix visibility toggles in front-end pattern library
- Limit reverse column order setting to mobile only
- Rename InjectInvertedClasses plugin to ManipulateDOM
- Rename MarkdownMimeType plugin to ProcessMarkdown
- Remove rows from grids that have a reversed column order on mobile
- Remove .md extension from Markdown links and turn them into button if desired
- Add language class to Markdown code blocks that do not specify a language
- Turn Markdown tables into Semantic UI tables

## Romanesco Patterns 0.14.5
Released on October 12, 2019

Hotfix: forward missing prefix to setBoxTypeTheme snippet

## Romanesco Patterns 0.14.4
Released on October 10, 2019

New features:
- Integrate visual regression tests (with BackstopJS)
- Add snippet for creating static HTML file of resource
- Add responsive options to main layouts and overviews

Fixes and improvements:
- Fix incorrect syntax in Google webfont requests
- Define exact aspect ratio for Overview images
- Add inverted class to logo in vertical menu
- Fix image URLs and display size in Markdown output
- Mute rogue path output in manager for Redactor too
- Remove http:// in Youtube embed placeholder URL
- Update resourceTVInputOptions to respect possible context settings
- Fix broken avatar image in compact article overviews
- Fix incorrect path in CSS to global backgrounds SVG
- Correctly retrieve (possible) context setting for FormBlocks container ID
- Correctly retrieve (possible) context setting for CB and TV options
- Load full off-canvas navigation if main menu is not a dropdown menu

## Romanesco Patterns 0.14.3
Released on July 16, 2019

New features:
- Allow credits to be added to an image or icon
- Add Free variant to Overview images (no fixed aspect ratio)
- Add Commento as commenting option

Fixes and improvements:
- Isolate content images and increase the distance from element below
- Show top level parent in vertical sub navigation
- Add alignment option to all Overview CBs
- Add text_size, show_subtitle and show_rating options to Testimonial overviews
- Make overviewRowImageBasic template more basic
- Improve sorting in Overviews (reverse sort direction, alphabetic sort order)
- Add basic icon chunk
- Add tertiary button style (Fomantic UI feature)
- Add option to place button on new line
- Fix issue with rogue 0 output from getImageDimensions breaking SUI build
- Fix quirk where TVs couldn\'t be rendered in layouts anymore
- Prevent leaking of data from srcset placeholder in overview images
- Allow theme additions to global backgrounds
- Return after a setBoxType override was found
- Lower minimum width for all image TVs
- Apply img_quality configuration setting to all images
- Only load certain assets (CSS/JS) when they are needed
- Small caching optimizations in Overview templates
- Rename and refactor Knowledge Base into Notes
- Tickets integration is now deprecated


## Romanesco Patterns 0.14.2
Released on April 15, 2019

Fixes and improvements:
- Prevent MIGXdb fields with default value of NULL from being set to 0
- Allow otherwise duplicate TV category names to be prefixed with _ in projects
- Add option to embed Google Analytics with gtag.js
- Add option to embed Matomo Analytics
- Fix not being able to set image type in Publication and Portfolio overviews
- Fix binary download types (such as PDFs) not having content
- Fix Global Backgrounds TV not loading its MIGX config from file
- Use nvm-exec to run Gulp from PHP (prevents gulp not found errors)
- Add fullname parameter to Registration template
- Point to correct math validator in Registration template
- Add empty error message div to forms (for SUI front-end validation)
- Allow recipient email TV to be empty in forms (i.e. when using a custom hook)
- Fix inheritance of form label layout settings
- Add label to honeypot fields
- Only load Youtube videos after play button is clicked


## Romanesco Patterns 0.14.1
Released on February 10, 2019

New features:
- Add TV input option for selecting Fibonacci numbers
- Add math question anti-spam option to forms
- Load Semantic UI styles inside CB preview containers

Fixes and improvements:
- Rearrange snippet folders and import a few new ones from projects
- Fix Overview headings displayed as regular links being too large
- Fix Registration template not validating password correctly
- Exclude resources with unchecked "Use alias in URI" from breadcrumbs
- Make icons work inside CB chunk previews
- Make check for detecting SeoTab plugin watertight


## Romanesco Patterns 0.14.0
Released on January 18, 2019

New features:
- Add main navigation with dropdown submenus
- Add template with Table of Contents menu (instead of submenu)
- Add template for Downloads
- Add Kanban layout for Content Purpose elements

Fixes and improvements:
- Update status grid to incorporate new / altered TV values
- Add optional anti-spam hook to forms
- Add option to select background for rich text segments too


## Romanesco Patterns 0.13.0
Released on November 15, 2018

New features:
- Add content purpose TVs
- Add TVs for external links, file attachments and related content
- Add ability to create input options
- Add ability to create crosslinks between resources
- Add re-purpose component, for creating content "flows" inside a central topic
- Add after save hooks for MIGXdb configs
- Add JSON import for input options

Fixes and improvements:
- Add chunk for dynamically generating TV input options from database rows
- Load project timeline through Backyard package and store data in db
- Rearrange TV categories and add rank
- Replace Grunt task for generating GPM config with PHP script
- Make tvToJSON output suitable for use in GPM configs
- Disable CSS background images for Tiled overviews
- Fix sidebar not showing on largest screen on Team and Client pages
- Fix link in Instagram social button


## Romanesco Patterns 0.12.3
Released on October 4, 2018

New features:
- Add OpenGraph metadata to head
- Add snippet for clipping characters from start or end of string
- Add plugin for injecting inverted classes into content (requires HtmlPageDom)
- Add options for controlling footer and bottom CTA content

Fixes and improvements:
- Include homepage in basic template list, so they also have Overview TVs
- Fix author image in compact article overview template
- Disable Disqus comment count in overviews (was acting buggy)
- Prevent decimals in calculated image dimensions from breaking variables file
- Allow overrides for head and footer chunks in all templates
- Fix issues when using multiple file upload fields in form
- Sort available forms by menuindex in Forms CB


## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)


## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1df6db551d93ad04a926bec4c06dca6d',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/894b0f02a7470150a14da387ee84ecf2.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c33c0f5580c66df5e3bb1f188210809',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/09319d90224fc542062055a17328035d.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05a7839d3821fbd1e338e8c1741da458',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/0ff5a1029667f93e3da53608d22602a4.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b59cf0cbd519047c45426ed6fd2d15e1',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/2c49acd33a97cc4f980829c276425c94.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e880b20e4e72526ced9013745a803e3',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/55d5f214e95e749be1856674c5805e8b.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5974516b1b88a645c8e2163aeceece6f',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/a1b8f3f67d69c4d4345d42d7913f3360.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ac61004d377e77d145fb853a524a4f2',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/b491ad3105b89ac17ea41f29ce0e1aac.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bbe611f861130ccb8de3bac229498b7',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/2349c19c38c37083492c42cfedb9fc2b.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bd30792ebbbe77d9c0911ce33304dbd',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/8e44f00e96c91acbc7013df98d8773d1.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b7a4473bb8df306999169e10e4ec8b3',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/f236b268f893304b86b121528b8bde39.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0ec0564d10edba7f7b7b9d4b1cb976a',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/ec54cecdea5677c6ceeaf186832c2074.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aab8ee304abecd1975bbd8d7fb0dbd7c',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/52288326a75520603414638a46ccf5aa.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '682b80cbd4e2bbd61d787a44457091ea',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/c74f8e6585a542ae3242822045f5f66f.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c57e15423ca94f26d7e5560270987931',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/7096f8f1caff26c930184b5af9a77b67.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1660de20d4d7c068c6bbdfea3a4d917',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/e0d1bb889649891cb68f63382b04ec67.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34b68a3346f020fee57c86c13465498b',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/e1501017a3198685b1f06ad2c7e9163c.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b7d27c4bcc5e78b5a63f379417c05f7',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/224e71f600f61f9d4b8d02922acdd87d.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4a54d59b7ee9d8e3f2851302b9e2ba2',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/6ef5aa89ad868092988681d435a0ddae.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '918dc62a1868d363070a618c7b3d1f2e',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/2e3805a95f39e982495cda2d86dbe2a5.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0313be756fd3217ce7c85c16b06ef29c',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/212888be676f1328c9aad690c9c10702.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eda2549f1b720deb6392fb768eba002',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/d21f56d5e5a97d87529dde0b6c7b9aff.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '403fd129398814bbd91bbeb28f4e8e0e',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/4c3fbeb08c1ae79bf8f659b15652a5d4.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '590d34050e5d47e9688442f156c9fc13',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/a4110aea3e0acfebb4d304351e2cae4a.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09e3c60a665b8a9bcbb07c77e692f921',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/3429777a848aeecce242d7ca0061ed40.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c304e4ff39b01fbe3c283d37a304d70',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/f076bba689f24f2e51848896cb4d7ad6.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff88f6c83a8adea1872845498638eb8',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/93855877c558ecebd58a02b49892966c.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d20a56db14da74970fbed3049dda936',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/84c4083ae88fea63bb492a1f97a6023c.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4043622370cf586eb69c641797f93c28',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/b96a16140ade1653e25805b06ba3f393.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3affc71c170e10a62e91360d644bf43f',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/be19b2523d992d8cdb0d35faba64aeac.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0942c3269a2ad12f530fb1566c7bfa0',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/1ca1a364c4992541b70dc54cdf6f6a12.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e271a6f7aa6c731438ccb9d2724cf1d',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/2d8d3ae46fbc8d984d089f1d12860de2.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '693b8a07a3fda2dcf029df89ef921ae1',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/e82f9c40278d6fdf46e98162555cd175.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4a455f43488fdbfd178383d7b697bb4',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/d1b8860bc78913efd5be8ea9675c4f70.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6a0e495a24d241ad6a587f8e6b38bd5',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/34436acc23660d53601dd824a2b914b6.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '002762fffd374d32b507a9055921e0f7',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/09b5dca30f25c4ed34bbb4c2d0b3dd12.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe70a05bcd4e32082fd5eb61a967aaa',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/09326010369dc6d1951b626b90542fbb.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d452d55a0c781473528d6b19795ad5a',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/3c47e354cbb59918d529e9d425028683.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aa4603ea899bc8de74e3c7cbf7b200a',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/2469929cf215557a2b4a5e986db6f652.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e69073501d340f23b92bda68f4909d74',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/8f72bdf045c3fb5bc1753fd4347f7dec.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eb6f94231c53016cf31b730699dc170',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/ec7054dbf378b368a531a79cdacf688a.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8072770a3f7dbf7adfb349257b656400',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/090219834e96cb2dfd0f34bcce3b8ada.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52a028f5c56e6a41755f342bf05a3a3',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/9a2739aadc040982b00e87fb8241a230.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcbe6c8fecd26f1a908755fac9fe03de',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/479adb85285cb262586624f9b4f82dbf.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57b9d06145fc811fd1406e87c6a37f48',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/c180d3a9f90b58bf3db7ad350ccda047.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df88f1ac02161bf464bd15cc5def06c9',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/b38731f205274d13dba410edde72117c.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c167292b0beac21f90fe65c9070935eb',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/df5fbb35a1c53d7a91918f6fa3e552d3.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e90200d6603e767b843651209214ef7a',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/4733605036fc49ee7910f4a26a7eb2b9.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d2b2049befe817cf31ce16ac946119f',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/a1b7c55a61b97f24b73a09c0d2ab6097.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e4a9717c156b6194c7c667573419253',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/7e2b8ff9b78192e03a14c73fec47dba7.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c892585e924585552da32a680ec60ff',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/9e3c52ecf660cfcdf8e8d7b5fe117840.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bc5312020fe5a87da8b71fab10d351d',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/44ff4bd83972c775c4ba6706ea96d13c.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f93e332e020d2badf272c0e5788f7d2c',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/3881a55827b7567562cfb07f6ae5c16e.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a927edfb6a80e7eb545d857cbc81cd9',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/034518309154b0545f83fae39b2ab108.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dafe9dc29978ac49cdfb2a34b61b3b48',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/484aa5a49f2b15c1f94d5c99a2e3a82e.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da662c55ceee2e8869e90c4ea9c32cb1',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/cee23465a6befa8bbd134ea88915f154.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7d80f9d22a2d28b61275418ffe3d360d',
      'native_key' => NULL,
      'filename' => 'modCategory/6cfe85a3d84d0aedbcc200c129e26bd5.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);