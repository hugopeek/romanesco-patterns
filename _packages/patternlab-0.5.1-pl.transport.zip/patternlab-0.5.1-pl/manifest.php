<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fc4e18722b34b931416b21e54e2f1ba2',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/78252f487c3f0e316e574ad4421892a4.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b270bbab00d4554723cded7d1fceb23d',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/52c7b9740ea1733e49fb277b26ee2d86.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fc3debfbd46468ad939362d445a4496',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/66f0e8cefb77adb7b692b7b26d94c693.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42350c66a3499fd00ec57a4c7ff4581f',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/db9eb544f7e5b50fb1d2e41f1d95e0c1.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea5e042246168a68d46da42271f5f3bb',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/4d987b81a9699a487c5e64145d29e2e5.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '320dc4ecf31c7ee06f8e620d0310c15f',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/8a7b11710f8bc84f8b0d8fdc50115262.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d8ba8021c1f649e0e2f4fa9a8de30ec',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/0e12a7bfe5904ba50bdca7ddb1c384c0.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cca3b0907a8dab7ecb474829aea3701',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/bf37e1aaa1434adf9fad8e51078e96ef.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '003dd866a71ee4b6eb377d03ce654c87',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/46372b03bc6ec3a94f023b40d7eebaee.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87ea16f7e301416bc1dd0f757eb9c1f6',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/b29458e1ffc6a5e85eca58e6c6b3646f.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f490ba81928e589c6513e2f0feebbda7',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/7477d9fc38b41e660548e66fc9eb64c6.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12fb3d87ccae755035a2905369807a5',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/5dd8c7aaf05cba32bb81030273c10ada.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de2f8df02a698214359d17d15a4a33ec',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/0afe6091470588a9718bc35a94ab50ab.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44869b449c1c4f056b1defc6e5877192',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/ca13939927203036f898891ea34dc414.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96653574db4c26fafa1b10a0f535ffc7',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/d0e2a440a290de3cec8d3ebbfcc0a672.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78252181dde90904fd89776c7a11d514',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/29d7283b2c93cfff5acc3e4dd6b2f6b3.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76602c4788f6b70502f52182b9678d68',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/1e76ffb9ed0905c049a62eb016d27d26.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6358fb2a6cdedc073aea8331e9d8f55c',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/4840b60b37df3c6c9a4ef6fe59d4466a.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ce8d6bcfd266caf8932c848145cb7df',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/96791254dbff4fde165b67d12d9bcb1e.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ac48a1957657f2d2eff333a4b022d7e',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/40f7fae1fef0533f2fab235cb54e0625.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08849e791603cb5fcdebb97a973c2a24',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/5b2cb7a215905403c7d5f4fcfe505d2e.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceb7963a01b9faa6c2c9bf65f0553b86',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/3c60e3db5d45288bd20f22d2b5c056fb.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '81a127fbb03b884e8fa934700daa073c',
      'native_key' => NULL,
      'filename' => 'modCategory/bad0bda2fb5951a70517d13be07cf656.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);