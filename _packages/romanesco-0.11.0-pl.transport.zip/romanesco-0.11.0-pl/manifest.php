<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4e78d30d938fe461498d4827b0905d92',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/8dd0a5bfcd20d949dff409959500dcb5.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6934eee7d6b736f3de011515d2940b70',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/91b41531a06e0d0119749c130844730f.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '472f4c1ff2922d52818f2f46d8bf0cd4',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/3cb1b166f9ccff814ee123ddd98dc04b.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f49289180344b6288ce066fab9064535',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/f9419c08abd69a3d4e2e85de2ba47d22.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df965259b0e5fe8f1d4dd644e3c2622f',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/6c3b181529becd42e2fa63b9bef24cc6.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afd105497b69aeb5675a58dd22305570',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/b234f76cb1b0d7fb1ce4f8b7defe6e8b.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80bd2afbb7ab26523f30471a1f27135e',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/be2d96a8a6dfa87470f78e39c8918280.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01a8eac722bda82d032a8ff63d6affcb',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/84ae833600fbb2b2fd60399e0ed5bcc2.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86d21cbbe4a5833f4e9c30995decd1e4',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/d938d2b0854ad714b8f7e4d166dc4637.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7734c998723f0d01b7e5e25e561153',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/1076897542bcc5cf702dab516832d388.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f97ae8488fca2fa0c381eaba7d34778c',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/0f80eec96b8335f5e3acc41313b80ad9.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c80a35774920a987bf48bdf4bdf7f6',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/bf141991009d7897ac00f975a079f0e1.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '542cd360819f26ff69d5b950922e02bd',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/8ef124dcc59d3238a5a562db4aef5de8.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9cdb9360e8af7d54cbbaeac8f99de57',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/bddc42b8178d17d7f49b78611390846e.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4666cceec21e448c9531a8bda1b04ff5',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/c5f52e366ff1fa86ef1a6e24c3e1a733.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf3d0861717996907bd0630f013b689',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/bed670b315682e087490ffb485b23500.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd47d931aa4e5b72444a8707f4b5bc30',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/c2c1e7bc51738c3f693f2f25b02c4fac.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ab1571aa844ae862425d2e039c3a2b3',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/8cdb0cafa5a0d778162729d2a0333e7f.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e756042a0b94ecd5309bcbe8545f073',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/50769157a2ea422be76716c9a66b211a.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24a537105357fc68ea894ae56aa88a31',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/5be6c15cbc33e5699c36d3c8de580d95.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f51867e13a22816507fb8fb2a37185dc',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/86df3fd7995c970067fa9107ddf9084e.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cdd299a52e16bb57ad378dff25292e9',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/125a6703f5e5eee9fc8e986e46dfaa7f.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efabc0f7741be3e9197b26c2e7e7a9bc',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/8c57f5605e86210ac46a63177eff33f9.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68cb5a4d774242bb673d11dcc765c866',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/c6d195b7918fe09c288fb86165b46254.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08cebef16d95a3114a7a8af6f115eecf',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/7dd42eb7a4b61fff308fbd59e7acdc20.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8566fc0afb4c106aa35e216fd70dcdaa',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/04181cebdfb3aa8196464b5233d0a236.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d25a72601dedba74e576f07194d927b',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/55e4c7632f05224c432a92f5af57fef6.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11740005ea7c0d2ef40adcd397eaa36a',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/83a918231f54c95e99d5c0ac46530a0f.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8510f5536049ab85010c2f2209b63b8e',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/36c431c158db2f7ab89f73eaafbbbe20.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9426b5574d66957a140dc4e3c8f4714e',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/47f40e538c1fe0dad19c2c341331e6ab.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa0a845aaa22487daa60307769b07181',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/7fef966d8c953b82d14ae0db62649c42.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f56307d9e92386b8251b2d5edcef9143',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/45139bffae6265d2fdbbafc45eac997f.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc60c184789df4d954055ee7a631cc62',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/f764141e832b002770ae30241ec3991b.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ce4396c7a63c2735aad6efd8f548b22',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/27ebd2f944999708f4a168994e0f8c1d.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '169bf689fa42a9e55222b1f18270fc54',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/c36f271901dea032864b377308d86a8e.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00d266e11ed9914f026f7467aa170e0',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/330d25504df7f5d870cb4420cbe1c047.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62c246d8ceb9ee5d5f154312dca695aa',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/8ba6ae480adbd34999244812b4306103.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96193a00c0bfa5722857fb8fed4b7c86',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/24244256fc5730d219f3498197e7dd18.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '212d45d5f92835d2832dc51a5c6719e2',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/6b001be347b493ec8c67884236bab104.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f1ea31779a585ec2e0981a222bb240b',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/088f64b4c5d6e02774b7e7c5eda16ef6.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5cc5449653eca1163a1327f202be948',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/332fb6151d75d9aed5bc23eefdf50015.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '34e59553ac6f6eb2178f625563f13126',
      'native_key' => NULL,
      'filename' => 'modCategory/a7771d643f614722a8519f17763e3a48.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);