<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.14.1
Released on February 10, 2019

New features:
- Add TV input option for selecting Fibonacci numbers
- Add math question anti-spam option to forms
- Load Semantic UI styles inside CB preview containers

Fixes and improvements:
- Rearrange snippet folders and import a few new ones from projects
- Fix Overview headings displayed as regular links being too large
- Fix Registration template not validating password correctly
- Exclude resources with unchecked "Use alias in URI" from breadcrumbs
- Make icons work inside CB chunk previews
- Make check for detecting SeoTab plugin watertight


## Romanesco Patterns 0.14.0
Released on January 18, 2019

New features:
- Add main navigation with dropdown submenus
- Add template with Table of Contents menu (instead of submenu)
- Add template for Downloads
- Add Kanban layout for Content Purpose elements

Fixes and improvements:
- Update status grid to incorporate new / altered TV values
- Add optional anti-spam hook to forms
- Add option to select background for rich text segments too


## Romanesco Patterns 0.13.0
Released on November 15, 2018

New features:
- Add content purpose TVs
- Add TVs for external links, file attachments and related content
- Add ability to create input options
- Add ability to create crosslinks between resources
- Add re-purpose component, for creating content "flows" inside a central topic
- Add after save hooks for MIGXdb configs
- Add JSON import for input options

Fixes and improvements:
- Add chunk for dynamically generating TV input options from database rows
- Load project timeline through Backyard package and store data in db
- Rearrange TV categories and add rank
- Replace Grunt task for generating GPM config with PHP script
- Make tvToJSON output suitable for use in GPM configs
- Disable CSS background images for Tiled overviews
- Fix sidebar not showing on largest screen on Team and Client pages
- Fix link in Instagram social button


## Romanesco Patterns 0.12.3
Released on October 4, 2018

New features:
- Add OpenGraph metadata to head
- Add snippet for clipping characters from start or end of string
- Add plugin for injecting inverted classes into content (requires HtmlPageDom)
- Add options for controlling footer and bottom CTA content

Fixes and improvements:
- Include homepage in basic template list, so they also have Overview TVs
- Fix author image in compact article overview template
- Disable Disqus comment count in overviews (was acting buggy)
- Prevent decimals in calculated image dimensions from breaking variables file
- Allow overrides for head and footer chunks in all templates
- Fix issues when using multiple file upload fields in form
- Sort available forms by menuindex in Forms CB


## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)


## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3370afbe7dfef2cbcf26c828c7589d5b',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/1bce914ddb418da6c294d32f631ab4c9.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44cf4fc51cd564939aab746763222392',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/dea7dd82c4c60b113a4820f52a23c023.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cef294666bcdb4ad3265ec0101d44740',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/d86b6e0ff405d4fae052d5d41c1e35ef.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55953aea6fee6680b828bb75a08302f9',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/ad95e8bb0b842e5fc0ddc34f14efc854.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c0bb6b9b584309bcff60214e497cd47',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/88fb5aed0625e79be617a9f2fe04e100.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a196bdd7bb5cef9611aaa3231881eb8',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/3eeb3c33c2c59065d85c8cb73ddf5d99.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9495126dc930b0eb8c585be5f427a2a1',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/fe09d899bbac69ecb3747f9622ddfc89.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8197b7251330ba034261a4008fbcb6bb',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/516bd910d00cdc23ae92d6780698992e.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e785cd883a56e555f290a8012123975f',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/b07ca9925bfb11a2138fa68e15ffe904.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21f16f80b3127a78c447d7b3317c7185',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/94d97321c2d32ac311782aa3201cdaf4.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84d92e2bc3631bb9f800de6b3dfa9fd8',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/c1704156bbd73334234d5db17d582058.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '125b42c5ec8efc7f0fd0e6d1018bb440',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/eb8b901f438388f9f97ff8feab5b7a00.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1029f76509805cbbd28c81ff7479e4fd',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/96b874760dd4f0f4c05157d30c3f1b17.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7527ad60d7f12e8d7595857e2eabddc0',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/ab89a89731dde194001a434ac222aac2.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a73b59b56746fca6bfe6cecee7037db1',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/16078b699e3053b24b27bef35d787d82.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44ba367ccac4c5f02572233fc79edd04',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/1fc3da5ee30d07bfb9ccccc05b70704b.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eacd87fca4382620b6b9bf87ebeaae38',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/46b8301375e6744dc52841bbaa8e9e51.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83172e8173b1861d908f5464a22e9b2c',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/b0939a0b839215b9223419e0139a801c.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fcef7e5689962623b902628c9e84afc',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/3c487d719dc7d97e8684e6d97c538ecb.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f254c01b7b463cc92e0d729b1513bfc',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/50c4832a69421bb914ea715f6eeb0d80.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f163aa86c3eb3091ecf90496c5070b73',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/728c980bf2371560f83fe357f5573c46.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc080f3092aa62aa48090bc57c0f4163',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/3ae0442383d1e7e4f3776619faf4fe5c.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0b047f099d6473efdc6828685f274c3',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/57858459a1a79b066439e10f0a0b2121.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f8f30c1bc5703b887974329e587ac5b',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/b2955152d3abf398a0b07c58ea6fada3.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1215e4702c515e71d47a8cc2ec4f6b9b',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/b1e9a1a583630c8aefdb94f1d1ac719d.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78e8c5a935df63a6aff24e2fb8362986',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/f1f37be64bc778536a7145fc137dfb2c.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acb01b1a2d4ca8e00fa46f845d0a7bf3',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/a85d450873cb6a38f498b6902361ab5b.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0758f9d2c90d64b170f98613e0cc4e8',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/99b3e6ecff39305829ace2528306d829.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b290da35d437f79a1a2fd4fe9959072c',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/1c587de41f8e2946ecfb02e497290544.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1e8b4af74c330f736d78a77168e5958',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/af4f004a91b2e79094835b2dfa6fa3fb.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6de63135317886973516d96b934e301',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/b42da13410c3f3751ffc7b2cf4258ae3.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8d65c3631c1d1dea5caef861ad4f0a',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/cc14d0689b6e038e557a8569563fac9a.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aac30478e9caad0ebe4ee2e9f7b2a6b9',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/1ebb26ab48e06e1e6b3641f52cae76df.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b2dacd640ca699cf11589e01d19190d',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/cbc30c8edf6c3460078d1901394efb34.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b15419977172f5fe9a4bf83e4d45397',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/5d36470f3b2d13d761465ae3a26c2ed7.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09693d4f43c530e4e2d49702a75b7f0e',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/19bc06332558a56cde06dd84cd69912f.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50e16d68d23b25859ce6511f45c755e1',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/ef4a07f0229b8d559aaf4a0abafc10b6.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '787ce1b673867278f5b60e83b63562a9',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/57846d1aa1abc9b1c05852f238a91006.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '526cd2ac74e0a1b79cc46cb28d0adadc',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/65cc90892a549e7cec538500606807ca.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '861e9f81549e5deb3e2215fb968e67ea',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/41e07daa621542a64cc0ebd74892dc67.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f7d979f3f883d370ed20b5a9e935b1',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/b03e8e2408284bc0a7203f1368c47642.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07c74dadeb5da813b9b461ab0f59d6b5',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/59570e720996221f2a3befb36d036b75.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ed9db201bd6673317151e4d51cd6ce5',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/732cc45044a99988106c06cf9a219d55.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '171a2e9e4525407a072ff9180942ed74',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/a10290bd35f689ee12dbe86481c3d77e.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00c9dc2ae0d059003b45394b31219738',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/f22709fd6da15b0fe8ebae1de94f4eab.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '311e448e0733b615111a8067a7cf5bf4',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/dbe7f4debffcf24b4f9f806c2eb4d1e4.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '133e89b74790fcfaece1f9df7944a490',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/cc61bc9cfb2dabfc8c0255e1457e310c.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8743ecee4bb66ca131b4b1252988fcf0',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/f75e8be05e34688c2657bb7d730c0907.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e9135daf1912b39b166a2dd4c392d8',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/3a5bb7117416902cc7cc11643f6d157d.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e23a41066ef5d8f2ba12ebe5f46d3efc',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/dfdd8f6dfa908dc10215a64e069dee1d.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b67a6e1f34f2678e62e7fb86afe58314',
      'native_key' => NULL,
      'filename' => 'modCategory/49d6693d4c239bae45359b6026727277.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);