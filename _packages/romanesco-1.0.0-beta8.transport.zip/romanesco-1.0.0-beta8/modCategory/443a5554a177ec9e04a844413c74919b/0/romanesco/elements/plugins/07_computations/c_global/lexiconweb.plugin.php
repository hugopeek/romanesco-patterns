<?php
/**
 * LexiconWeb
 *
 * Load default lexicon in web context.
 *
 * @var modX $modx
 * @package romanesco
 */

$modx->lexicon->load('romanescobackyard:default');