<?php
/**
 * fbLexiconWeb
 *
 * Load FormBlocks lexicon in web context.
 *
 * @var modX $modx
 * @package romanesco
 */

$modx->lexicon->load('romanescobackyard:formblocks');