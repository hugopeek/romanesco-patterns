<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco

## Romanesco 0.8.1
Released on May 5, 2016

New features:

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN

ContentBlocks added or edited:
- [Field - New] Tabs (Rich Text)
- [Field - New] Tabs (Flexible Content)
- [Field - New] Twitter feed
- [Layout - Updated] Content + Sidebar
- [Layout - Updated] Sidebar + Content
- [Layout - Updated] Content + Sidebar (Nested)
- [Layout - Updated] Sidebar + Content (Nested)',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b0fd7b2c80fafea0e04d92a6f11840f0',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/5fe88e200b1597d10997b92f97fc11b6.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c45c0003569fed9461ca319dc17bde3',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/2a1c6f582aec5843d5e54fdf617ddb5b.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f06fd0ed13a52926b6b881d503fae1de',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/18b0aee78f69074de6effad62849ec24.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '556057679b0696f83f01f61090db0db3',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/82774cede40ed244ee93f0333dffd22d.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09776fd5d181021cd297bc2a19173f2f',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/2d59bd59b5c8451d370ee7f155b0b835.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbd489880e785df09d9c8a0787231a66',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/81b87acc2ec0d26b6ea18ae54d221784.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7201521bf941f60bc010e31eb315d224',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/4aa21e0f92f2e24055dacfcea6a28bde.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eefa663f3183368aca999f17dc82d9ef',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/1d8fa2c8f2d22ccf9010512e9e743037.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '373111045d8e55cdfbbc73969adf69c9',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/0fe94f9a2b337ea3ae00563e51c1a82d.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce93d82825ebf0fbabdfc9f09385ac35',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/3feef0dcf13b0a999f50ce8435679228.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8dfd084b329ee2f5906088ee55fde1f',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/fd9957794f972d6e538a765b6e58e828.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a6951a9f9b4db2abaf88dc93c1b9a26',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/a05c3db6a70efe45695a9e2a7e8d33eb.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e876436e0a04edcf76ee5447e6b8372',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/af002a13b0df50fcf6055da556a116ad.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a8a1d612d8349d1e4a2a0e20addf757',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/c950b7768ae2f4caa27b10f9ec6e0dd1.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85faa011f9e7f8564b1385be32a145cb',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/62df1952a4626b7a75819ef67156d1c9.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd40ca5a347ce9b31130074315ed2e77f',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/927a09974b8ae8a712265ad49954032b.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '718dc487c43608c5587a3acd054c5eeb',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/737e53b82670f66f4801c982a2ac58d6.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f7f58536fe947fe756b7c0e7df5ef8',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/7abf1c641cede61c82f1f0a899d9b6dd.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '254118543e136b87ee255bf49a80fa78',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/ea6ff635b962ec73bc1fb7cbc1e1364d.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c247c385a64c48d3c1bcfc51673acb05',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/35bb7accf6996134e56112c563e26d13.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5389e15b6718eb71acb95423b32def01',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/6e8a6c6be3866b7dda57453780f2fe2c.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bca578b2c2bdcc151b53826db3643ec',
      'native_key' => 'patternlab.publication_container_id',
      'filename' => 'modSystemSetting/ad5deb275fa554c627d984a095bc798b.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c51fe124969bc57d77cdabaec81a4fe',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/9f8e3e08137719bf3e4f2bb243b42dd1.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b784bbbe996abe9728dc8b9f9689260',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/5328e9e1765552d0650d5c44c15e84f9.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '539d8ea067f9a14c0e4f0b3b35132dbf',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/1e32329def77bcf85f41f6be7241121d.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ff32b059485d057479ae38c5a28ee4',
      'native_key' => 'patternlab.social_twitter',
      'filename' => 'modSystemSetting/5a8c6aabfd22fb482462af4f9ceb6d41.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c915db76d08965746538b8873241bdb5',
      'native_key' => 'patternlab.twitter_consumer_key',
      'filename' => 'modSystemSetting/0f2ba78f1d2e3e15daf6636d8411098a.vehicle',
      'namespace' => 'patternlab',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5332ba7484f996f7c0385c291f852f7',
      'native_key' => 'patternlab.twitter_consumer_secret',
      'filename' => 'modSystemSetting/525ffa0b4a5c72601ab1c26a36745f9b.vehicle',
      'namespace' => 'patternlab',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6527250ce49bad8830585659debde29',
      'native_key' => 'patternlab.twitter_access_token',
      'filename' => 'modSystemSetting/9fae0555262bcbd590793adbd1ca7e57.vehicle',
      'namespace' => 'patternlab',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd54fe1b7a139ff2f39c0a091cf962df8',
      'native_key' => 'patternlab.twitter_access_token_secret',
      'filename' => 'modSystemSetting/8f414e698d92006b393d18a13c1629ca.vehicle',
      'namespace' => 'patternlab',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c0414ec5f9801ad993c60c882d42baf5',
      'native_key' => NULL,
      'filename' => 'modCategory/4cea42b8587969efe1c0b9e871f9791b.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);