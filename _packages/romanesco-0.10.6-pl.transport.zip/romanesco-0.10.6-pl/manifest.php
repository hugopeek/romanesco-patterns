<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.11
Upcoming release

New / planned features:
- Add ContentBlock for creating previous / next page navigation
- Add ContentBlock for creating a button group
- Add template with main navigation left of content area

Fixes and improvements:
- Responsive images through srcset and picture attributes
- Apply dividing options to Overview grids too
- Add descriptions to all elements

---

## Romanesco 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '649e61c3c55e7f39d9e176f0aa7697b8',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/7ca04b510d87b99efd83edbb94ff4321.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77bdd0f619968907596708e08d0047c1',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/229f1a018e85d1e62230165f8718d951.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1af216c947473634c3a360840f64527',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/2ad4788f022d34f5d4870442203ae2c8.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f76396c1e7b2636769c04be5629c6522',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/138f9d5e1c9c10cea74e39b75e92f5c7.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '385c3b535052db6d26dab784de23967b',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/1e6bba53e275f4cd5ef436e2d123781c.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc683d8b47603c04c4a9f1387a2bcdb9',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/db0dc4347889a566dca2492d5e06972b.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f1260949e4a204b89db008f04e31e5f',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/cdc59798dbcdff2b7fe6bef13b02d436.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '728e4cc8cc09aa7e7793b487c47071d1',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/517dedb6c8304efad769f32e9b85bd03.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1178d6f973198bc1b10cb656426aba5',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/473aa42794d27eac1640c6ed5e5ae8c4.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '225022d88fb808bc983aabca4adf1b4d',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/7fd8ee88ff0f78623cb122ca204c4d6c.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c21039c916145253c8f3191bdc3fe3',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/2b93ba7a095fb2fa493ff79c953d0776.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc5f1300b3519bd2714555ab7a6888c2',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/1a3bd66691a27233673696648cbb1717.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d415155c201cbc3280dba30a9c01f36',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/c9216ffddcdcf28e2d62979bef838df6.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b13b97288971e049480c02e125dcf28',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/e2d57a722bc6f16d083ae08f412dfb9d.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38f30198888c026e95dd65b5ed5b1963',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/4b7be988586ece6721d1059c1f202a50.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06a0aa00b738aee8fc35301e347729f1',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/5a72ef375f80219aad47319195676631.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '628fb87c27ea5c91df01a7d7b08bd3ea',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/8e8ffd95da2fd7afe0386c5cfa0e91e7.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f09159a85e5578d82243ae8963e161cd',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/4384c7fb8e9bf68f68a4aa62b9fc1048.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fff3fccc4717d64d0202159f589c106',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/309bb67752fbbfbfb8a288752d8409a4.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95c3593b5797c5b3cf5b41923bc2181e',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/0bfde7b679139b0e96813089ca55a453.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe0120def5119ce82ea7245253032e8',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/a509efbef9eef6f312303bc2546d10d5.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f92c07eced4c689af9b4454cc2a9f6e',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/ba1e292335222ec3fbdb05cfe3bcbb77.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61970deeb8df9d779ad503aca46d9e82',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/8ed6f13b151c29656f925041d9a72302.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7a66ddfa4bc18bc9b939fe5dcf86bbf',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/83a44decf5c7cced09fae3c4b7ac6bcc.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b0cc65c42db7d820461835e8ff32887',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/1eb9fc06ec221bac52e8641e89385cdd.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9acd68cc8ef838a502edf48717b300d6',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/b977bae6be34e89075715330c942c07a.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bfb147e42c46abb5a66e7fb3e6ea92a',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/bb5610e5ffe37a67017b3acb60910036.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe8ccc9b1f5dbb006cba19fc40f8c40',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/518d23ab54429df871cc439ca2e7d352.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe64598b24dfe566bf6c32a001b80892',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/dac5ba4a6c83530be7126d467451f711.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9952c1e24a2ed478e9e8674398bf9187',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/aacd343503f8eca08f648d782080c86c.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e690580f2e532e7123b9b4508ac10d6d',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/2f2120ced4eaee0d06af499fb82b55f3.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bc638b9e4bba1f267df228b00983f1b',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/2b84b0ca2d916eb2c3fc0eb5c6826db4.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48df475562c8a0eb0795ff9d01cabc07',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/336c4cdfb9133e239a595308fa821b34.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f6e603fa2453e26beb5619b5a5a8ad7',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/18fa0bbb40bdfd1890e9d8f75b48ae49.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '449d83d1265821cc067bc5805a8cdab8',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/43a9baf5fe02001c7b2a4ce1dfa9efa0.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fafbccea66d4aed6215735901f1297e',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/55d85861013e3bc62f3dda369ec153a8.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07f7b5f30091a3a785bc7c240a79c51f',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/6665ec5dec42bb557c4fac7532ac9b40.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd62d41937968f3d6a1147841b3d699f9',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/dafcf0a051f06d989bf794e37ef6330c.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '401106dada73899803d0ef2cde00a782',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/9a120fe8267f3b80ede9c753ae7d5065.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65239b9272210bb7fded854b6b621baa',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/034251a3d94a72cc7a28c2a2244f7d20.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b0c5cc01d6c8a682e3bc927a6ec6a8bb',
      'native_key' => NULL,
      'filename' => 'modCategory/b9128d8936e0adc55cd4465a60f0db94.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);