<?php
$modx->lexicon->load('patternlab:default');