<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN

ContentBlocks added or edited:
- [Field - New] Tabs (Rich Text)
- [Field - New] Tabs (Flexible Content)
- [Field - New] Twitter feed
- [Layout - Updated] Content + Sidebar
- [Layout - Updated] Sidebar + Content
- [Layout - Updated] Content + Sidebar (Nested)
- [Layout - Updated] Sidebar + Content (Nested)',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '41bb0e1b6f724375855636b5f619cb6b',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/e1877396b1143e83d07d177983196c34.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66723d8216a475a8b04d238c1f8f4abd',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/f6b5b3573cdb36a1bcc2eaa6cbdddd90.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5205aea60e1e1fa99716df350a80ec4',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/0dfe9a92515781dc9b6c69e0be395a94.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '613e81d8a42945121f696bf5426b9e3d',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/077136d60aff119f7d205294f0a589d0.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7ad100eedf8b0f99f5ecae6e79e1649',
      'native_key' => 'patternlab.date_format_short',
      'filename' => 'modSystemSetting/102e7b48e604a8bcd8de99ba6d017b41.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f1165b170e5c581c3fec1a0f66c2c17',
      'native_key' => 'patternlab.date_format_medium',
      'filename' => 'modSystemSetting/42bf0a0835492736678531f1b1f4726b.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f28346bd0b36880bc79b8dbefcccff3',
      'native_key' => 'patternlab.date_format_long',
      'filename' => 'modSystemSetting/b572c10b4da3da8874370eec70473dba.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b90d421a999cbb9f78129065d3f08c14',
      'native_key' => 'patternlab.date_format_full',
      'filename' => 'modSystemSetting/bba12bf5e7cca5d8daab8b3bc114800b.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49a145ab7bb9e30db9b601ea61160e96',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/45e31bab14c7ac104597c1179da9d9b6.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac0d351a34d9f03bbffeb20a75723c32',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/f55ecdb7ea9b71880414a88fb012fe63.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf91dc3e761ee851b43c0c2cf2508b7',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/52a669d75383cd325f2d5e2654ef58e9.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ea131e8c4117e92a188931e84ffae8e',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/ff785898d1ba9ef74599ef58f96a6cdb.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8af404d4226782056e0a64ff73a866d',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/446035c28dc3c43d5b21a67f2e6e07c6.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8bba5c6b52f28bbfb946d5bf37daf2e',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/47ba92fbc733a07aae809d638d26ed60.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6c85c68270ad01230ee54794fc72061',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/4cb289ef282e444ed4f6f6a6d11ea3ef.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '693c119b3364fab566512ef8820d5101',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/9f946e57350a560a6d1e123aafced08c.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40e44411ececa05944c9f144e01e8977',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/4f570e38b7ab2ece4ae092b05bbe5f5a.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '494f8919b4b8b6c73af4ab74f34bb3b1',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/a975d7d6f34bb8c9b179cf20e05dc4a8.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '116968b7f6383a9d4fb26dae6650cb4d',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/0750973c78038d4940e512557e1f18dd.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae8952a19947554461c222f871b68752',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/92a78fe555f33668acb272e7547e7d86.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '349556f8527f68016bc2ca0552d8c2fd',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/16ee52682043a2f513ddc87686826598.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62d94711dcf7d5c08e0c91b0823050f4',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/9f6f04afc4fc3808b9eac38752f50c96.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41f9ad5d0c555c3af005680a66dd3912',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/88e19af8197eb188d94e50b2396d80b1.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3350e943c1137cf96f4a79ad48315676',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/fc2404b0808fc187a9a3a756201f27e2.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f3f4adb6864692fb578608ed92a4164',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/41b90e01ed46181533e771c8b36b9922.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8315bf4486c5fa222638849d513eafd',
      'native_key' => 'patternlab.publication_container_id',
      'filename' => 'modSystemSetting/1dda96affbe48893dc0a4bfdbec87f31.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27decbe5efdca8efeda2d6766b6149f6',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/72cef5507f934c00f5c6dac52fa0cd72.vehicle',
      'namespace' => 'patternlab',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f7775c5efd0e22a6ee033f4aef3a326',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/deee2ced8ae13f6e1fabe45af3455116.vehicle',
      'namespace' => 'patternlab',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61a349b629ca9889e944730479c32f45',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/21777a68848d5f414b620bd5cbfadce6.vehicle',
      'namespace' => 'patternlab',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc4b17767c242f5a88a688566c43ad59',
      'native_key' => 'patternlab.social_twitter',
      'filename' => 'modSystemSetting/f9babf44d3900466c0eed9e60f8c3c94.vehicle',
      'namespace' => 'patternlab',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b356ada76db23a8b2558c8dedf7d876',
      'native_key' => 'patternlab.twitter_consumer_key',
      'filename' => 'modSystemSetting/8d103dbd2d2da79156089f830f59a50f.vehicle',
      'namespace' => 'patternlab',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e54ef0b857f77b7cace35c2562bbaf23',
      'native_key' => 'patternlab.twitter_consumer_secret',
      'filename' => 'modSystemSetting/ddf06a226e8ebbb851af047fc8378080.vehicle',
      'namespace' => 'patternlab',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdfb4952d721f47e29628592ce3ac450',
      'native_key' => 'patternlab.twitter_access_token',
      'filename' => 'modSystemSetting/db7f69be11a86ad4dfa6b57dd6222d11.vehicle',
      'namespace' => 'patternlab',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e5e00c272c56a89a488264455b84e5',
      'native_key' => 'patternlab.twitter_access_token_secret',
      'filename' => 'modSystemSetting/33c8418834777c2f29abe482acb4a2e1.vehicle',
      'namespace' => 'patternlab',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '74684af0ea630cf26084006a045b1179',
      'native_key' => NULL,
      'filename' => 'modCategory/6d4ab34e1c4ea8302fea37fd65e666db.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);