<svg class="hidden">
    [[migxLoopCollection?
        &packageName=`romanescobackyard`
        &classname=`FractalFarming\Romanesco\Model\Option`
        &where=`{"key":"status_progress"}`
        &tpl=`statusIndicatorSVGSymbol`
    ]]
    [[migxLoopCollection?
        &packageName=`romanescobackyard`
        &classname=`FractalFarming\Romanesco\Model\Option`
        &where=`{"key":"status_health"}`
        &tpl=`statusIndicatorSVGSymbol`
    ]]
</svg>
<style>
    @font-face {
        font-family: "brand-icons";
        src: url("[[++romanesco.semantic_dist_path]]/themes/default/assets/fonts/brand-icons.woff2") format("woff2") ;
        font-style: normal;
        font-weight: normal;
        font-display: block;
        font-variant: normal;
        text-decoration: inherit;
        text-transform: none;
    }
    i.icon.trello::before {
        font-family: "brand-icons";
        content: "\f181";
    }
</style>

<div class="ui grid">
    <div class="nine wide column">
        <h1 class="ui header">
            [[*pagetitle]]
            <span class="sub header">[[*longtitle]]</span>
        </h1>
    </div>
    <div class="seven wide right aligned bottom aligned column">
        <a class="ui legend icon button" title="Show legend">
            <i class="info icon"></i>
        </a>
        <div class="ui basic icon buttons">
            <a href="[[~[[*id]]]]/kanban/" class="ui button" title="Kanban view">
                <i class="trello icon"></i>
            </a>
            <a href="[[~[[*id]]]]/backstop/" class="ui button" title="Visual regression tests">
                <i class="eye icon"></i>
            </a>
        </div>
    </div>
</div>

<table class="ui very compact sortable celled status table">
    <thead>
    <tr>
        <th class="collapsing">[[%romanesco.status.table_indicator]]</th>
        <th class="collapsing">[[%romanesco.status.table_id]]</th>
        <th>[[%romanesco.status.table_resource]]</th>
        <th>[[%romanesco.status.table_tasks]]</th>
        [[*id:SeoTabIndexation:isnot=`[[*id]]`:then=`
        <th>[[%romanesco.status.table_indexation]]</th>
        `]]
        <th class="collapsing">[[%romanesco.status.table_owner]]</th>
        <th class="collapsing">[[%romanesco.status.table_date_due]]</th>
    </tr>
    </thead>
    <tbody>
    [[pdoMenu?
        &contexts=`[[+context:default=`web`]]`
        &parents=`0`
        &showHidden=`1`
        &showUnpublished=`1`
        &includeTVs=`status_progress,status_health,content_owner,planning_date_due`
        &processTVs=`1`
        &tplOuter=`@INLINE [[+wrapper]]`
        &tpl=`statusGridRow`
    ]]
    </tbody>
</table>

<div class="ui small legend modal">
    <div class="header">
        [[%romanesco.status.legend]]
    </div>

    <div class="content">
        <p>[[%romanesco.status.legend_description]]</p>
        <table class="ui small compact celled status table">
            <tr class="olive">
                <td class="collapsing indicator">
                    <svg class="icon " viewBox="0 0 100 100">
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="[[~[[*id]]? &scheme=`full`]]#status-done"></use>
                    </svg>
                </td>
                <td class="collapsing selectable">
                    <a class="edit" href="https://romanesco-nursery.loc/manager/?a=resource/update&id=1" target="_blank">1</a>
                </td>
                <td class="selectable metadata">
                    <a class="level-1 hidemenu" href="https://romanesco-nursery.loc/" target="_blank">This page is hidden in menus</a>
                    <a class="ui empty floating red circular label with tooltip onclick" title="Description" data-title="Description" data-content="Red indicates the field is still empty." data-variation=""></a>
                    <a class="ui empty floating green circular label with tooltip onclick" title="Longtitle" data-title="Longtitle" data-content="Green indicates the field is filled in." data-variation=""></a>
                </td>
                <td class="tasks">
                    <span class="ui mini list">
                        <a class="item with tooltip onclick" data-content="Walk through some basic usage scenarios in a short video, to get a sense of what Romanesco is." data-variation="">
                            This page has a task attached to it
                        </a>
                        <a class="item with tooltip onclick" data-content="Walk through some basic usage scenarios in a short video, to get a sense of what Romanesco is." data-variation="">
                            Click on the task to see more details
                        </a>
                    </span>
                </td>
                <td class="collapsing owner">
                    Hugo
                </td>
                <td class="collapsing due date">
                    [[Time:date=`[[++romanesco.date_format_short]]`]]
                </td>
            </tr>
        </table>
        <p>[[%romanesco.status.legend_published]]</p>
        <div class="ui two column grid">
            <div class="ui column">
                <div class="ui small header">[[%romanesco.status.legend_progress]]</div>
                <table class="ui small compact celled table">
                    <tbody>
                    [[migxLoopCollection?
                        &packageName=`romanescobackyard`
                        &classname=`FractalFarming\Romanesco\Model\Option`
                        &where=`{"key":"status_progress"}`
                        &sortConfig=`[{"sortby":"pos","sortdir":"ASC"}]`
                        &tpl=`statusIndicatorLegendTR`
                    ]]
                    </tbody>
                </table>
            </div>
            <div class="ui column">
                <div class="ui small header">[[%romanesco.status.legend_health]]</div>
                <table class="ui small compact celled table">
                    <tbody>
                    [[migxLoopCollection?
                        &packageName=`romanescobackyard`
                        &classname=`FractalFarming\Romanesco\Model\Option`
                        &where=`{"key":"status_health"}`
                        &sortConfig=`[{"sortby":"pos","sortdir":"ASC"}]`
                        &tpl=`statusIndicatorLegendTR`
                    ]]
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

[[loadAssets? &component=`status-grid`]]