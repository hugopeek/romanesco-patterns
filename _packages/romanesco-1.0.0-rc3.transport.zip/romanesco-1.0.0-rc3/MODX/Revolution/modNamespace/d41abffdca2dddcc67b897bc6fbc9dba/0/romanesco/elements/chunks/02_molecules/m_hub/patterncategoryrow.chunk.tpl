[[+name:lcase:empty=`[[+templatename:stripAsAlias]]`:toPlaceholder=`pl[[+id]].pattern_name`]]

<div id="[[+pl[[+id]].pattern_name]]" class="ui pattern segment">
    [[$toolbarPattern?
        &pattern_name=`[[+name]][[+templatename]]`
        &pattern_status=`[[getElementDescription? &type=`[[+elementType]]` &name=`[[+name:empty=`[[+templatename]]`]]` &property=`elementStatus`]]`
    ]]

    [[$dividerBasic]]

    [[+description:htmlent:prepend=`<p class="meta">`:append=`</p>`]]

    <div class="ui stackable equal width grid">
        [[+elementType:isnot=`ElectronTV`:and:isnot=`Computation`:then=`
        <div id="preview-[[+pl[[+id]].pattern_name]]" class="six wide column preview element">
            [[getElementDescription:empty=`<em class="meta">[[%romanesco.patterns.preview_not_available]].</em>`?
                &type=`[[+elementType:lcase]]`
                &name=`[[+name:empty=`[[+templatename]]`]]`
                &property=`elementPreview`
            ]]
        </div>
        `]]

        <div id="code-[[+pl[[+id]].pattern_name]]" class="column hidden code element">
            [[+elementType:is=`ElectronTV`:then=`
            [[jsonToHTML? &json=`[[tvToJSON? &tv=`[[+name]]` &showName=`1` &showSource=`0` &optionsDelimiter=`0`]]`]]
            <div class="hidden element">
            `:else=`
            <div class="template">`]]
            <pre class="language-[[+elementType:in=`Computation,Formula`:then=`php`:else=`html`]]"><code>[[[[Switch?
                &get=`[[+elementType]]`
                &c1=`Template`      &do1=`$displayRawTemplate? &uid=`[[+templatename]]``
                &c2=`Computation`   &do2=`$displayRawPlugin? &uid=`[[+name]]``
                &c3=`Formula`       &do3=`$displayRawElement? &uid=`[[+name]]``
                &default=`$displayRawElement? &uid=`[[+name]]``
            ]]]]</code></pre>
            </div>
        </div>
    </div>

    <div id="connections-[[+pl[[+id]].pattern_name]]" class="hidden connections element">
        [[$dividerBasic]]

        <div class="ui stackable equal width divided grid">
            <div class="row">
                <div class="column">
                    <h4 class="ui disabled header">
                        [[%romanesco.patterns.[[+elementType:is=`ElectronTV`:then=`assigned_templates`:else=`included_patterns`]]]]
                    </h4>
                    [[[[If?
                        &subject=`[[+elementType]]`
                        &operator=`is`
                        &operand=`ElectronTV`
                        &then=`
                            $referringPatternsOuter?
                                &pattern_list=`assignedTemplates`
                                &pattern_template=`patternLayout[[+elementType]]`
                                &pattern_name=`[[+pl[[+id]].pattern_name]]`
                                &prefix=`pl[[+id]]`
                            `
                        &else=`
                            $includedPatternsOuter?
                                &pattern_list=`includedPatterns`
                                &pattern_template=`patternLayout[[+elementType]]`
                                &pattern_name=`[[+pl[[+id]].pattern_name]]`
                                &prefix=`pl[[+id]]`
                            `
                        &uid=`[[+id]]_[[+idx]]`
                    ]]]]
                </div>
                <div class="column">
                    <h4 class="ui disabled header">
                        [[%romanesco.patterns.[[+elementType:is=`Template`:then=`assigned_tvs`:else=`referring_patterns`]]]]
                    </h4>
                    [[[[If?
                        &subject=`[[+elementType]]`
                        &operator=`is`
                        &operand=`Template`
                        &then=`
                            $includedPatternsOuter?
                                &pattern_list=`assignedTVs`
                                &pattern_template=`patternLayout[[+elementType]]`
                                &pattern_name=`[[+pl[[+id]].pattern_name]]`
                                &prefix=`pl[[+id]]`
                            `
                        &else=`
                            $referringPatternsOuter?
                                &pattern_list=`referringPatterns`
                                &pattern_template=`patternLayout[[+elementType]]`
                                &pattern_name=`[[+pl[[+id]].pattern_name]]`
                                &prefix=`pl[[+id]]`
                            `
                        &uid=`[[+id]]_[[+idx]]`
                    ]]]]
                </div>
            </div>
        </div>
    </div>
</div>
