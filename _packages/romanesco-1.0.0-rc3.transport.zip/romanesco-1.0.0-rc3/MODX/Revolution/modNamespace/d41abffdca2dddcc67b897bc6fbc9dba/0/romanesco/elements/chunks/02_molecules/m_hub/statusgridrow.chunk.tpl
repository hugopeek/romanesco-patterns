[[Switch?
    &get=`[[+status_progress:eq=`done`:then=`[[+status_health]]`:else=`[[+status_progress]]`]]`
    &c1=`todo`          &do1=`3`
    &c2=`doing`         &do2=`4`
    &c3=`review`        &do3=`1`
    &c4=`stable`        &do4=`5`
    &c5=`successful`    &do5=`6`
    &c6=`problematic`   &do6=`2`
    &c7=`expired`       &do7=`7`
    &default=`0`
    &toPlaceholder=`status_priority_[[+id]]`
]]
[[Switch?
    &get=`[[+status_progress:eq=`done`:then=`[[+status_health]]`:else=`[[+status_progress]]`]]`
    &c1=`todo`          &do1=`orange`
    &c2=`doing`         &do2=`yellow`
    &c3=`review`        &do3=`purple`
    &c4=`stable`        &do4=`olive`
    &c5=`successful`    &do5=`green`
    &c6=`problematic`   &do6=`red`
    &c7=`expired`       &do7=`brown`
    &default=``
    &toPlaceholder=`status_class_[[+id]]`
]]

[[SeoTabIndexation? &resource=`[[+id]]` &toPlaceholder=`status_indexation_[[+id]]`]]

[[migxLoopCollection?
    &packageName=`romanescobackyard`
    &classname=`FractalFarming\Romanesco\Model\TaskResource`
    &where=`[
        {"parent_id":"[[+id]]"}
    ]`
    &tpl=`taskItemTooltip`
    &toPlaceholder=`status_tasks_[[+id]]`
]]

<tr class="[[+status_class_[[+id]]]]">
    <td class="indicator">
        <svg class="icon [[+published:eq=`0`:then=`unpublished`]]" viewBox="0 0 100 100">
            [[+status_progress:eq=`done`:then=`
            <use xlink:href="[[~[[*id]]? &scheme=`full`]]#status-[[+status_health:replace=`stable==done`]]"></use>
            `:else=`
            <use xlink:href="[[~[[*id]]? &scheme=`full`]]#status-[[+status_progress]]"></use>
            `]]
        </svg>
        <span class="hidden priority">
            [[+status_priority_[[+id]]]]
        </span>
    </td>
    <td class="selectable">
        <a class="edit [[+published:eq=`0`:then=`unpublished`]]" href="[[getContextSetting? &context=`web` &setting=`site_url`]]manager/?a=resource/update&id=[[+id]]" target="_blank">[[+id]]</a>
    </td>
    <td class="selectable metadata">
        <a class="level-[[+level]] [[+published:eq=`0`:then=`unpublished`]] [[+hidemenu:eq=`1`:then=`hidemenu`]]" href="[[~[[+id]]]]" target="_blank">[[+pagetitle]]</a>
        <a class="ui empty floating [[+description:eq=``:then=`red`:else=`green`]] circular label with tooltip onclick" title="Description" data-title="Description" data-content="[[+description:empty=`This field is still empty.`]]" data-variation=""></a>
        <a class="ui empty floating [[+longtitle:eq=``:then=`red`:else=`green`]] circular label with tooltip onclick" title="Longtitle" data-title="Longtitle" data-content="[[+longtitle:empty=`This field is still empty.`]]" data-variation=""></a>
    </td>
    <td class="tasks">
        <span class="ui mini list">
            [[+status_tasks_[[+id]]]]
        </span>
    </td>
    [[+status_indexation_[[+id]]:notempty=`
    <td class="indexation">
        [[+status_indexation_[[+id]]:contains=`noindex`:or:contains=`nofollow`:then=`<i class="attention icon"></i>`]]
        [[+status_indexation_[[+id]]]]
    </td>
    `]]
    <td class="owner">
        [[+content_owner:userinfo=`username`]]
    </td>
    <td class="due date">
        <span class="hidden sort">[[+planning_date_due]]</span>
        [[+planning_date_due:strtotime:date=`[[++romanesco.date_format_short]]`]]
    </td>
</tr>
[[+wrapper]]