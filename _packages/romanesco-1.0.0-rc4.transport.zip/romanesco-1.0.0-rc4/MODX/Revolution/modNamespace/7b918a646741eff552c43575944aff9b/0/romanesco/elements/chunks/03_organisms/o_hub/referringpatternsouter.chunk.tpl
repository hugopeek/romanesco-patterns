<div class="ui list">
    [[- This should really be a snippet, but my PHP skills were not sufficient at the time.

        What all these snippet calls do, is query the database tables of each element type
        and look for signs of the given pattern name.

        All migxLoopCollection calls are nested into their parent If call using the mosquito technique.
        This ensures that no database queries are being performed unless the If criteria are met.
    ]]

    [[[[If?
        &subject=`assignedTemplates`
        &operator=`inarray`
        &operand=`[[+pattern_list]]`
        &then=`getTmplvarID:toPlaceholder=`tmplvarid`? &tv=`[[+pattern_name:empty=``]]``
    ]]]]

    [[[[If?
        &subject=`assignedTemplates`
        &operator=`inarray`
        &operand=`[[+pattern_list]]`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modTemplate`
                &tpl=`assignedTemplatesRow`
                &limit=`0`
                &where=`{ "tmplvarid":"[[+tmplvarid]]" }`
                &toPlaceholder=`[[+prefix]].assigned_templates`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modTemplateVar`
                &tpl=`includedPatternsRow`
                &sortBy=`name`
                &limit=`0`
                &where=`{ "elements:LIKE":"%[[+pattern_name]]%" }`
                &toPlaceholder=`[[+prefix]].referring_tvs`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutElectronTV,patternLayoutElectronSS,patternLayoutElectronCC,patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism,patternLayoutFormula`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modChunk`
                &tpl=`includedPatternsRow`
                &sortBy=`static_file`
                &limit=`0`
                &where=`{ "snippet:LIKE":"%[[+pattern_name]]%" }`
                &toPlaceholder=`[[+prefix]].referring_chunks`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutElectronTV,patternLayoutElectronSS,patternLayoutElectronCC,patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism,patternLayoutFormula`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modSnippet`
                &tpl=`includedPatternsRow`
                &sortBy=`name`
                &limit=`0`
                &where=`{ "snippet:LIKE":"%[[+pattern_name]]%" }`
                &toPlaceholder=`[[+prefix]].referring_snippets`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutElectronTV,patternLayoutElectronSS,patternLayoutElectronCC,patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism,patternLayoutFormula`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modTemplate`
                &tpl=`includedTemplatesRow`
                &sortBy=`templatename`
                &limit=`0`
                &where=`{ "content:LIKE":"%[[+pattern_name]]%" }`
                &toPlaceholder=`[[+prefix]].referring_templates`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modResource`
                &tpl=`includedPagesRow`
                &limit=`0`
                &where=`{ "properties:LIKE":"%$[[+pattern_name]]%", "id:NOT LIKE":"[[*id]]", "published:=":"1" }`
                &toPlaceholder=`[[+prefix]].referring_pages`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutTemplate`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modResource`
                &tpl=`includedPagesRow`
                &limit=`0`
                &where=`{ "content:LIKE":"%[[+pattern_name]]%" }`
                &toPlaceholder=`[[+prefix]].referring_pages`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`eq`
        &operand=`patternLayoutBosonField`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modResource`
                &tpl=`rawID`
                &limit=`0`
                &where=`{ "properties:LIKE":"%field__:[[+pattern_id]]___settings%" }`
                &outputSeparator=`,`
                &toPlaceholder=`[[+prefix]].raw_pages`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`eq`
        &operand=`patternLayoutBosonLayout`
        &then=`
            migxLoopCollection?
                &classname=`MODX\Revolution\modResource`
                &tpl=`rawID`
                &limit=`0`
                &where=`{ "properties:LIKE":"%layout__:[[+pattern_id]]___content%" }`
                &outputSeparator=`,`
                &toPlaceholder=`[[+prefix]].raw_pages`
            `
    ]]]]

    [[- The If statements generating the raw_pages placeholder could be replaced
        by placing the where clause directly in the pdoMenu call.
    ]]

    [[[[If?
        &subject=`[[+[[+prefix]].raw_pages]]`
        &operator=`notempty`
        &then=`
            pdoMenu?
                &parents=`0`
                &context=`web,hub,global`
                &resources=`[[+[[+prefix]].raw_pages]]`
                &showHidden=`1`
                &showUnpublished=`1`
                &tplOuter=`@INLINE [[+wrapper]]`
                &tpl=`includedPagesRow`
                &toPlaceholder=`[[+prefix]].referring_pages`
            `
    ]]]]

    [[[[If?
        &subject=`[[+pattern_template]]`
        &operator=`inarray`
        &operand=`patternLayoutElectronTV,patternLayoutElectronSS,patternLayoutElectronCC,patternLayoutAtom,patternLayoutMolecule,patternLayoutOrganism,patternLayoutFormula`
        &then=`
            referringBosons:toPlaceholder=`[[+prefix]].referring_bosons`?
                &pattern=`[[+pattern_name:empty=``]]`
                &type=`[[+pattern_template]]`
            `
    ]]]]

    [[- Initially, every referring element query was controlled by a checkbox in CB.
        This proved to be very hard to maintain, so instead it's just the assigned
        templates that's being handled this way now.

        So if the Assigned Templates setting is not checked in CB, we can display
        the other elements (if set).
    ]]

    [[If:empty=`<div class="muted item"><em>[[%romanesco.patterns.not_found]]</em></div>`?
        &subject=`assignedTemplates`
        &operator=`inarray`
        &operand=`[[+pattern_list]]`
        &then=`[[+[[+prefix]].assigned_templates]]`
        &else=`
            [[+[[+prefix]].referring_tvs:empty=``]]
            [[+[[+prefix]].referring_chunks:empty=``]]
            [[+[[+prefix]].referring_snippets:empty=``]]
            [[+[[+prefix]].referring_templates:empty=``]]
            [[+[[+prefix]].referring_pages:empty=``]]
            [[+[[+prefix]].referring_bosons:empty=``]]
        `
    ]]
</div>