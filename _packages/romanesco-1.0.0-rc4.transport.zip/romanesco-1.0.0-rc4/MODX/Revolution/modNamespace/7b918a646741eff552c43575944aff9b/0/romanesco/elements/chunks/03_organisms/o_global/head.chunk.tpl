<title>[[+title_format:default=`[[++romanesco.title_format]]`]]</title>

<meta charset="[[++modx_charset]]">
<meta name="description" content="[[*description]]">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
[[[[If?
    &subject=`[[++opengraph_data]]`
    &operator=`eq`
    &operand=`1`
    &then=`$openGraphMeta`
]]]]

<base href="[[!++site_url]]">

<script>document.documentElement.className = 'js';</script>

[[- SET PLACEHOLDERS FOR CONDITIONAL STATEMENTS FURTHER DOWN THE RESOURCE ]]
[[If?
    &subject=`[[++minify_css_js]]`
    &operator=`eq`
    &operand=`1`
    &then=`.min`
    &toPlaceholder=`minify`
]]
[[If?
    &subject=`[[++critical_css]]_[[*critical_css_uri:notempty=`1`]]`
    &operator=`eq`
    &operand=`1_1`
    &then=`1`
    &toPlaceholder=`load_critical_css`
]]
[[If?
    &subject=`[[++theme_font_page]][[++theme_font_header]]`
    &operator=`notempty`
    &then=`[[++theme_font_header]][[++theme_font_page:prepend=`[[++theme_font_header:notempty=`&family=`]]`]]`
    &toPlaceholder=`load_google_fonts`
]]
[[[[If?
    &subject=`[[++cache_buster]]`
    &operator=`eq`
    &operand=`1`
    &then=`$cacheBusterPlaceholders`
]]]]
[[beforeEach?
    &input=`[[++nav_exclude_resources]]`
    &before=`-`
    &toPlaceholder=`excluded_resources`
]]

[[- PRELOAD ASSETS WITH HIGHEST PRIORITY ]]
[[[[If?
    &subject=`headPreloadLinksTheme`
    &operator=`iselement`
    &operand=`chunk`
    &then=`$headPreloadLinksTheme`
    &else=`$headPreloadLinks`
]]]]

[[- LOAD CSS ASSETS, ASYNCHRONOUS IF CRITICAL CSS IS ENABLED ]]
[[[[If?
    &subject=`[[+load_critical_css]]`
    &operator=`eq`
    &operand=`1`
    &then=`$headLoadCriticalCSS`
    &else=`$headLoadCSS`
]]]]

[[- LOAD GOOGLE FONTS ]]
[[[[If?
    &subject=`[[helloConsentFriend? &service=`googleFonts` &true=`` &false=`[[+load_google_fonts]]`]]`
    &operator=`notempty`
    &then=`$headLoadGoogleFonts`
]]]]

[[- LOAD JS ASSETS WITH DEFER, SO DOWNLOADING WILL START EARLY WITHOUT BLOCKING RENDERING ]]
[[[[If?
    &subject=`[[++romanesco.dev_mode]]`
    &operator=`eq`
    &operand=`1`
    &then=`$headLoadDevJS`
    &else=`$headLoadProductionJS`
]]]]

[[- CONTEXTUALLY LOAD SPECIFIC COMPONENTS ]]
[[[[If?
    &subject=`[[cbHasFields? &field=`[[++romanesco.cb_field_map_id]]` &then=`1`]]`
    &operator=`notempty`
    &then=`loadAssets? &component=`map``
]]]]
[[[[If?
    &subject=`[[cbHasFields? &field=`[[++romanesco.cb_field_code_id]]` &then=`1`]][[*context_key:is=`hub`:or:is=`notes`:then=`1`]][[*uri:contains=`notes/`:then=`1`]][[*content_type:is=`11`:then=`1`]]`
    &operator=`notempty`
    &then=`loadAssets? &component=`code``
]]]]
[[[[If?
    &subject=`[[*context_key]]`
    &operator=`is`
    &operand=`hub`
    &then=`loadAssets? &component=`hub``
]]]]

[[- ADDITIONAL HEAD ELEMENTS ]]
[[[[If?
    &subject=`headAdditional`
    &operator=`iselement`
    &operand=`chunk`
    &then=`$headAdditional`
]]]]
[[++head_additional]]

[[- FAVICONS ]]
[[[[++romanesco.favicon_version:notempty=`$favicons`]]]]

[[- ANALYTICS ]]
[[[[helloConsentFriend?
    &true=``
    &false=`++analytics_tracking_code`
]]]]

[[- SCHEMA.ORG STRUCTURED DATA]]
[[[[If?
    &subject=`[[++structured_data]]`
    &operator=`eq`
    &operand=`1`
    &then=`$structuredDataSite`
]]]]

[[- DENY ACCESS TO HUB CONTEXT, IF MARKED AS PRIVATE ]]
[[[[If?
    &subject=`[[++romanesco.private_backyard]]`
    &operator=`eq`
    &operand=`1`
    &then=`!checkPermissions? &context=`hub``
]]]]

[[- SET HIGHEST ACCESS LEVEL FOR LOGGED-IN USER ]]
[[!setUserAccessLevel? &toPlaceholder=`user_access_level`]]