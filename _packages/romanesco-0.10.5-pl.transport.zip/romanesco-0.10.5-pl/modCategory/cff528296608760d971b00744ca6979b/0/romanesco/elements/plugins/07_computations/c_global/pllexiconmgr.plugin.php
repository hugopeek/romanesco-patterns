<?php
$modx->controller->addLexiconTopic('romanescobackyard:manager');