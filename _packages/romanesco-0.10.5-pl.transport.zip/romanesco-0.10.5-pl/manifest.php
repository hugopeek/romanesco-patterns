<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.11
Upcoming release

Planned features:
- Add ContentBlock for creating previous / next page navigation
- Add ContentBlock for creating a button group

Fixes and improvements:
- Responsive images through srcset and picture attributes
- Apply dividing options to Overview grids too

---

## Romanesco 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '107bf6030a54f288fad0a806b379c6e5',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/eb43ed06b4037a72d35300a3b14d8a2a.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '186dd85346ea2957490bedb8da8aa44c',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/795e9b121a4878ef66f23353f7eb671b.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4e98d23748e549df77ad6a088706dd2',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/2f359c8e3dfa873fec9272ff9e29a9b6.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cd745847418c583290b633422b6495c',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/eb82667e6ff2e2d01676af0beb4f95fb.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9062445ef17ef238ddf570088591f1b9',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/65a1428ed4c96ed5479b73d90a8ad1cf.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd72067243170ed874c2aba1bac7e2917',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/2d7a88c5b3e7f0654d96e58aa7d4529c.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2119541e88030948c44a533598b55520',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/c2b7d0f4bf9b906108ebbd649a03cdee.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b37af899f4ea7451c9b81ae98f2a230c',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/f32325b4bd69ca0f9c7efe5b50bf705b.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55727b05e34f64f93684a95078b8f08e',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/f5ca833fe95b1614a36cdfcc5847b2f1.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca6c58b350c80daedec5a6df19bb7a11',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/0f13d21d24c877d585f06e25750e9331.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f0721b08194e68bad2433282dd74233',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/a3f0d432cac759ea8d8f014d118e9368.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c813e992db13dc1f473fdb93da58359b',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/c6be24274b825d319cd1d0e635c20b93.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '998a7747643ae21f3be2c1d21b415191',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/909e37c0459f260bbd2eb82c679537c7.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae3f5f1608dec0878a0640dfa9531624',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/22fa7f22fd046773f4299057a7748b7d.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d04467568a110b4966fadb847c9a7fe',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/f73dde9d4020d6b0cb5688f512d79270.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b3e9c99c0bbd2877eab6c24a5236adf',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/af8a89047a78192e9c9aaaeef5cd7e74.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68ec6b48dd1b1ba83e02cc5ac630f034',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/58c42318a78eff51f5b9176dde18ffe9.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4003177931a85ab5cf3961a33803b4a4',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/f49d20086630358b34265db4d22796b1.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81a5a86987dea7159df133caf8a0468b',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/38bbde3960f57cead596fff2366c5ad5.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd54ae5e6ea6c1f7a3a95da483292c643',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/cf30cfced22a3dc74fdc1318543b921e.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '926fa54055d599733497740c9e231c7c',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/354171ccef9f2397189ffef22d9e9d8b.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ecb56c2f765226d250845d22815536b',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/498df182c87f5bb9557ee192320c5f6c.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38623c38a2a7fe3e33808bb1f39bb6a9',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/9f040a9a346a533daba210f8f8997e77.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '361bb722bc1fd06f2e88f34792bd0c73',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/3551d3bc2c85d89baa9dab11a663de2e.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccad76a3de515cfec635391bdb573e94',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/1b61d9a669df1953af71547b2d073754.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f6ec6598c9ab65c9bfb3b783c0e723e',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/a639033ae676c07cb5dba04f1b922837.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a4b634601d808ac8d9de18545a73a9f',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/1b7c53c3ca7bdb6eaa4d392d7b71966b.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f516c84d19711e3c758e811a224b0a3a',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/a8f816fbdf3fb563780f38e45f28d209.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79415c7a9812212b92377d223104356f',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/e2ce420c802e73aa87cad26caf5e792b.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b786ead4dfab985effdfdbb29f872085',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/fe120e3ee2be6875f655901f3c29b3d4.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99c31ff63cc36b78065cf3dcd27bd0c5',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/52b3bf8e996123a26e6b2a7c992c7d58.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ba767582eb622c3386bb3104af63bbb',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/3a1728c8c002dae0101c8816eb87e646.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1923ccda3b0b2a961f54474727562c5b',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/e252134e8462a7db8f96fd12d505f32c.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e62ee61d06df45a198a540f60de749b',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/783598e655406a73c16f6360b9789cc9.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e6ceafbd42516f99abb575b71a253b6',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/0202da33feeffc2473de3af3e4a01611.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9631c96059a9ed9ab02e9429acaa989f',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/66df492b2f1a756b641a3f3b23027a7a.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4de84f8b4fe5253612afb434ce27203e',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/3938569b8de705e6c932d9076525179c.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd598bd6ccbbdd11de0286516fb7899d',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/e05ffbd3456758c5959a8a823128d001.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83b8f97eda2b51eafb932600c219a0ec',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/43457cd69c676cf4acacfc18dccda08d.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c448871188432e53101ec8a52b0bad7d',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/3ec5721bed9f1b1f2ddadae695037b4b.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6f64a87a6a1af568e80e79e252cb2a3b',
      'native_key' => NULL,
      'filename' => 'modCategory/cff528296608760d971b00744ca6979b.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);