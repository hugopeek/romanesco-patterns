<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ba5fb951bc36fff12f60ae28e5c03979',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/cbda975cddf669f7324ee68005bd0272.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4621cdf50fc51f3c01bb8c2d45e97473',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/2eb0dfd51d8f459fb07d86935de3c432.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '427d507ed3cc8a82376f9b27b1c6f6c9',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/216d18734b47e16d96c24c02272cd749.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb95104f7dc2f8a58ea18816b3ada9ba',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/07fe87026f3fa7e388df7e69bfc43f0c.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '222c7a360dc859f0edf32bf6a6b2c2d2',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/a6453498186a42436876516bc3b40ff7.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '445825c478c5ed90821f8437df5c592e',
      'native_key' => NULL,
      'filename' => 'modCategory/c3488844fbf4f1b230b1de985b85128a.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);