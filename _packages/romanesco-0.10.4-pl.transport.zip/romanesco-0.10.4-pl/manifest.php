<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.11
Upcoming release

New features:
- Add ContentBlock for creating previous / next page navigation
- Add ContentBlock for creating a button group

Fixes and improvements:
- Responsive images through srcset and picture attributes
- Apply dividing options to Overview grids too

---

## Romanesco 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0d63ca35adf6bc770cc03b7231bd3dfa',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/042e7b84fcc7bdf637858e3bb4684604.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1db6de20c1ca88d960da6d1c7eb7db01',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/987b57a4aa2762d403227054d3696d33.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954b9a948f83496973f935c39f551a7a',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/571f2d35ae2fa4eb282c65375773cf63.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4059763887fd2382a071976213c2d305',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/d034f312f305171e00d7c35425b04aa4.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50b951955e708bbd9868b084042cb89d',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/59d3aab3d43e1a7f55da8234e678ebf9.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30db224a53adae06f89a8bee8bdd6362',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/7dd396e977815b982d82e30d8e369bea.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ea5e30d6d130aea68670093c0393bb4',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/530abc9c48d199af78f668b80ce37d58.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a31ff1ec647829d9b274bff5216462c9',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/41d998c0b9dc443acd39bc05dd61ebbd.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbdd07d9ffdbe6cac194e5fefa61d448',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/a1ef963ac3969cbc5886866ff2f7483a.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35be44dcd8a1a6ff77b8615f48d3548a',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/5614adcbeaae416f6413dfff6929c5a7.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9519268de8e13598abaf608fc4d06765',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/554d23f8f48b87d2b90d46e53d6ce767.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20f0965d58adf975dd55b8f7081b5cbf',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/ea915c6d9ad651c9d18037b2dc209f2e.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f39e000e68c09cbfe179c3efe547e71c',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/dfc852d4f1637c1c9073d3e5391918a4.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60634899a2b18d0ba5f92793cd20807e',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/72144c48665f65e2d8998fea9665ef97.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf4b3c4e4f75b00461507924990aa778',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/22689d1b8924cde70bd48f88bc8adb83.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89b30fe67b4b3abba24dbd3808056a01',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/a279b6dd5cfbc02a6e1ace7706c960c0.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8a4cd1e3cb7ea7cdac13809370d1991',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/f6de7fbe085e45a8d41eb78d0fc33cfb.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14420c35d78495b2b500c00174c06d21',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/4a15679a6ebd4abc11a151ddb71bca25.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bca13928c7083c2d969de1a466fb65da',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/278054b8119c328b5dcfbd98e9f496c8.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cf39c1e0e836baa05807df39de4096d',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/b25ae1529d1155aa96e27a79d87d7347.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97709614bf7a1ec78a478f33d1420bcd',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/11d29604a9eb9ef881533e0767295bd9.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69176907437b9ec8efb0b49af49beed0',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/73d5d15602896e5a59db16797694e1f5.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb2a0bb016e4079e7f6fc1c28b837b8',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/a78c96d7851df214f58cee7341953d5d.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0801fb88975141c76d10ff7c0ad14ca1',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/9cbe767087fa59ad72c2bf399997e4ec.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7796a551dc02603030f34738cdca62c',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/e1dae385d7cfd6a12dfac3794f107e8f.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3aec0c17d406616f969d24f14f81d88',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/9510b8250f76ffea96a0136f0a625eea.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '717e43b5e212041b2b00e80004808a1e',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/c0dd2c0fa07976e2dd61688c8b50dd76.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7addd5b92de1d5bd388da16a4842309a',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/db9985e7188a8d6f3ff6ff40f6cda952.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c9236e0469fc6d491900dc14f0f231',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/b7050ff3d87d4fc23f992c5e57175d0a.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78b3972f5624be92a3f2d298eb2d784f',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/e352f0f6c034ff717be9e1f86449c381.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7825d16d3ac8e57923e6b62aee3df13b',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/3646a06633468cd999e9ad584ba45bc7.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ee04fe13e9e7b21b3c41bdfb98307f',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/ef5bc7f31771ded49a1e4b720472a839.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bf2112523bf1531d5c192a58a3fdc39',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/fba140ea6dcf6ea03059b9836a0b11e6.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2753cfe737a68695bde096624319a0bb',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/3948fe271fa213e86595d0909ba26324.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16399c2a893e3b8ddb518e6e1424204c',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/9753944ad03362da60cdb1deda4eb745.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af11e5f02664637f1c8be6545d40be2',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/c8e77048e4733b99bf499d01ca5dfe63.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a626213013b9497f99c7ad2492e943',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/42a5add3ac4792fcdb96d5a543a0dea8.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7bb2ad265c0444ad25423a6f3ba9af0f',
      'native_key' => NULL,
      'filename' => 'modCategory/752e355c126df90ea22b58b365bd82d7.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);