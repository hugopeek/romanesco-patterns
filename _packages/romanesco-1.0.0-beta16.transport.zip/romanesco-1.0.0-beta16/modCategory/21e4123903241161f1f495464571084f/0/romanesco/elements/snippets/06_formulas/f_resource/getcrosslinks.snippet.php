<?php
/**
 * getCrossLinks
 *
 * @var modX $modx
 * @var array $scriptProperties
 * @var string $input
 * @var string $options
 */

// @todo: get them!