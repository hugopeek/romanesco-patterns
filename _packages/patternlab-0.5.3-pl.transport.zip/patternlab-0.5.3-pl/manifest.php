<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cd3bae255c2cb37a2665b9fe6d0ad8cd',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/2015ad0cbaf07dddc512b9ef5287d27d.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c95f81994f320a24beba3d2c0be091',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/12cc730322f4eb600ba3f6c382f3c058.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f24498adb45d1e497a2eb9f5ed839fc6',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/144d4cecaadd4af161c5dd6d471bba58.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2463f62b38fe87debbe5b575cf09fa9',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/86fb9ff700e80465050de44d004cd7c0.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f923b9221f4a10728b2d10e26efd75bd',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/493174b4c6bd138bb6213f2a75abf3d4.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c6617167a03ca789b3e2b274f0484fb',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/6757d04034d3a9134b0c56996d03bd67.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c54ce23e6c7d234a320b1b1ea99f9266',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/c3466d6b91b725a9918b7d04e1410b87.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35606657f3c21969b9202a6fc76b8ca7',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/d3ced328205d1174aeaea3f87277c7c4.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473698c6ee355e4504c738b269574cc8',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/88c52e04242a8b4ffdc502f9621aa7e4.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a120865b5dcea6bc6b85e1e1e7701ea4',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/87c4605552301bf6ccdcb309dfd53ada.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1f1c6c89d2482f155d2309a2562e8f7',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/e04004850769510b792bdffeaa941b29.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be061adc608ae62ef1bc7e236299758e',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/81fc04fcaa084bcb9f3c1f52623e38f4.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f543da224e736ebd57cfc9e609038f9',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/1796ea4c394321fbbe87acdaadc88ed9.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24a52f346385a40b881f05fcaec312cd',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/bde114211d6f65398601bef079d11ff2.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a55000600de60e628f4f74e2c53ceb1',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/07ba8122db54ff395eaaa562e1a12131.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86acaa55c188bbd7c85712b205fbc3e9',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/34e08726aa03762a32aaf291bfd707d6.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aaad0cdc004fa62b2d6df41b5517eba',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/f8641a4b993d486b76783c2aa0d7f593.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65b130c692a70adf24d94e93284586f9',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/6358b0006e7d256eb38f3e8f058654d2.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f14d540b16dd9076215b35e21f9f7dbf',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/206971ecf5ced545f9463f97c2cc2f78.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e68d9d7d12219c768678dd4487493f9',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/07190a161b6af99ea3c46a0c2596fabe.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aa89533386a27a394ed40d14519701a',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/8914ebffbce279ff4b914f53881f7ace.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '163ac1ce2d21efb01c172a9c42f9692c',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/10ab51e6cd408700433054635fe52c06.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3208b50b88241f2d593a5a833c8a109e',
      'native_key' => NULL,
      'filename' => 'modCategory/27c34cdeadd73ff0dbdb7c0a9febe098.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);