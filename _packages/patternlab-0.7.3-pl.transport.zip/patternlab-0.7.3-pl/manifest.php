<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '892a4fb0e6f03c557f41249246ff52de',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/36fd05ba848f3fc6d222f89815dbc90e.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '490cceec954dd91edb45b30d70a193e8',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/f1472502ee8ca56b2a8bcbccbb344a08.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d0d1ba8f31dd4c3ac90125af9cde907',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/c72dc2cc40b3f20d0b4152867737f395.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6979ce027cc0ac3a6d8629302535dad',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/4eb65c56012a48aaad8ce8f385f0e03d.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '854646133e36ef8e330c5ca497c18e09',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/0d58fcd0c7ba17a1cc2ebafe9918f1d8.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e401d3ca698e26c434cd8522a7456ae',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/3f14566c407f9458a41fe37a4cf055c0.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0befbabbc5dec60b5f72fecbe80c8892',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/cf971e989fb505f32091a087b8b22005.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75754643dcd57ee3b9eb4fa7dfa73b88',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/ee81574d086179e1bef399d4bb2820da.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6263a7511ed22852398578eb8131b449',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/00d01c45fe4076ba287c4c3560bb5038.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33b53dea398ee53c7a64ca359199b242',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/9eafab6ebba3a0fea2315456b7579510.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e8570d83d003a8cc2dc508bb351c06d',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/d70b2189411c713ff1fbd472456596ca.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6546f99f94493b551659c45ba3d487f',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/cf8e5ba64ee2fadbb57c77e8d14234e7.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f985f87219c09ea7d2f5b26d970b849',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/83b45231eda54e0040a85f380460191b.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f1219caf3f6c788970ff6f0add4ddf0',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/f4b7e0ee5cbfb671673f7a57b32b13e8.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ef485bfa3676e943132ebcd0fafc43d',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/7299aac843f31ed2312a58c99b18b296.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dc598a08bc63a775740ec0610f07cd7',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/99ce0514d79e7d276e40a2fe01baaa05.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b976f830e9db2585115b5791cdc08146',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/616b28a6e590aad295473701d67e9085.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '293e89a8256dffe543ceade4c64f6728',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/e9853f1c8ddeb91d54e023ef68f07eee.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '823a8963cfcfa45fa66d47c71f580c70',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/33c208b059cedae9ff7d5030bd804727.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46fbd331a668f1c6c3e07e5097a1d0a3',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/4636cbc7870a9885ac60220e15f70d84.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cdb9ef8e0e17f17c9296fda80353adb',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/5c9f54891114800b5e39a8983a095a6f.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0644f0f4596d53bfb24f4766403fe160',
      'native_key' => 'patternlab.publication_container_id',
      'filename' => 'modSystemSetting/69a65285a14baadcd823dfce4f8c1516.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b24c55d57dbd9ce246d78f47753a6b3c',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/aaa73a2d700f4d5daffe6ddd0e76d5f2.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd92f497e134af65038bc6ac57f7c887',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/31a28b5a643a2299f40453d4c2d1c67e.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '059747443d3d33f9e43188103cf8e912',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/69dec603afe3ed04394170ec51163b34.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01f99746ec5432af51392dffd1ca71eb',
      'native_key' => 'patternlab.social_twitter',
      'filename' => 'modSystemSetting/6a77820cddf50af19395860dd9398c4d.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1505ee76ccfe20c088488b1ed6cbba',
      'native_key' => 'patternlab.twitter_consumer_key',
      'filename' => 'modSystemSetting/b7995e4fa4fbbeefa01b61ed4e8bcb6b.vehicle',
      'namespace' => 'patternlab',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '944eb1e18afdae7c12a90ab231e97f4f',
      'native_key' => 'patternlab.twitter_consumer_secret',
      'filename' => 'modSystemSetting/4364e15c933e69bbd2fe16df69d47b42.vehicle',
      'namespace' => 'patternlab',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67d6cc045e6d318cd52e5fd1f2c67dfd',
      'native_key' => 'patternlab.twitter_access_token',
      'filename' => 'modSystemSetting/a8ff905c2c05a119837c719ac23c0c46.vehicle',
      'namespace' => 'patternlab',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a18d2e25d0dc270bb415aad2fade814f',
      'native_key' => 'patternlab.twitter_access_token_secret',
      'filename' => 'modSystemSetting/5638f8329e551f3d0a191a7c759c4e07.vehicle',
      'namespace' => 'patternlab',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '670efdb442ef8679c1da5cabad93d5db',
      'native_key' => NULL,
      'filename' => 'modCategory/a9d8780468edfa5387eeab34b87f4c55.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);