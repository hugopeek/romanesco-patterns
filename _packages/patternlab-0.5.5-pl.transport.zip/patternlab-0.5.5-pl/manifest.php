<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9795591f8ef88cece380b8eb929dcb8f',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/f6b292123f69935873ec09f6ea9a6009.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a3adf5a0032754ddccd591ede7b5a7d',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/83b4512c7cb3e3b79ff7dd890ea5be47.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6288f4e729bf1bdeb6f9a2678c16106',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/96d44d669030d962551a95b4b54e17ed.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7600e352c812dbdb0f699bc31f44d233',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/001726e281e590f13df29ea1b1b3e64e.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b59bb7f5d9a754b4a8b0f1ae40c47a9',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/f8f89aff597727230d82c5edb14ba64b.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64b5eb045853de5832cb661a95b4434a',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/311cc38735be392a47508d85171c3d15.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36445c0d02e74aeab804e77fd39d585a',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/903a74207241a988a04192a9c0b07816.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b5bfcc5668e4721d12882e0ac6f4170',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/436bc08e7a63fdf5c41e70e4cd80b1a4.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e1b3416648765683f89f40d3bda1f33',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/6a6bd8da503d8658178d9022dcf7401b.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b56d6bb6c6403b81f05713d3c0cde4d7',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/61b5a44c202f45ea568c8a3f0564ca88.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae578e793e95ac58e882fba6ea41f9f',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/20d7a6ae1b265d54c516787867f4002d.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aad5d7c590a6423526a842dc5c99539',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/6d9850608cf39c7fdefd3afbbe9bb12d.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74295c43569d1615eb1a8b7eec9f1e33',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/3a3a7e0541b55480c386f6c158c94aef.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a48fe6cb865ac421ed6822e5dd9a6b2',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/76917025a942e660cd2bd891339f38b1.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6dd9830865b38da0b0c32c63457fd33',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/495ba7c73db20ae14eae674bb653811c.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a2cb039ee7843c7ab4aa6a2a03859a2',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/5828590331915e25c7327aec02e2235d.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '018e087d5832e86ae7df93da090d05bd',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/27b96ec8daccba1bdd96323f47b05ad6.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f015805f94ab8f3aa4b3b51f506cb16',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/deebea1d5d984cf155a285881efc6eaf.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3711d31f4f824fe7660da0bd9ccb60e',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/78c4dee9b709e67592e59336ac49d1ca.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddd6591132f9ad54246c1811239225e9',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/83f07dbe6a1706d4b2c912629071f027.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c3659048d14b397b5ab8bc291527ad4',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/1aad888045d3347602be84f46de9ab11.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b923f4bf88054648281a81e160f9bc5',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/16c870ded780007de9bb39bc3c907bc4.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb03738a7e70e5982ede31294a59cba',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/bdbc92fcf5b7867196770214f003dd21.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b5ad2755972d5a23ce3ec799ebdb7e29',
      'native_key' => NULL,
      'filename' => 'modCategory/ac2e086372a9717022ae62da13fd5265.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);