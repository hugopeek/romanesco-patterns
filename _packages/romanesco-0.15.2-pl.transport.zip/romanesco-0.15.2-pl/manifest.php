<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7a42b5a1477399c4701ff3d65bf7332a',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/abb976bc4517306cfa4dd141d5c6244a.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29d1822b9f16f0c6e270aebb3754d320',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/261b749ced8268e3e2567ac2b8c23c90.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5b3e42bce647dcd958e6c8d08988528',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/67a730790c900907f3cca3b441f787fc.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd1d9eb029e5ef9e77b6c7d9e6cb3f3e',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/4c9c660cdc8e085ab6386360f468f87d.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '933e7c21f1b372ac966d0de5553bf195',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/b6acbced6476dbf9deb1ac56fe20e1c4.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7240e8b91bd82ef17ddb9a164deeac1',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/01fefda4b8341961ed195ca78eb80be2.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31dadee924ec06995af92b2163d55f51',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/bea07a62d62a408ed77ffb50e7e72add.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a9b9cb207fc9088cbb08f4ea4ebadff',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/5031f8d53a6b30d00f02e76e4b132463.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d4532689539643f126d1f481c88bfc2',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/cc70880a38071418d191a062ea380179.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '385336680348d1f7a9519a1a2fb5c5e7',
      'native_key' => 'romanesco.title_format',
      'filename' => 'modSystemSetting/02cc94a4da980d534fd6607fd8b62c7f.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7bccedb27bf991004d793e6521ef710',
      'native_key' => 'romanesco.custom_css_per_context',
      'filename' => 'modSystemSetting/dd8b54740471f00e3095a6db1fc30a54.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc1d222672ee0513cc59a22c9f1719d3',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/8bfb15a96c781c29db75d29f9578eea8.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8212caee51cbe40fed0d78c693a4034b',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/714124b7638972b4d4311b383d0bbd19.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dca08f1aa0697a220e54504325a45437',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/90132df3db1d3859813c2a5334423e94.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a8d8ced86c683a9a63dd25a8f5937b4',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/12fe3ad4d342ae6acc3e1ec1c6bd5534.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72c48f4a79a6996686b775e68b5b2120',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/7fc12dce68be0c3150b4d366d3b4c7da.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4646606e78ba7bdba0e3ee50119305b9',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/2399d0e02b22bb4e008e81f848bbc26a.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e9c75adf18e2caab1dfe85b4dbedd51',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/8baf3ca0f2575c8aae5dbb8ae71b495a.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9802b31b25b8f2a3c5185d632e2eb631',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/96cbb6bf2e3873669d12e5ea174cafc1.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3582c24ee54f7118f270fd3f24ce3d4',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/d5962adb41405e661b8ed4a3154b9f02.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a136856cdb2f66c023158c79d116b9f5',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/ea004a7cfba03edf922a8898cf75c714.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a900cc7e758223a433c32833aa56318a',
      'native_key' => 'romanesco.mapbox_username',
      'filename' => 'modSystemSetting/26dde0e4d9e5d5c6f9b17ed83e3f2dd7.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5bcbf47a2336db52d00bff779ba7c88',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/132a25ade0da489bb7fb503b64f98362.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fb34de07648cee2847162a88e14ac42',
      'native_key' => 'romanesco.mapbox_style_id',
      'filename' => 'modSystemSetting/45376e7dcf15bf6506952d03681e8cff.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '677f64d37cf88348367b8c7210471e45',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/0e3306923796c091384e40738aa524a8.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5059dc5e2c57f48f4a5a66bca71d15a0',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/2f0ae4816be34c5440fb38d99d1cabf6.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c140668819e95fe5cf8b391a1a2673b1',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/21d9fbe72637e746b35f3aeb9b40572e.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9386533f8930ffc00c71312860850619',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/647e46a657c0f51b53105bbf75c729a6.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a03f965ff5e567f5a2cb3a52a5db6760',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/16dc09df4875e029b0661686d387b4b4.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f837e7d18daa6da0649a0228d09cd97',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/ec8be86c9f49addb73d3163d9e30e1ee.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '173639163561b6739925f4fb75ea430c',
      'native_key' => 'romanesco.assets_version_css',
      'filename' => 'modSystemSetting/e2a9ef2650895edd75e0feeff080ffac.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14b9d25e4bb74a80bcb5d3411e351e92',
      'native_key' => 'romanesco.assets_version_js',
      'filename' => 'modSystemSetting/6955f71534d767a1ad9a8e9aeae408d6.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8408ba3d97c65ad420469540addfb7a7',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/e4fcd77e5243f376ac7c330d58f79c6d.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5871d64445a0d4d71e62ccddd12d4b23',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/3c21a21f88e33a6f0c0912f60a91aadc.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3ec3f989044ca67cdef5cc59cd441c1',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/c0926d7f0230a88e23a18bd3f0ca679d.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b4526765ac947171c1d1d853353f2d',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/b25c3da66d6e745047323421050fe779.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81106214e484225861b721d1a61c3ab2',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/0e27944d87587863c36a9859ed4bf1ce.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cad9ab96ff4686c5f5b1891919fe022',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/515cecb2cf67879e77fc7c49b8ca8e6f.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0169cdcb4c70e29446d98a5ed68d3f4',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/d1348766aff7c82a88be1ddb28b98fa1.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f41f5e04d970a9a2028722621e5017d',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/1de43a55cd4a71ea38edc9a838359f13.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4e2aee536627092a91f63630ac7ab54',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/02d081b0a33dfa11814190f921659748.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0ccbf160afadd71648522f442192992',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/73521285153c2efeeba5fec4318909f0.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4778a67ab291a29ab33e4d67691cdb0',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/62a5622814ce0ce769606da86e04ebbb.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97770744ddbe220081d88410e3d3e7f2',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/704fe26047bcc2bb17d2e93712eeec2f.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adb69fcbc802934697b921e21fb51206',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/879884f9102ee6be6e49a1640ea8b334.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66cdaa72fd8d0b5f03877bafcccae017',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/6a9f0681859dc92c42893795061af7ae.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19c449197e279581c642b74fb4ae0769',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/3eb19a9e657eb50fc2ed226e6e60fa94.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6fca46d6f18108e61ccb015879d008f',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/ac6c84132cc38ceeacef5b4d8c159ec1.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3eb46048a2233774b3ca92364f0100a6',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/2d9150c5a486528f23bd783886ab97b9.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58217edca78cce81247dce968ab6ac14',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/3cfa016cb34d1524cfd9a47368303d47.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bdabc0a652187f53ad713927c64c169',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/868633b72390f0b523980913cee827fb.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12b40f7123e93542d23a833396cc831',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/567df301638c0a36e95bc0b6c2b03286.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '935a3c9e474b5f7138de107a1bdc47d3',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/efc8a21eedc01cfacd068eb3579b51b4.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92161dbab4e3b99dcf298766ad102e63',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/ee0041d524118630205d79a367f98510.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19cf6e82f603894270769c1d654add13',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/686b9156bb786647dc1f1b5084384f04.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f11a1b7c90ec80d7954edc6a97bc782',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/01c7ecda9121eaa85c6ab61a0477d282.vehicle',
      'namespace' => 'romanesco',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32587ef5cdaa9c0cdc9eae3d70a33d9e',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/497f5b48cc4f01587a1cd12c650ea297.vehicle',
      'namespace' => 'romanesco',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fc7fc18c7e80a65b561814394824e24',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/429058373811507994262822c6278bef.vehicle',
      'namespace' => 'romanesco',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec00985c80999aeab7acbcafd09cc577',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/a7b776b07b0fc1c7560cd4dacccff3bd.vehicle',
      'namespace' => 'romanesco',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3187ed8961afd8d25679c264aa34dc0c',
      'native_key' => 'formblocks.cb_input_date_id',
      'filename' => 'modSystemSetting/307441cc76cd54f3e67cb7c44c91070d.vehicle',
      'namespace' => 'romanesco',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be00e57efcd93634ddcde3e19ad01a55',
      'native_key' => 'formblocks.cb_input_date_range_id',
      'filename' => 'modSystemSetting/8f0b1629c5e8dbcd91e6ba02281d7e2d.vehicle',
      'namespace' => 'romanesco',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe4a0b793a0ec7105fad99f9a78a1a2c',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/79eee0a26e91ee5d67cab382308e6756.vehicle',
      'namespace' => 'romanesco',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b3e331ba29f789fcc34cc2b58ace9f',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/84bd61c687413ea65229ee1f008ef263.vehicle',
      'namespace' => 'romanesco',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0d027cc0a7db2a81cba46aded591f7af',
      'native_key' => NULL,
      'filename' => 'modCategory/b66cfdf672fe78a95e9ba82543de16b3.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);