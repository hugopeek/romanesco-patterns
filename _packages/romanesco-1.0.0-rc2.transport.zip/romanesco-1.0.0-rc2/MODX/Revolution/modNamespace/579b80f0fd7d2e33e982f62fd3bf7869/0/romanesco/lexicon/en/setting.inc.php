<?php

// System settings

$_lang['setting_romanesco.dev_mode'] = 'Developer mode';

$_lang['setting_romanesco.cb_hide_fields'] = 'Hide ContentBlocks fields';
$_lang['setting_romanesco.cb_hide_fields_desc'] = 'Comma separated list of fields (IDs) to hide in ContentBlocks. Note that this only hides the field in the Add Content modal. Fields already added to the content area remain unaffected.';
$_lang['setting_romanesco.cb_hide_settings'] = 'Hide ContentBlocks settings';
$_lang['setting_romanesco.cb_hide_settings_desc'] = 'Comma separated list of field settings (references) to hide in ContentBlocks modals. Note that defaults are still applied and changes can still be made in environments with this setting switched on.';
