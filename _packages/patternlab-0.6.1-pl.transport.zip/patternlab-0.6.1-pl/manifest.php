<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3cb4eb9e9e60d2c786a7c2f7be22e502',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/7fd1950589eef18e11c5fe5895f10d51.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97f8cdd1a6bd77a37d4c1f83c2adbcc0',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/217204871feed6ca4a9fcc78a46ad577.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4186306c45c7f7ee21e643453fb73ec',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/9de712c1547f9120879672d678f53a9e.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aac9e9658087d6978f55b71103cfd81',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/6af6717604fcd2177a85cd17540b9b17.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de00f6e3a455032c95129f7dc80c7414',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/3b88b81a51dd30afe10220d27ccf4141.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52189af356cc6295eff33c0dcd3074b',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/9d230373c13bc33f0e56db4e1793c6b2.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ac04741ef05191cf9d8cfedea71a510',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/ed083b8b8e2d4617e8d05d29d7ecc2d8.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '735be424fd1025a9057a4a9ffb419fea',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/58d79f63947d14acc697ad6f08283473.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f3afb1636159d84eb1eacadb62ec611',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/d96abcf76e29a655707a4ba6be6c4cd9.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c16cf2b8725ad874946747548009f7e1',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/4199a6e11c8989b04a041cc7a1a34921.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3e5f6894e5eaf191d7ac359f0306799',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/0c72e54f71549efac5c8ac7adc6dbfc6.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccd66f970e17638e2df6d6ce7de24afa',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/c38c5acee04d4d33402f2c244b31a851.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dacbff9664979923bb46681bb65af0d',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/5a5a1ce77d5f8fe440fa4eb28088ead6.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '397ceea51a1eb34a6362f6b84f01bd48',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/c1a5a7660708cd3d70dcb748312eb6b9.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ee9c9735890df7ec2738f89fc098dab',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/c5b5440ba8c46d05e9396290dacd2589.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '507fee9d45d0b8011d621f097468f580',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/7bae795bfc0053b9e328d939a84c6b69.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05ffa6e84242918137a4728cb5f05310',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/a9abeb7ec3f5d3624ddf708819a6585a.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2264bca459afc5e60f8551ef727c4883',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/328ee03fcab3a6964041291f5aa4a128.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cc5eb4aa5cccfe25ce7d62f7edaa550',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/8d0f8733a0775dbb64f3013ca0626fb6.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dda0f4534b4fdf12e55c4c53c0d3793f',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/f37f93036c0c0cdf69d3eeb2d632930c.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf28f7cb2ff9c5bd660545bc922036c7',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/905f180ca6614eda982e38d11f2056b2.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33f20787bdd86585b0c633e8806ed4c1',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/991194801a0f99576127e47e96b9afc7.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '441ff276d72023613507fe106fbee94c',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/840b1251a6be948184909abf82a15497.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '325b3f1a98d83d348023c21ca287641c',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/25fc8965f80c0f306e4ed1ec00743ebb.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ec20f3e4fc70f7799bab422890f353d',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/33ea7385b2a35de295d23aa71a937b4b.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78edaa1e8a47c025f68ce6d1904df7c5',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/094c16699293847548c869f71fdcdcbc.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f3d37c95f44cf27cdc3274c8be923e1',
      'native_key' => 'patternlab.social_twitter',
      'filename' => 'modSystemSetting/fac63edfa88445c21127f595b4b96c27.vehicle',
      'namespace' => 'patternlab',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8794fe41f0d7b23c7bbbd58fb5346074',
      'native_key' => 'patternlab.twitter_consumer_key',
      'filename' => 'modSystemSetting/5eb6922a9657bc8df1e60859c20e6830.vehicle',
      'namespace' => 'patternlab',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0e58b475bcfc8da34e0367db9f8e69b',
      'native_key' => 'patternlab.twitter_consumer_secret',
      'filename' => 'modSystemSetting/ef89a2d3004448729cc90c806eed44fe.vehicle',
      'namespace' => 'patternlab',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36ea6c7149c06c82c3ab7cdf24f900e6',
      'native_key' => 'patternlab.twitter_access_token',
      'filename' => 'modSystemSetting/538bd9d32f6ed06eb720513685f4e855.vehicle',
      'namespace' => 'patternlab',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2618ac9ad5e3cc9ab10e2d250ea60b0b',
      'native_key' => 'patternlab.twitter_access_token_secret',
      'filename' => 'modSystemSetting/592894957256e8c459de800596e411f0.vehicle',
      'namespace' => 'patternlab',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '89983a12c0172ce6f933a3683fce259a',
      'native_key' => NULL,
      'filename' => 'modCategory/3310cbb34e78224c1adda9ec460ea4b4.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);