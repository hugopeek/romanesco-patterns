<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (require login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '135fb1fa7d5886e309e192c69022ef47',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/66269b4336e95d66e7e221afe0362bd9.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b65728383e4266567a937f16a4301d88',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/a29365bea748874c92760c8c5b72668b.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82e647dddbac5fc0948e372c9d2301fe',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/a72b1d1e9f20430d678a5835e2795e59.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '335825d1ea47458d734ceb7957a26a6e',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/3571cc0fc121daee2f425f6ab34fc86a.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad6d5f3beda4c87e568e11a8f6b45c69',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/9ab84d3f693e291a6582db22a563c6f8.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e350f1c6f03808d71fe37474544fa8c7',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/879e933edbaee9439b3f919b0fd7b881.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d23ff92144a7b1808d52380c80a9947',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/d10c5d69904fef956217286df51f4667.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33f13d63b2a11b3146681df81d10ff45',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/6a14b2a45f1ea3796969b8173e455190.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c646983dc399186a42ac0a1bc6d1e3b',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/efa2c7eb85928f4cce622a9b7bd0ddac.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0668135702c6d7c84ffae098d5ab781',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/1c3db4807eac305a07ee2782793d9cf0.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89dbcbd6216f53742ab9976791cdcf75',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/b263c20fe07633ba1522d91f88c01296.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1da1905a68630d0b8c9ea4c9b4ffe23',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/42fe159f8fa84650ab67f03ca7df5f9d.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d379d48dc2b9e9ebfc598a3fdd4c5b',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/ba2f7b4a1f4839b37cfd138b4f1492c6.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a79ae797b73246ae292d3c9e1d924f39',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/4b40ab700a410a64e19acbebea9d098b.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5db2dbddb57dd3fc618d597004e4aeb9',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/f5363bc75ec062b69211636ee5ca874b.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5178ae5c68b1550e9a26de8dadc2874f',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/201b28199a25f57af96f5d5d634afb35.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b18c51004a6fdf040b3dd1a92aae5d88',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/a945209a17e319dd9b830529d86b63a4.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf70ffdab0f4be854cd8d9f322a8df3d',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/16f591ddef0ec43d940575c9a279e0a2.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '741585a42f539997e59ebf40184f496d',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/b213c021873ace872d410ae617af8cb4.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95b5d53733755991f5d887dc8054321e',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/a682b1ef4c53afbb3998e6610c3d1da3.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b3228ce7fc4b35cb53ae2d4ca05f3ec',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/06324eaeac4b545f6a545f4c1a2b7178.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f93dae2654fecbbf448b94103a0083a',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/087557f22c74d6a3a0de20967318026c.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b68faa00b69d9ad06ead6a9b3e52f738',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/1d0e22505690d924982924dd7b112fa8.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd76ebac3ae568967d8bc7557848249ab',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/f0ab54dfb51edafc52dd72e9bf806907.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '825ca770318d1b0c55dba4cb822b16c0',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/a339468b0c4e6c40badf4f180510e64d.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b126066e15ee395b3b49f5c85d657b9',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/630c6325628d332a5ca50c18ff1439ac.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd0dc6d80d357852dfefe4fdb961bd2c',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/d66ba6044f668b28201cda83c93a4fd4.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8eeb0b6776d183ac4e3ee08e583edb9',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/e5965af52ebddcac8ff98d3188a984d9.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae92f5b2709906486f30ac35f7506230',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/204b14474f4f1c52f70c8669517ddac6.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a370dbafa76c33576dc4ed88849712',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/1b48a5b2953520485bf506b040819608.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd0f16886a65026ecd9cafb7d990ba5',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/4f4b4218828ee24a5b0af49047a5e6fb.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60e771359f3494ba026a97486c81a63f',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/5f8dffd82909b7013cc6e4d105ddd32c.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be00c88710acdebc62fcf8f72715847c',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/63bb2b1b418eda9bf420b5530a7bdeec.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c96de57b21b0ae27cfc6e1a21605a1f',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/a81d9b2c6593e52b82b0f1f0a5e9bf65.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '762708f077b8d28991b4b15803b9534d',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/491061fde2a78ee99c0afbf44bad151f.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '302213eb284e0380404756a12bb29ed0',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/a1ddb50d89a1ad4d91d85e4e7abbe77b.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd078bff0d3b8c58bab35a0a13480cbc',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/8ba825800c398ffbffe8231555178978.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae89eaf474d6e6142d3b373e4703611b',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/eb619080ecea543b517a3f4e7bc08cc4.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '964f018171c60ba015ba0153ed470d6b',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/c71d2c645fc1b228c5220ef8d3102947.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98a5dc4e92938ec57443bced30e1dfac',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/63caf8ffea000a59ba22bd06bcf719f9.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2efe56c1608e44651230f70d81747eb3',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/d80a3ea82639eed4e80917a970260c33.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '811a03744c1815ea6d8d0dd6fafeff07',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/217912414baa6aa48923f256da44e45c.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9875d6b050e419540d32bf053dcd1147',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/974cba7d125f0c5e600a8861590d65fb.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7cbdec0f222a7db638e3200d4cb496',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/659e7440093adc218e07d19cbe37c438.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25e6404982e3542c0f79da24adae391c',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/b54eb36e35abd09770b78ac2b153e4f1.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52beb4b342dbeed3ff52076dfbad5e0f',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/1010bcaf4d4f7625aa2bd5ed4b67e3ed.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '89533fbb95c988baebe81f541c836df2',
      'native_key' => NULL,
      'filename' => 'modCategory/ea13b0669d00c032b700a0ccbeee2cbf.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);