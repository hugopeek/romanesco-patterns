<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)

---

## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template

---

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d193cc029a25bb3b710c878644ff788',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/c850a5f5af83d1a76a598f5785b6dbe1.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4626a6d13a9aefaae1343cf4d3646787',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/30351ff6d4ae59afa742659f0c3a7023.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfbed48b7b84ca21a1dd379c114133e5',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/3af842a5544d077b481d38d0c0b327bd.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe75de1233355d6515157c926fa3db15',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/c53ec5e845f07c4c52c2bafe8ae9fc31.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fc82fe1ddb80405d1d45767d18d603e',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/c314ac2f71a33ca03c1b82303abbce91.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd69515e3105bdda464b213b0261ec071',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/cb43ffa78ed1a186e2fdb46158110e56.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d6dc60c26b104c51c8000ba527250a1',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/8f21342bddda3b5d16ce0608309cb30c.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f907f5c89896925bb35ae2811f047449',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/9d62b54599898085652d986d31ffa923.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1896a5864ae921ff181ecc2c94ac4771',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/e69e4226e0bea2062dcbfda3ec8950c6.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7cc4c550653cf7b69100692b485c798',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/93761f685d87c29f7ee2c6a29f563c7a.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ce51a5cc08f8ed19a8a4aa5d07342e7',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/c1599c350597eff1516021fbbc05ba94.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f55b7cab747e2eb245e92e7d2bbc44d7',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/ca330e947a7aac5b3f912ee8d10978d3.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c778795cc76ea271998e7b85e078130',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/246b5ea795e94cc35c545c3fb47c0b0f.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c88d0043f9e551caaee3c91726c4c620',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/ef6a684e35ab825462c4bd28ea3ac9a2.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b67883e8b9b87e8525ec9fa6475fdadf',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/6d71aabc7e63f4bc8ad0d898a4f25dc5.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c33a94f8a846ffe3ffe044881b62aa2',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/585f89f91e603a8c9ba9476cc9033fa8.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dbe68e24c0e769ff061095a7b607950',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/09e68f50c7ea1bc9c7a1f87ac0f8b03d.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ff31f050c6582ccf45389454f52457d',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/19f7b9c8af165c1a6371b7a846aab6c1.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '360af53fe953bd02be60031149f242b7',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/0e81f381218ce25bc78aefc04bbd5554.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af838d3f14d9bf0497ac84c671ba8719',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/4c395906f20cd5af50e35fd161f7133b.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08e7dd4277354a27c4dafd6ec1d6242d',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/d2406da8a22eb23dccfc697b7a4e3e26.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b21a9c58dfb85e4e3845e7c61411b17e',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/2270d653c93531b51ec999878331f0fc.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7000600a1234253f145daab6e980a421',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/44ffc0e94e36fceca94c9169c94c0314.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f06feced0f30e686d847d4b2040662c',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/480959c6a4e5cee9485feeb0faa51748.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16adc021ea08cf7764641f9b9ff93fc1',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/505ba45d06f6273d6e3cca684598dee1.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19415ef0bb8b9d75265b0c6f15bb57b0',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/ea2eb619d1893fd978b65a45b8d0f6b4.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9be577ff39231b58fe319cf1aee0b06a',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/5abf2d50ec2c426fa51e782ae248ee38.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a4ab40c2f122bcf22cd4e512eab921c',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/8b1518492fc727be03cc1d0bb7e101c6.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abc57ce3ab2a3f795fd3ed35f96983b2',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/ed3b7785bea1337538537c4753ab7bf8.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38f2d18822907d83d7f9d90b5f5cb1d9',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/8c91608974445fa2ba84932ebb835a8d.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80c2d3aa5b036b1dd5c5925499d87983',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/ebb1cb418bf9d393bf1584ad3a396523.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9cdc953eee35ee1dc3a8d49ed409ac5',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/c19b73eb5a5685f5f20885f14b00b978.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68237fcc27b613e9925d88463e3ff76f',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/c44c13b3653ac02ec83a8e3bcafe1cc9.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86460d33c78ad993443e5bbf225ed1ea',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/6fa94eb296e343dcd868c958888ce85e.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12ae4e7d1bca0269569afcc45a11dc90',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/3295cee42861da26df6905c635f7c958.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80a15e2dd4f413eec4895c3b83eba399',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/d8da8fc0094ae26581c2d4a7ee84d5de.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '386cacff5cefbe24b2e84e1b54025da2',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/b50b6e1b6800226c7be5bebc6c1455e9.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47f2a23abd162ae351b76b4fb514c7ac',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/a83a42c3bc433644def76d24299df0cd.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40846270cdc59314c2d2623412564dd5',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/a898c7ca9b3f11afcf751490b9fd2e26.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5ee7ab87b795ce11d300606cd5ba84c',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/bbf26d58229b8628f331dfd1c0e9410c.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '186b659434d6fab582c409cb1936ef18',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/7efde501c57560657ded1f301d6f2f32.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a912af81d8717020200ea53b9ab69392',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/e3b073b4a9a679a4d70d639790f3769f.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5d94623cc8ff3c28798444a5d1ae3de9',
      'native_key' => NULL,
      'filename' => 'modCategory/c847427f58e25a6388338ffc51553f80.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);