<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template

---

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '29d69960aeba01f605982277c66cb6ca',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/b0dee0c0f18756d17d6b9c8e40a60659.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a4c1614f37bf3b1d843825eee7cfb3',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/eeadd0d90e6b0b7fe1c662584fee6b83.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5151aa30f495867a466144e500da0a5',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/24ce659a947583b318b94996163c97df.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b33258432dbd042088ceb75b33026021',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/fb84bd4b8dc1e3f57845a6133b68c2a0.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91fff08f9b96d3643069b0e390786e1a',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/d784b30bc3521574745513410f0f9962.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c5fd5711e4a284b34138d5ec36df737',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/1b8d762b74e1d22f17a1cccece50f4df.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1b2f9210c50e91957c88489d67b40b0',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/e7c895fa68af1d6404a92daaa1bdaf93.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7029a55a145c9a4b959745fb08807541',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/c8ff0ab10bf1df7cfa383953f4b42078.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9be1ff455c1e3e8b96abe59d5cb9b45',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/2b95f375cb3c47401ad5245485bbe720.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41ed282c1ff17889b7a6c4ce2a4877f8',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/f2fb5543c1a18ed4a099bda072dcb2f5.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c04c38437edd157a8ed1f9396d252de',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/14dfb87381609c917fa57bfe47522fe3.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd49746d398aaebbf945e684ddf68ac2',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/89ac24ea289c22843c99a6b0c5d39f35.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ac4d92a1a483f73f3d0ee7c2b53e62e',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/728aac91334d277f40cf775e999a3b24.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a1b0fd960c854eac0be65c3411b3cfa',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/e80e05ac398a62148d1897d81754a5d8.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5540fd8d31b0339a2d5fa89f8ef4b91',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/100bbb16cade9871a315c724e8d259e6.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ce01f703260467c2a40654f96c82db2',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/827cc915fed7e9699e9979e4ac76c732.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '081546f4ba67d147dbfea4c745e7b734',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/37c6a6876d460d6a94fff114368bf76a.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67cd7dcfe301e6501d85a110c1491036',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/15228e97a69517c3a3b6f0d293fd5348.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66f4816d0f025ac5e4086b30692b80f2',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/edf823c8e429993ad37e8757b763b888.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81c0024859bb6a1837adc894c507f3e5',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/7387fee54d7967a4bf73981e29f4820a.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46e84925b1050937b7e77ad4d5ec7091',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/851fdab1dd96a28ff91efa9c863ef974.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0325ce718711f8430199f0e3bcc5216',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/068fd519925fd74d39ffdb5d1cda9083.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da78df62adab64f1f671c63e6cb2aac6',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/8dacdbe603a454e66497865098f438ec.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5629b1101374929fb6d65fda05617c02',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/8a83958bf6e97f590815aaad0723fd6b.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba9ffcf5553f33bc3343367135626d3f',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/4e19d97dabf577b863e92502b310149d.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9309f18662dbebebcf6d26a2a2404b6f',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/d304a6899eed927675c3eee861e26375.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd565175447c6966d072631f10469edf',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/b4b484892c42e0bd798002e5f88132cd.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c996b3a8bb08e7894b54e1417397df01',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/08df2cb413099fa0145ab2ca452b4aad.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b106a54e58d82a6b5ed6341498793f10',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/37ee370c51339f7d5951e63bfaf6ef0f.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7d3efcf27fd09cd1688a2fcd2d2d0ed',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/17ea4565f9c484ca62ad93571b44e874.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6a917e3cdae5be457a5b667d8505d4d',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/8e87c89f3dfb6f3c88c586dbff4ea86e.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58b9558d24902cf511f8bb1ed524b1f2',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/883c38ba92217b94ff7e691d9b5a5270.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b0927c92e4e57dc5da4f68cbbf3307a',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/1153faa66787477e8a127ade31ddc139.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c3a05e24d02b627cb6ebc739264128',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/fdb7b7ab1081049f5d46328607fb45d3.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85a24689893edee0d45895b07fe292c4',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/5da7405d53624d1290347dc5a9924093.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd5b6f6b468d3dfdd1e9f7634f392f12',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/f8ac082fdc045cdd33a3319c8ec420ba.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13926b20ebf8d79da56cdb098ac61a61',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/d0ea1c41a308e4fe6ac8e850ee5440bc.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53572edab053588d7231d3f731794e21',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/b6558692734c13fc2a1a968eea6aef0b.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b1ed6c93e604548fab05b1221edcfab',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/9277161ee02a61193c99ed172a56b44d.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88cd1de61e442c0dae245cbbedfe6f5d',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/4d7e83e96b4336c2d4dc39d166bdec0a.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f94e617372555c9dc9c4dcc308cab5b',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/b0817320f1c5decc5aa3321968f1ab9e.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dda011f83d16744b73dddd95e0fed58',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/f805bfd8c7424e858ccd53bfd59f1b62.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bcb64ab619831166c943600054faccba',
      'native_key' => NULL,
      'filename' => 'modCategory/fdc4b699a7095c5518e3fdbea9aab555.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);