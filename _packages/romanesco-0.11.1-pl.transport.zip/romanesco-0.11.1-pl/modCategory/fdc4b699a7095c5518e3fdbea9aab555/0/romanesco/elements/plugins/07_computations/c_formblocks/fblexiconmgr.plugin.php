<?php
$modx->controller->addLexiconTopic('romanescobackyard:formblocks');