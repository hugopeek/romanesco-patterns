<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)

## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c096d48c4c5b1af760d5779bd1b86d76',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/56e2629e3f81675b65b18c0f6a5abfd0.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58e7c54239370e97a7177f971b218c22',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/e61e16dc42a9e582124ac2b89fac9a6b.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17111312fd732de007a351edd5cbe61c',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/788128bc65ba2d52ecb3eb4ee8137f16.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93f62d332fbcdb63bfdc895564d43021',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/a37f67e79d5a7052152882608115dace.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f2500f7ff7543f46c4c499e6886b811',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/6d0b32b447cc7a369e84857a6e2af174.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1050b3f0c303b89d3e339475df9612ff',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/136b02f84f39c41c8acb8b2f90d5af37.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd63164db84f0ba30af7f637533bfd0b3',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/84c1815481d17086e47a43646cff1cd0.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e9a80043b37af76e30b50f1cb141290',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/61f050c5034bf3f52b4241eef877dc93.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60172557fd9a7f98c80098b0900a7ac3',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/662b22f0c7c72b058974c9cbdb2c6780.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '196003342ecc0aab172f2379e0439650',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/bd6fd3c79712596e14717c4bfe1bbc0a.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceb7ab1d5cff508ed4e6cb551b373d27',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/3ddea6ad41275331e6283cf41fbca083.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c558be112b555235fc8889a93bc56127',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/7ea767a4682f143bc7eb7d9a7b3f8ce9.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86d71f0d5d5c10c81f56d70d4c22f1fa',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/a3c2013bee439535744b967504db61f7.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c7198beae27e32c3fb4c2ab1fb8cde6',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/7486d6d9fdc043843e1f41b92289cb41.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43dcf0a9cc5b26de9216dbf7664756ec',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/744b53c6f68c1e845a7c1875f82a9934.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b04bf3ee8ddb2ea23dc34bfe71ad6a2c',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/f240202103857bcf1fade4bb6e8ea2a0.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86080c39b31463f010f151c29e56d038',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/a5fe0d5d6556b59b45744bdfebcad239.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bec40e287767ca44e52810c9a06ec2a',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/b61a175b832e87bbca3093ef4e3346ec.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '308b9675fdf08b1e8163ee5599346d1b',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/84adaf1191927c292d2203ba6f634c58.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '782c744bb7375c5077b0d05b4d33bf55',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/751d98a275c02722df1605e9afdaba01.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c495e59de9a204865745bd206a94afdb',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/c0d869a56da569b10462844029c5289e.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd576a86d555f68c1b02100816042b79d',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/2d071ced0dfdf6ff62649424afd75562.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c1c2c7af90815ef7d00443a73338d2e',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/572afc94ddd0fc1d4ab9e3286675d6c8.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e55f3bd25a9ddbf3d6360a6e22e124d2',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/43bd4b8a66c6e24cada696a8a4060c5f.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a9651e898063d8fac49341ccaa36f5d',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/391dd9de5311c76036d59c638b08faae.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95346e411754c135f933067379363504',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/947f305970f580d1ce4857d4ff0377a5.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eb5574318e822c5607bc58f9987893c',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/fc299f131ed8af5c5e7319cc1a67d636.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dde3df5e6e229105ba6364c25b053b5',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/0f4e4cad413a7b97fdb2dea1e31c9603.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56ff65d54e44224236cc63ef00ff4461',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/99983f425ec0fcc95910c56618fdee19.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85b661a50e16b5ae98af85a494befff6',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/df1950f8ee27438d7a8e4615cf4188e1.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '151c71f8f448bf6220de8cd63e2c71cc',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/8e7b6f61ea3815a408092b8d40374f7a.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91685e90f1fbf56bc97d42a9ea3d1574',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/6af13ba2f6b70d9f588dc266f34ec84c.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '554fd7c834c6bf4039a5465a9fb3db77',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/83cffa86e80aef4ca8dd231c3edacfdd.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1aebc739cbd2e757d157dc0a50c5dd57',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/e409538739bd84fea98e9d932584c451.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9bb5af523f6ab3ede89d6ad1ed0f25c',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/8b25ff54ecdc038269098d7e515b7631.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473671310954896b69d4f6f8adf03c70',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/22b96c72fba5de3401769385a154148e.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02b8a28a755d56623d02204643fcad0d',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/e64f223c50b200091b73556481bf12a1.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf8b7619645b670479226fe54dab0237',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/a6534d7f87970e2da93202517531d166.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '545e561bc118804661872da0bdda3995',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/c8561b813d8ec48cada5898ea2aacbd9.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcd373197840b7d41e2afc757a6a580c',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/d357fb9658dcbae6465508a2f72f25bd.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b93bced228aa8309fcea68749e21810',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/9fdb6a79fcdf6a57dcc61715723f42dd.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8207347b3da9a7f55e52fa0e2a4fbfd7',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/207add2924bb0ac8024c48bac2a2534b.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e7123145ecb330071b907b240b5543f',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/cca56220657681ac94739ad9785b7cb5.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f3ab649687c5451c743a35c91dd3d42',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/742511b25592fe607513d313e19caef6.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f334c544de2baee522f14daab48c38ff',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/6c7a5c680ed1def30f37d47c37308e44.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7dcef849efa7ecd5b9cdf96f311992e',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/77d2289f4fd0107e5bd9f8f7b7260423.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b894a77ee42c924e19946b0ca2181537',
      'native_key' => NULL,
      'filename' => 'modCategory/d35bfc0fc081d466fb1dcb88ea772bed.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);