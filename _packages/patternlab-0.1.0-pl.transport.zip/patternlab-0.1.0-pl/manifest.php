<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7e5664955763dd33abd1a0dfe2cd4dcb',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/afcffc066c0c663b6b305e4e00093721.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e5d6c4d594501baf99b9bbb1c77078c4',
      'native_key' => NULL,
      'filename' => 'modCategory/4609b7c0e98a4d0f891f6cf771f78745.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);