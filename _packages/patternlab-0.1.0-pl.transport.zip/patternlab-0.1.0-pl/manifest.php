<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f966439634056f7f75b90ad55d4e2788',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/7817b003fa9b0f0f62ece3f9368a2ac8.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1892141b7e067b83335682fe426fc0f9',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/e9eb2591265a5d2674b9e967427f00a4.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266a05252aa190785658c761e9184764',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/8e5ee7533d9be35ef638b3b97a8fab1b.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ccb3bc7615fe73d332678628d6313e4',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/ca738bcdf9367baa2136af0748dba075.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d38ab05e2d44dc7ca63c143d8882b93',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/3e6fe2be6977ab78fb50b8844a2d39df.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c7cb09e15021a4bb871f9ba2e5857bdb',
      'native_key' => NULL,
      'filename' => 'modCategory/9420f3947de494de5fdf0ff02f057efd.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);