<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'badf1a18c94cde227d36016231d05cc1',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/79b9ce3c57dac0d4c2cef74a921378df.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a37607cdfa2249a72bd7659caf37439',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/e37305ebf3e370991dddd5df89dcacfa.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b27cb10c3cb79b5249dcd00dcce6ef9',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/4207f658e7948feb6adbe30082257de1.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2231802b6f1e5d7a8949a15f6d196f4e',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/51dced269b935ed917bbfed5b1b2bf8e.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df5998cddfdff160f664150833e82a40',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/d1b49794a1adbc7d1df2a4020df4d96d.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '481c8b7573d5a718d83e89d51816490d',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/7b73fcb8b04f15e928e4b47249f89b3c.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6add35c88f96bb7c460dbbcb30e1c42',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/95c3cc7fc37ef12080407be5a5d00b1e.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fc02cac3cbac9067c67543d209f3f4a',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/afa477d724fc2e76fc461648026aa1a4.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53df9613f9858664f88fe482b809fd6f',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/1eb7038da15790e356b144b0673694fb.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c546525aa118bca0cf089e51aac6bda',
      'native_key' => 'romanesco.title_format',
      'filename' => 'modSystemSetting/78166fef41bae444dc91c3042e4f8ecf.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '632271d3213d599ae1157f6490dd7d14',
      'native_key' => 'romanesco.custom_css_per_context',
      'filename' => 'modSystemSetting/b7a59bb7db0d2ed3fe35671cb62e0a3d.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9160ca65e80a7ea6a8676c32376f7416',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/7fec7cf2d6464c6cac693e397bc1ea9f.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b31b42a9b5e56ebd6bc52ef92c94f5e',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/76dda84a1028b24f1ce57b5613fbf983.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '903204ce6c3bcbbf75e4c269ff557d18',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/4435649630aa7294764242a13af5a0fd.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '600f5d87364250bd9d35ec6a7d68ba1f',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/bbeb4de669a7df595caf379f19a8274e.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c933fa6f1f3e31c84abdf297d7ad749',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/c245450a4341a39fe428c1dc3c3b0bb9.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2230fac1f5819ec975a99e3665ed015d',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/156b283e5c917500f03a372985b3c39f.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c22ed8807b145463996f07d3b5560c1e',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/403b413dcd161aaab97e7a1502ef44c4.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b71818db98d012c484c986de3c969e0',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/fade1862c9ed0a034bf749475cf0a8cf.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fab5cf00ba78904dbe2b87fc79d5eef',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/e9fb8befd612d1ecbc3b2499759d9875.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7e906fd40daf8ce5db24e97cd96e566',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/b94e33e19b79edfc42c529834c35d7a3.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0b0bf3606dc69b4badd0208f67d0b09',
      'native_key' => 'romanesco.mapbox_username',
      'filename' => 'modSystemSetting/9143a6f4f0840c894ba7c43330b951d2.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecf5bea54e2d9bf95c9194104b98909a',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/22067f45a5ca44e622e751b326fd76df.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce306785f2aaff7faa5430426fdc6874',
      'native_key' => 'romanesco.mapbox_style_id',
      'filename' => 'modSystemSetting/6ab46da01556ba9e41594f4f88fe8748.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4547ca4a6959fa41c50156ab0c81bf2b',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/6f22ad059d1a9886ed0f7871443eea63.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99398195ef74d6a75e2c56519075faaa',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/54b100cb2477364e98eadef98216a184.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aae2ec3afd03d16d6e04e464f1582f16',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/fd95a9bda9ca471951b5103dcd94117d.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02230766159d6d103845b40d0fb6ccaa',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/e4df88c32b86f1dbb77371aa1ab464ea.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c145907f97754f4ecabb2679851c0dac',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/e22eb84b9e6264712da59db45f5ec1ed.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a169936ef044038b9ec93bb96b90463c',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/c079259dd2935288b4116d1d20c7aa5b.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edfdcaa74627a086b062aa6fc68e72d9',
      'native_key' => 'romanesco.assets_version_css',
      'filename' => 'modSystemSetting/c941b7eddc90cd6c97d07a5a0db46f15.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b543fa9e3bea55051663852776a9a86',
      'native_key' => 'romanesco.assets_version_js',
      'filename' => 'modSystemSetting/b616c0e1b3820d38e82e0920b018ba6a.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '975814877d617f938a0726c9c809f813',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/db6552b39d03579ceccc09db0ad4bd45.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f0e1e8c5f171805f8836d94c0bafea9',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/bd6a0fa2aada10c2fbbde835627131a0.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09007bc379d638ad91ebeeb7bf9818d3',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/28ebdb444383ad5dc4d3dac2accbc383.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc1395816894af25c80df0e59008d412',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/ec8122d91dcd17db575503bf2cfb64f5.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e710353572d13b59150c8fa72df9422',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/c3fa03ff566a5c290dd5d888b67b6fbf.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19a7ab877b0891d04995631cf1536270',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/9a0b33a84d510d6f09331b949db497c4.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc5c3e758cba07768a26f62776e56f7',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/4ccbaba1ef9ab35af3b5f6a717acdb28.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84a512f629fd9ddb1276fdbca46e5916',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/cb5c589ea5ad1b4c67655e93c447bb76.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69ceccd3e611eb7bbb5cc1a11dbeff60',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/c71428585107f650ef4125c2e85c2fae.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d4cc2f017a57e4b58a27fa9e3c564e',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/187f7fd8f27bb8c17cfb8eb6a5a91c71.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1adca164f9d56fe5a6b62b84438297c9',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/52158cd12524134ef286a1ee75f9b258.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5eb748c5198268d5fe687f7c2e390e0',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/eaa94175c8b6d738dcf58c078d6f7c15.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43cae59ac1072d27ebad5bfe7aefd061',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/602459ea421ed53379fb3ff7b3807f11.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a55c9ba500ea3941ac2d06a2e3b2174a',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/ac06605b5184f4d616fcf357385aed8d.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '124054f00a2b5e5a48346f8fd1322156',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/fcd101642d2eb122fd4c76e0b8d410fc.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '960e3646e04fa94d7ddb725655344a5c',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/ee64043f952b44f6480d8b017562af16.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd175753f38ad07cddb8cb79939bebd46',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/bbbe1f559b9e672898be6bb9c36ff577.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67411492ec1a9e3d418c083774d6eb97',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/96b82b0a648b430fd06802c043079d3e.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1855beb3f93f71aad2553caa80396a1',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/1b1783d22afe87582558a522b7f72008.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f312c35a8cc460623c161d08cc637d6',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/6232c5fcabac812d9617edd67029c62a.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ac7f04433d12051f67b9d757b225d8e',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/032950ecab415394e3fa1843f4d23456.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '204fc921b35147729c30faa08c947df3',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/4cc17449ea6b70d21bcedc6dc5748742.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65e95e479c6185c16a3bba9f3c7e79e6',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/304955a9e34bca054b01e446c6f48fe5.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '026da8440087e7c34011e5b092c1f227',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/26995aa630b487b4f0a4f64ff77380c2.vehicle',
      'namespace' => 'romanesco',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a77de07b5ee2d1905e36e08865d1596',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/6e2dde11e55ce01992097c9db0fa36aa.vehicle',
      'namespace' => 'romanesco',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08637b12a3232fb941d3265d4f6ed9c9',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/de9090bbd5d13bfd9f2a769183c6079f.vehicle',
      'namespace' => 'romanesco',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df67439e0a06af88bf6c144867d3ede7',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/f3fd176b0dce567306b1605b68f018cd.vehicle',
      'namespace' => 'romanesco',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28763abd090a9476394d2bb1c32f0f65',
      'native_key' => 'formblocks.cb_input_date_id',
      'filename' => 'modSystemSetting/1dc622b1b052ce922587f8c2a03fb48b.vehicle',
      'namespace' => 'romanesco',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd558ff6560c31fdae6f2a4bc2d6c83e4',
      'native_key' => 'formblocks.cb_input_date_range_id',
      'filename' => 'modSystemSetting/21d71bb54ea9bff6d4b3e217c12d977b.vehicle',
      'namespace' => 'romanesco',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cabd3eb407d50e4a56af1fca2aef1d6',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/e31537f5dd8ae37781f971bce3379eb0.vehicle',
      'namespace' => 'romanesco',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a71051bee740a66a3e0a8e14e65b4cba',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/8821b7ec82dd770d252e7c6313403d73.vehicle',
      'namespace' => 'romanesco',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd0818b43e5e61fd63ce25e2030b29406',
      'native_key' => NULL,
      'filename' => 'modCategory/20e3d065141c286b20dfbc002d7799ac.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);