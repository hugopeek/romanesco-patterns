<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1a25f29dd8d59eee47dc1c491d65b28b',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/659ffce6822599e81f43befbd35e69d2.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '766be7f947a2bb4f42238d422841e0ed',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/c9c94a58fe99d45c162aba7e192cea24.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54f5ef4972dbe5e10ea23a4084c9ed8b',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/81df3eafd51232758614bb173787b508.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e2d98c2a0567a94afc7dda2be3607e0',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/5bfa3c31d6bcdd3a42735a5f457f6ad3.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a54ae8238e98bdfc3977019ae40b5fc',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/be3bbcd5712cab502a1a72f1be30619d.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9043fadf0fd907fde5bb46bcf8b4e332',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/2b92ae90000aa5b687624b33b64bffbf.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14d8cc376735737c14cc782dd477d433',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/bdbed87bbffd8e9e648ed187ac1e23b0.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e34f07363e1a7f5a2cf6c0cf14bb6f78',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/0e5844126a65310e539c23c6fc46427e.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '916a03a00834659f0fbad9a989cc7981',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/aa065aaecd9cba7c62eda50155378794.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '568086a172e72d65a48ca37a989ab259',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/1b91f8439c1b9b82692d7637a7a24ab8.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddd116b43c9d1800f954be96ca8298ba',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/66e8e08c7420cdcd0151e150ee9081bc.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e8c2cf07d44ab65f8e89ebc977a9e82',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/2e70d6c778d96e6c11b42f6d4d1a5bb2.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dff3a301513183a31a4126cc28d9ed10',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/b858f0393b82c6f5f2413ebb2def0bd9.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ff979c42e5e9e2aa1fa5a94669ab85a',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/5b2e60f838e892ded3ea397f18baf4b0.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19d362a5f5ca9c4e7b12b8d4ee0f9720',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/d3fc77991e148d137d7f3a8f4a0de0ae.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9ee08ffd7fc91716b7917af4c7a35bd',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/a0e97a3ddfa99e12a74b00b524c655d5.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3e3f3307baa1e660f6f2fde653d792f',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/ccc22a9435523a341db59af8205cbf6a.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05669e7789f0c646e382b3071a3c40e5',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/4c9a9cd1f5767e6fe2c3379d2eb39490.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16955350de37f813f921b55adef54bd2',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/dfd0a668860fa2a5d90c25c8c7f25fd3.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18902c313f92587db32a7e0c80f0f098',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/44c98957ec61398b5da04dc5704350fd.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16cc1b81b2867c0391616304fdc2e7ce',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/9f18d451de10a20c67a7f97a95e1beaa.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0230dde58c7084e6fb60f7972285a94a',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/1361f277bdc7890cd1d04c1ef26c9cdc.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a9a78a4c13ddf13277ec3fea01002709',
      'native_key' => NULL,
      'filename' => 'modCategory/ac5b6f7e5e583e54884dc6330ea8e48b.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);