<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '671a8d0572dac94130a2e35c5e7770b1',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/9dd72c4a94e301d38886ee9ac268f6ed.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91a1aed1d1ecfe15648bfa489c6845cd',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/76981909407bb295c42257206d050423.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60ce5d3535737e008c5b360918f4fdde',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/8dccece21e3a9edb3be6206e65c828e2.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aed688fe320d3a248254a4043ba7a7db',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/eb750c2ba35ed1ee8329015b89a146aa.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad95eb863f3f28ebb1c23005f02dc948',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/c479462a7d9f17e07ddc957f31662fcd.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc3f2b076d82c8df3fb5b46d10c37341',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/c0052ea98a7af57157fde9ba17a735e4.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc2fa9160aa06ec50b9650b07cc5c269',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/efd417bf15b72d569d1b9a87eba60b23.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d7398a5ae6e4839b05f4642e0848b6',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/0f54682ea3613d3ceaefe6eefe0ea387.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a110fff9d491b00f87a505fac6f3f4ad',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/305eb511de9ef606e24151729234bdcc.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd52171ef6463332be83996b62fccdbd5',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/a87ac486ec93459b0651f31c6fde635d.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78946245e709e6dc9860d05d0945ed92',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/be614cf0d99771a1536bf41fbd5295f9.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f10ba318ad9a1196b2baff02f7450ad',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/c64aa5a5548a62891140561856085e66.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '352fe3aecd1c8a9238d6647b45f75fe9',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/0d0e7773a6aa2afd1db8493a7e7956d4.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89fdaa2fb3ce53066ac3d5730cb22b8f',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/7f98821378fa73366d4aac748d358ab2.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd73b7de525a7dc787e653dba3c1afd4',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/35b588e4892557f404133a94052adac7.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ccae6699ec0183732ff2c43a4289287',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/dc7a8e15c58ebfff2f353350fd4f07c5.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79046251eba719081f73eec84981af0a',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/54f56a0db51aa1dd56212b7fe406636a.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c879b4676bcd92ddd2f40c26a569c9f7',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/38e81cf5d53013c29e9b9e5bc8e7c013.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8058a7719e88f1ccf4b406ae4ee27aba',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/99aa89ed18abd045fb50a53f734893cd.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b310f22ac7cf192c376e2d9d301b5b',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/6e0d94643784dad8a98f908ef87a2a72.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc2a6a5bcb8a007f86d64f4baffe6a80',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/b286ead67c19e8aa66b2b7fa9f94d412.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'accdfe29f4b3ddf52221b74b4664e333',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/23d9b92d3e464056d7ee4d2c675f8e01.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a9485c6bbaea6b5ef51238bbadc4f86',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/b66bc3b47eaac269153972729c1c07d9.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c9a7b40b5b8d2d5d5fdce6639e5312e',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/41c80157c023a486907522eeb5b3796f.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04d1cf1816bbde01a2f806594e1764bc',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/63d6964da4fb4d912d557f99b5a90d83.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b1014b4f3b844682461b691a42f7617',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/2c8fbd6f8fb65c3fb2b86b0894300f9d.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1c99c9bfbb91803e9a40ae7840a3ef88',
      'native_key' => NULL,
      'filename' => 'modCategory/7b97baac4d10e0e723f030da38ff647a.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);