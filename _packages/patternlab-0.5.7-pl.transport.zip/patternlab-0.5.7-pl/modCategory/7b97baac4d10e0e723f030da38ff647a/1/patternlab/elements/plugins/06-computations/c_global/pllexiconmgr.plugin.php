<?php
$modx->controller->addLexiconTopic('patternlab:manager');