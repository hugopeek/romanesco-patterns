<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '117d0a98b0c4241818f49879de6e48ef',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/5c941044c5f0618ddb623208d53d1627.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02438e52bfe72e8f74bf4bb26b2cd0dc',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/bcacd32a78fb3672fb0fc36f9ce8eff6.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '520e9cab8165db74eba8256df52f9eaf',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/b3ec664abf673ce90fc0d88fb83ed566.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9260d394fb3e055a544a8c227d4dbce',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/23e7b5e9dc87b70a9833d1d72726c308.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a52efeb0a4d11cf251fdd8c6a1b963',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/46f5963d73c45197b4b8c5162924f7c4.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba56937d8df0b2fd7bb1bacaf644d9d0',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/2523366c0b14ef30f062ba7762836531.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45e07954cead9574c8cd840d10248985',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/3ffaf76b72cea4ed868697d1b7994016.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63fb17492321bb40a13ecb7e0e842c5d',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/7c5f6d9495575a0122a4813d017b92b2.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db1d0b51dd556ea2a65f7d7ad7733c18',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/de3817ce152bbd21415aa455798b9837.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dc1a5392796171524dd1c343cf83a87',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/57abd31357bf1c3b5cb790f4d17feab7.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47c72827e135bf4dcf05f611257c263b',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/c00349a1e42fb6239e743a9a9a7a76b0.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c9f5940f2e6dfbf4f036e9277aaa52f',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/3e333bedffc82f506b15c369892890da.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f57e4095726ad8b33d0d66f5f5c493a',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/a2c64503686c526fec6f98971df44723.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2914e6e179311cd409c69b1d4d5b43f8',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/30ed98295dd601609f2b999b56b9346d.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bd2dfd2d072b1f6b256b68e3de50c0a',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/fadcc9f9e5954791ee83bdb4a3dbda3f.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459a9f62cd426056817d9b9781cb8856',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/d67ff73585b263b79e25adbcb36776ba.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '177b3c9ffa33da2839de0bb32ea780e6',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/48673ad407af6daf61ea256f527b0199.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6528c36b62400786fa2423d97fda791',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/4c8e311b40fcac05128c4d13385a3c83.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa4ea4aaa852938456c6a42ba970c57e',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/42bbce0e525be307dbcd4b8d7cbead6d.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '493697a18dd9c1a85a62a089c8812285',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/b94d4108ff710def554ad7ce38cbbb99.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cda73ff0e13761f9ad208a9ebf23b40b',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/338a5fa428bf84b69c3123a0aa4f0fa1.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcdbf0e89d7d217f092fa565fb35ccdd',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/ccf7a5c61236d0994b1f1eeee8affa88.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '291e33ea2ae92bd5ae5f798a799889ac',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/093db1196cac758b93ae22f339b2c71e.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c486e4aaac72042e6c757634f3d07dc0',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/54e9d313d8f5e4858216a5637056379b.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f0c1c9732f5f997654195209cd8c06b',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/049a07b494dd7db240bf3ae27a57b4c3.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2229879511fd608467148f94adfd93f9',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/cd2f0a28f21e4ca4431a266f8f3155b0.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c263c11c035aabdd98d6639aad264f9',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/b0d08d25cac07ba4cb6f5c332324253c.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '860d06efd8e6c3fc632f38c5f651fa84',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/5f28f9cd3523a2bff027de28152b6d29.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa79bf500218b40938ac088a0ed10997',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/b21d8ff9f57ad212dff2d617f87c678a.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2b20aaff48ea583efe71afa5e8667c0',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/6ccaf4369e3a8a901ea0692754cd194e.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d1047c54422135eefa339a5c3514cf6',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/6bbc8db629bab3e8d9a8298339f9a98c.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c04d1ce430a4a9296b86b155f8d6ca7',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/8f6f3a07b630c57d0e4d204bfbf611b1.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eccbdeda39898a6e925374096c2cf809',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/1a8e41c95c84121e4247b8b3ff4c2265.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57d92d16418dd7cb63af5f1b059fe1ec',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/88c850fbc2d21b75d00d8f3ddc21a5f0.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7ee17bfcdabda174be0976479cf6897',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/996a67ca54da9069accd572541c66831.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf412169cf791638a018645c03d344fe',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/5b5e84f8fb7518b6499baa39459eb9c5.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e078f921fd81cabed569e5c803e24aa2',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/95e4df344a44c3c900c2a9ab20693a80.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e318b6706bc9aecebf1929249be66695',
      'native_key' => NULL,
      'filename' => 'modCategory/154846d0f854116709bd314b15f7e819.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);