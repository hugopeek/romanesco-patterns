<?php
/**
 * 
 * fbEmptyHook
 *
 * Dummy hook to trick FormIt into not throwing errors saying there are no hooks,
 * and to make the comma separation between hooks a little easier.
 */

// Nothing to see here, move along..
return true;