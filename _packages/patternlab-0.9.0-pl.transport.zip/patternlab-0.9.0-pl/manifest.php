<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco

## Romanesco 0.9.0
Released on May 5, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN

ContentBlocks added or edited:
- [Field - New] Tabs (Rich Text)
- [Field - New] Tabs (Flexible Content)
- [Field - New] Twitter feed
- [Layout - Updated] Content + Sidebar
- [Layout - Updated] Sidebar + Content
- [Layout - Updated] Content + Sidebar (Nested)
- [Layout - Updated] Sidebar + Content (Nested)',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ed7f761c7db52a2172be0f0fe6fa40d6',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/b49e5a720d0065b1645be06189c419f1.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e939827c500f80d8fa443dbe3112e6b',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/6b4b4e89dc4411ea6d212355641606c4.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb563b1e650210d5e7f2daee4c217b10',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/1ac03e97e7e5edee5179f59ec9c8ec54.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '423121e7e74518f0c6260ffaf63f8291',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/6b2ad074b38ab9db6962a6dbe3bf82bf.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87d52dd0c6a15e6d0af8ec077a9d3a3d',
      'native_key' => 'patternlab.date_format_short',
      'filename' => 'modSystemSetting/5b3ded9dd7aa4a6e49128da7f6a2c621.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26cd296a28122262c7a252b5c87beb68',
      'native_key' => 'patternlab.date_format_medium',
      'filename' => 'modSystemSetting/7e52199752af9ea3ef8f7367670f3ef5.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0a58f688870267f9fdc743b9e043a40',
      'native_key' => 'patternlab.date_format_long',
      'filename' => 'modSystemSetting/a01e898c4aa0d5ef339300f4df35b315.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d1d43163bc751a6eee7a88fe8c32b6e',
      'native_key' => 'patternlab.date_format_full',
      'filename' => 'modSystemSetting/dfeb858028e7c0ee41b75d94b0d09c50.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9753b37e0d97a2e475bb4e42a3c10584',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/c62c3569f0c0c3443443c89989ca1202.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec289d246f3d010ad52ee4835d0fb24d',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/d8a0d5288e5f59b7d657cfacd177f0d9.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57dee7548d315e1196c4ca95cef6b913',
      'native_key' => 'patternlab.cb_field_code_id',
      'filename' => 'modSystemSetting/e07a1e94c05d241de34d46bbbed81fd4.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd41d254da35117f0e2dfd154fb39cd5e',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/e73fe31e0d5c77e4d88711a417d74e78.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '258a0b260e1094492029e988ca2eec0c',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/c90967a6ecf8c906b4bfbdc2218df5a1.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2da0f95682a5474a02c769b312aee166',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/8d1d7d40fd743db1952a15fac791bc89.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1301fcbd5eed4bbce21526969277cf8d',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/9e489ac3f44d2aee2f65231d394e24f2.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3c1e0e16121ef46f03e8e8004d526aa',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/d2715aa60568088d98812f98519a5224.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53bb4f122acae829129d11ceb63ab58f',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/1fe449d7bf766b34f9acde6baa600961.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a560dac9ac32e4047a4975ea160a5ab',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/b3733a4f0bc1623c4c72a0dc479795dd.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91b5c0d475e19a16e1a269be5fc2a046',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/a4d13d460643f780f3a9a4353c00949a.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e2c1f738d82be8f3585548c88bbefae',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/ee080f04a8a77f31787c63af00b42158.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbe4bae04f26318f7f0b24bc9529d369',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/1aa7e6b1f37fb7cc394b56b2cd5829bb.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d0d226638d7e96e22f1273e6f41cdfd',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/940d73f63dfd98abf2c235820b8d8384.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ed86e644bce8259ecaedc54c68d34d9',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/506f75254e8b1a5d45f6966e5d86ea45.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0372001c4e2e4dc4dd889afa01b703b',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/683d0d030e5b0026a1751f866d9eec5c.vehicle',
      'namespace' => 'patternlab',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '649e188f67858d69dc77509da0c21679',
      'native_key' => 'patternlab.publication_container_id',
      'filename' => 'modSystemSetting/a9b1c2293a9fe6f78055f011f723f255.vehicle',
      'namespace' => 'patternlab',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a08c3a5662635bb43e7bf762eb03ad6',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/3c43e835371d0a86a72fa94c567ba0ca.vehicle',
      'namespace' => 'patternlab',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc2b49b12832145859a18238f5a61e6c',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/15143b56b1a0e429acf39d7c0fae1638.vehicle',
      'namespace' => 'patternlab',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0759272c9c23ee26a2af8d02e18d9aa',
      'native_key' => 'patternlab.portfolio_container_id',
      'filename' => 'modSystemSetting/ab3959767dcd06d00ab24bdd6373df00.vehicle',
      'namespace' => 'patternlab',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45de72151a8eb7ddd02f45371ae269e0',
      'native_key' => 'patternlab.client_container_id',
      'filename' => 'modSystemSetting/9b40a4d8fd8a03248d65ee1ce37a41d1.vehicle',
      'namespace' => 'patternlab',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0b6d96a2c91cd83dbc3df91f85bb935',
      'native_key' => 'patternlab.search_add_to_menu',
      'filename' => 'modSystemSetting/a21398295318374418b8bd7671eab31d.vehicle',
      'namespace' => 'patternlab',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6998e42abaeddbea75df1f832829e393',
      'native_key' => 'patternlab.search_result_id',
      'filename' => 'modSystemSetting/b0eda71f28ff14d30d2961ac51cfe98b.vehicle',
      'namespace' => 'patternlab',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a2bbd20bb6b0dc86ebfc44962e962ac',
      'native_key' => 'patternlab.search_result_limit',
      'filename' => 'modSystemSetting/8a2ed47550a0b7e2db9897e455dcf7d6.vehicle',
      'namespace' => 'patternlab',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caac2f3f15f756a3570783a3a65fdb56',
      'native_key' => 'patternlab.social_twitter',
      'filename' => 'modSystemSetting/cbe12c4401b7a50aed9281d6d9c233f8.vehicle',
      'namespace' => 'patternlab',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32205f16683a7c1712cb2b7eaec29b6a',
      'native_key' => 'patternlab.twitter_consumer_key',
      'filename' => 'modSystemSetting/e338e1de88dfea8d1ffb8c3223ed2081.vehicle',
      'namespace' => 'patternlab',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd82c11632c663a8bd2be2ae28d996df',
      'native_key' => 'patternlab.twitter_consumer_secret',
      'filename' => 'modSystemSetting/39b9cbd03e83270adc0f11d7969fe64b.vehicle',
      'namespace' => 'patternlab',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8215e8a17ff27f25a895c7bb1a37a0e8',
      'native_key' => 'patternlab.twitter_access_token',
      'filename' => 'modSystemSetting/2b5a157e543d4e2bb36c699831d5c855.vehicle',
      'namespace' => 'patternlab',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13bb9ad1c8f2c56193a24fb9b0e12ce0',
      'native_key' => 'patternlab.twitter_access_token_secret',
      'filename' => 'modSystemSetting/cf828eee14c1a6a0a61a0f09a8b7884d.vehicle',
      'namespace' => 'patternlab',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'da2e2b11f3f92d177890784092adfc02',
      'native_key' => NULL,
      'filename' => 'modCategory/726e97f002fa59005f1c673b9c2302ae.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);