<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5def1acf79b0ecf1d41fa202b75dd030',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/7ff955778e1aa180b0dee83b131cb86d.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '495ffaf7f5d836a2a15a1579b3bb74f1',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/4d7c64ef02af3a0072c0fb185fa21192.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e102d4600c113f2060cc780911e9cb6',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/8cf42bc8a8788b5eac6d677a09dbf4fc.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed073a770aa60f911a550f798ff25540',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/e1ea3c9c1d931ecc7a979331ca8c3b5f.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9b1e0ed7ce75d173820c8a85ba8a7c1',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/a38c7fe761968998e7a0704e122c1e0f.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05ce960f0eb025a6373ace10fc44d4d1',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/e2e78e663cc52de70694f4f9d8c4794b.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b691025ba39348f095881c869ac3c5b',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/4b878e70ac9f7a66c2a905d8e2f916bd.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8adfe5c6fb4ee281abbc78ff756f19f9',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/e134dc1f92027cd7ab71bfcb7525c0b4.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1750ba8ffb937078ed7242633020160a',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/d0b58d302eb0a4b7a304fbd0a7c9d735.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07ce73a7d6ce381495c78217ed3aa0c3',
      'native_key' => 'romanesco.title_format',
      'filename' => 'modSystemSetting/d7884450482b6bb4b7baa3cf2a92c1a2.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa32d1c8a5b78e6f62c477a3a8b546ce',
      'native_key' => 'romanesco.custom_css_per_context',
      'filename' => 'modSystemSetting/aa8fb6715f0e3deab035aeef8a8b33a4.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae3c49580be7a4e4e302c30bbecb2bd7',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/7e8caabbd591fa9d00a093b3c8a3eeeb.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2bc74749a1a2bce79b5189b041f6b55',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/53fc6ec9c4944feb9cd631e94dcf68f8.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72e9097747a8910a2a17c14dd1759c88',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/5d8844d4746d33a8446529d7798e8ce4.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c18a1a49a9da2585edcb76fefa45f00',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/fa9460c5b0ffff2badf801004bcb6a34.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dedb297bedb289c86adbcc0736ff8eb',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/8ac29e0462a133030b312b2927e04c70.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab13b57b67e99bc7dd19cb085312aca3',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/5ceb2ce1cfcf545c7d414bc945f4680a.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dcc81bd40ed978188db3106bfc26853',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/e6d4f4c3577dc7ed068ddf5e5ceb3995.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81336ebb37c80bd7d8f1f6c7a1b48cee',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/c730200fef21da2f457640e209f3f2d4.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0ac6b5b78137b9cf96f5ed1dd0e749e',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/bc2f3fad3d9d4f268615783f7d2315a5.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17c19d6b78300866c585275cf07e7256',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/42620a8b5fd21bfa5ec553549369e530.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '050e477466c3592637ed35eb43426d0a',
      'native_key' => 'romanesco.mapbox_username',
      'filename' => 'modSystemSetting/30775f0a0e1f0b15c7282ed71b615695.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7b5ae0d088ded68c679c7028dd51cf3',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/e3e18dc68c3123edb4bcf1686ba4c470.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df541efeeaa2c96e16124af1ee9edc60',
      'native_key' => 'romanesco.mapbox_style_id',
      'filename' => 'modSystemSetting/645e912cb3fa033998ca148203feab1e.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57fa948aa6ac87d47653be1ced4d210b',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/72529ae45df00e067bc487d6e67230a9.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '334da724291066788822a29c5d5e4423',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/fc9519277f2f9d712a0d3d1e4aae900d.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d9c3df346cba412e9dd934412ababc',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/334b6048c91c0279062d788d4a3b417a.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac5943ee357ddb754aff0a676ebee905',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/4152f1883355a8e5036dae2cd0f6350f.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a5d4ed2bf5337603f181dd0500ec1e',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/639ea08776eff098f006c055c24121f7.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4342383e6000af1317632b2eb47c60d',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/b39401d8b123b260250f56a1f7abb5b6.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f11aef6b43313f4b4f64bfcdd52aedf',
      'native_key' => 'romanesco.assets_version_css',
      'filename' => 'modSystemSetting/1e226f7b892b91cc3caf0a9a8682b5b5.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20e4c0f19b5faab90c056ffd41243268',
      'native_key' => 'romanesco.assets_version_js',
      'filename' => 'modSystemSetting/3961a66eb5bdb8efb0cc7a2d9c64be69.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227a60ecb7c195ca919556d9c8610814',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/8a902a8ed16e6862d8dc5f34742383af.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03c3b523a831f74ba638f716c67c979a',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/5c20e5aff39ad9c08b6de83ad8047b81.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d5ff8f2e96e3f9519be9fc3e7c0b10e',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/fe9d0160ac0395bfe9e7846f9d6b2eef.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c362672c197e0cc7879e24c27f8c9a',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/0a9710e2a55588852f4948aecc40ad29.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28ccdf8d0cbac4d73c995ee0de25ac1f',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/985425877251f303207b1eb6023b0eda.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bba777f4bc77e29ce0322f8d4d53636e',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/c3bea332b23eef204fd5449d11dc6ea8.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceca0ef5926362cffc4ea143e036b9b8',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/5411c40ab2d6336d5fa46fc9480d5eab.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bf2b993a231a22d223b1ca82b20ba90',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/abb26db7810ea94cb072841ea50321b0.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bfae797bc09d493e3457ec54371a821',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/b106920b155a6acdde377e0bb9a311e9.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df7912133734d72bd6730b4488c96e52',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/68725d4358e280ceb8c1cb3ab557b519.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c406903a7eca48b4b6e5699305f4cdb0',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/bba5259c00b2777b8c870bb8fc52b1be.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2db248e37d39520c6e0c4a62503ee2df',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/82b5ec516bdcb2108f13a316bfac953f.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a178442a843589e7874b6880c2076aaa',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/78f3147243487075cbfe373ec4c058c7.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28521141294941f69711df1082d095d6',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/13189df8e48417da1cf90db088c026ea.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0efcf12f5631930e36869443832b57b1',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/534fd21d1918e63750f14dfc728ba037.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '785e71f08738697c9c2576218e411c31',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/0c44c28a4cbd9f3aa89e667255489a89.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '860c91331734fc9e117fbc7c3c9d84c5',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/6be12713d9fccfe35ab4a73cc5b084d2.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7767c44c37999028e7915834225e6d90',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/d723f660685e11e7ccb0f56aba9b4956.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ae39bfd812ef8c93fa5a21f21ff7579',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/a9037e6fa5d2022d64c53d68df4a6782.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739700f2153d81352c338ac7771a0b21',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/2b7631e1ab36c709c2eaad10231dc872.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7009d92700d940fe1069cfa93bd5a583',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/026ffa3dbf38074f782860e0e91be840.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d7a6a9e19421879e7fec341effe6b2e',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/6f89bd8ca4c19d99e699ddcd800cb154.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '305ce6da16cb346e93902aa4ab617b35',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/0b3c3c206bc3f038400b4525d944746e.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59a46de67f7e2ba7e5946c22266c0cc4',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/2c60e185a2f1475a71dc2f8b06793f81.vehicle',
      'namespace' => 'romanesco',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9543ac823fb2656f7aee1fad99d84fd',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/6fff997945294bc233b7b99217b8c60b.vehicle',
      'namespace' => 'romanesco',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7b7e816768f79edc07d3161bb4b674d',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/75dff8b6b7438e8fb9ea3c0294917efb.vehicle',
      'namespace' => 'romanesco',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c64d66d67d921cc142f4d59395928d',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/9b076b0f8604070b7cf717151fef582b.vehicle',
      'namespace' => 'romanesco',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b77a7979d4ea0b3e6a5e80616752183',
      'native_key' => 'formblocks.cb_input_date_id',
      'filename' => 'modSystemSetting/21cbd3dba93c57153a34a4b367b6a9d3.vehicle',
      'namespace' => 'romanesco',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b389adef021be1d59e9933c486b6d88',
      'native_key' => 'formblocks.cb_input_date_range_id',
      'filename' => 'modSystemSetting/8c26da4c5c7002eddfa2f8d28dc77507.vehicle',
      'namespace' => 'romanesco',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a26773edc7047c139e7b9ad31fd2f1d',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/32cb673bc9325e83b1ed22aa4b2835ec.vehicle',
      'namespace' => 'romanesco',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c547720354c7a00ddd5d459e37281fb',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/ae00ba6c992e927731a16f4f6d8d7fed.vehicle',
      'namespace' => 'romanesco',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0de237a6f5195e6cef5613e98c276427',
      'native_key' => NULL,
      'filename' => 'modCategory/5f568273b8c811928236e022bdb74605.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);