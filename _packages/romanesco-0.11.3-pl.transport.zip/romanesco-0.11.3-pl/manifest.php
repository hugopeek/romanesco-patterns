<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line

---

## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)

---

## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template

---

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c61864bcd119459aaacfcb8c78b1955e',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/8f286d4a3a5a56a1a3f2ea639fa13318.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca5e037bc5ba831b58892bfbd9311e9c',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/b2a5da3afa1277cfec8d9349aaf60db6.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f6d7cbd87d07ff5d5c82961a4a786c',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/c1debab5ca1e1c6bca5aedc90f3def97.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bed663aa17e80adb07450ba319b33fab',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/11082c03eccad155703a6c584b50b2b6.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f29ad006bd392c893824eaff57538ba',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/526d5d905bb6a857565b7ccbed3d5c32.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12f4277c10ea3248d5967774af742364',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/984de4c10734acc765490ddf98cb851d.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1589dbbf826ab690b90cb40eaa043779',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/ec75df3bbd566180c47695bb3a225a3b.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bcfc88914dbbb664fe7190f3510a807',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/b37bf2234e17471e244054512b527e35.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '042caea3ad78b4a0b21cff63e44437e7',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/c7e2315a760d65d8d927b7b4771559ec.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ff0036847edc56102f184401423503a',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/d39aedc24945f934b91d57c8749ace7f.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9db1746d5524750215f70ee78308a916',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/cc248a9e1d8877ce6b5b13178ac1b698.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30ae7ea072b4c58d49576bbe06fca66e',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/3516670f33a31dec85dadc5b537b67a8.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '692e7bec92a9a16be85b3f4c1eb4a5e3',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/6f5a99fcef5606f2517218d892d42aa3.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf1ad0f333feb74fe2b6875bfdd3425',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/09bdbaedeefc3a78358a80ca48521eb1.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd4f6b62e42989a06960913f302aa7b9',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/fe785b0d3af3c7286879d5e589f9b953.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f435aeea98bfd50ac04bd62e727ae9a',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/e9d2d284f738022726f7ee62f25b7872.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9d02dac609d296760c4aa413311cdca',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/4e538571854f1106abf61e37c6a16af8.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '461bcae24794aae174ad9459f5ba82d0',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/1798145a1e7a2d60997a3b8c2ee034c3.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebb38c9495e3c0e8b0cb4697a318bdf3',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/8fe7057e9e6a0ada0cfd967bd0218548.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa34355405bd79827c6fcf7c3b2d0602',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/4661b5275f60fec52b8b043a9ce2826b.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3542c06435f8f3ebb15bb008b7867a21',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/fea6e1940841683fa036e1711a178891.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6547c4ad945a1413a4df817610d264de',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/7970fb5a9dc8aa786f05577b35ee1c43.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '132446daddd5883e690efbd8895d9aef',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/c96df1a06ba7d4693bdc3b168c25602e.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e68c155caeeb0cc22550c3a4c8b3f6e1',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/9b6a3f22cc3e1bfaed804bdfa0f9dfe6.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68a64aaee49ba4a0c7d93db82e26a87f',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/ad5a99eb38010991fa16adbb129ddbfe.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15ac55648957d0d8a035f9f3b8b207fd',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/6debcd4c4e1f3117e63bd9a5c7dd076e.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b7e39547c30da626726343153d90cd',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/f2e0b65b212754edfb9402228f603f7b.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d53095dd19028f0956f932f1988065a',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/feb4b1523b85fe11649997b9c6c2f9af.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71bc7fe06a8e6336f3dce3e8188b107c',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/150a411193e014176d9d5e824df28a36.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4f6ee79ea4855a74ed6a84fb494aafb',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/011c55d58b213a6e7503e889e5e13934.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52879c331c1672103967d2e113be973',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/43d56f43633dcd94bf2b351f2872bd0d.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '758567a879aaf37914e1cae2c850c693',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/ffc08401d8d26f9d5874ee846ff2d8b7.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfba4e1f4beb5351912651e4861cbf32',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/2aa288ed328acec3fda5df7251b67c08.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22e759a843d196bab70a0a15adbde61a',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/627cadf6b89d1643431c30749566c735.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '033e7543d6d658253f76f0ca962c6eb3',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/508c3ffb9dff1b272572a0db8c696353.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5a04c244594bab38b30349ea94504c9',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/fb798678a958e02025d25ceda7b0cd1e.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab18ede160a725a6461ba5b03472bcba',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/cbd0fd105e24e95c2d1dcb02b21f8e90.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c58c2a69f173c6f4cb6b54bf006220',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/c60994c9973189a75af04163e0720570.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1e4c0bfa428470734c125680a33818c',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/6d4e5f901dfe2f2a9f236e7f3c3cf973.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e8694bc03975202750776e4b327acac',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/37ceeeded617b398bed857c448b77832.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc41d0a793f0a9dd67ba815ba8d6d4b5',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/8ff9c35bece354985a3a0c892ac13c2e.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '702d674ee88751ea18168d4db8622a3d',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/841f6902beb9ecd0a2b4c9ba39e2432b.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab89557e626590495d425fd13e70a01f',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/ae923cbe82ce171e6e1d615368283798.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '91d009cdc3ac37c621bab215eef9654d',
      'native_key' => NULL,
      'filename' => 'modCategory/c681099e52ec87d976226fcd08a35183.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);