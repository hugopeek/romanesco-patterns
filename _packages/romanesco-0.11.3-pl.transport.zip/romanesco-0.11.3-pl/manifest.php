<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line

---

## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)

---

## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template

---

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '96e4a615deacbc4c824bd42db4ce2ce0',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/9661855aeef4bea48fbe072658e76bfd.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86adab3d98ebf58acfb5db4a4ac035e5',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/ddf5cd56d1ad38b43a8cd13405ee00b2.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b39e10269d9d3a057a8c2cf298af98e',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/c64f5ec11ac5f89f3a46420b73060578.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8263527595b34e84d437958618c00f09',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/18052bf2fe33f24b3355ed6384084a97.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1f3c85faa51bffac764ea9feeecf77a',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/9f2d794f9dbe06b3624b13feafbc254b.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e4b6b96ad1ffeb038d81378fb4d1235',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/4f6db1f66cb19f8089d4a4a43c91f595.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d5e61272c4ebc0573331bad598bb045',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/8609a792c441e8fb99c39324bb7f769f.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd24f994ac20bc2a82298adaca9d4f9d9',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/a3d87b29843f4c29328f7439399fa44a.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58b169e5c105f798be95949f88828870',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/62d507ccead9437f82e346411ee6a0af.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4537c0945012d82e9e05c5efcbeece84',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/43797ef93da8529d98cdd3cb6905187a.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16d8af309d0383308ca1033c4e5ca36c',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/204734675e0445566b0052eac70ed5c9.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3413e01485b38fac6eb9045985bed35',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/2ef0cb814768597efd4033837676c300.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d58d14bc7dcb15a6ba36dd66f6dae8',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/574c1814fda3222b0b78400722fde234.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8939e653f5463143fc6071332adb8240',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/e4a68d7087914332e89168c185e6d4f0.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '625f367ff5d12b0944d9d2fc1411c331',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/05710acf9a2b27cca8104bc92b55f103.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592fde34f677b4c90bcbebfa26ecb529',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/9358da891f62770ea2578a0b90370a89.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f1c4b9e52d5206ce26e3800837bed0b',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/7dc519b9d3304a52f71a94db5d40ea53.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a86760b387f2ba06d5269f6d453e45',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/e7a571a104875d71e875baf5221969c3.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95d12af8b302cf5fdf5990f143f4356a',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/ba2de989421f92cacef8766eb9c74239.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a87cbfb4193d2b45e63228dc7e210a28',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/95a7335480e0c3946ceeb0702a1075da.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '337ce9557b38c2aa7761b3bfb6563b1d',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/11e54cf2c8a829948baca8607f85f157.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c86d0fb29a3ff15d52b97b7fc6679e6',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/e2425f51aec0a95604db4e10395ea30e.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0be8915fe1434ae0f27c0d5671b4dca5',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/0e73bc58282367ba27a4ed9eff2ad0ce.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a766c882b955b0341f11523f2305f84e',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/82ffa6ab89731098cfed239a6a2e0952.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e30a9eefd102f2acf9d7af0aedc63dbe',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/3e15678b946683fa4a943b7c439b1c40.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdbbdc8505b0b226bb08190ac3d954d8',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/adf48263dec6b16b8c988fe703328090.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7a4723fe5bd634867893f63a782a04c',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/6fa27259d45f4b6cd1e7ac93c7ea1a5d.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2924bb6d9f1ada6f53354e3f9b257d9',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/c2186c54d216a9afb391a394084b15e4.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dedbf567206d135999dceaa38d501f22',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/aa1cad0e57ad8370a878eff10304f187.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a37f82e26f77177913919d992e78f290',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/3943b3b897146f09168cedfc26ebd69d.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ffbf490a2163777c806c1e7252c7659',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/05d3fb576ce823536979dc4be57e8fba.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760e1653332b166a4c9cc23905cc70ef',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/d5943fa2a200f2d18454f1628426fce7.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5640bbcd90091ab685ffe75d684b9ef',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/569bd38aa00bfe4894515c48f64aa44a.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc5db204c120cb8abe39fad1109f00a3',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/1bebc45b24a3dd6dd1d037e7bec2bc26.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40956b955ff971759f3b67df014dade2',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/a8c79676287197f6f0e6b9d078b3c8c2.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59e48fdafdc5967cccca89e166c59447',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/6634ed6c8c2bb3775ea49ef5d3c3758c.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af715c8a3195177f79fc6c186d331e98',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/d834dfc0b00859aa90c614197eb0f19b.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73def33776548497179c4fd418578a43',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/bb8ffdf51d46f108d9ee9246fe6f8a23.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6808cc25a825aeefa2a5b7d80411a2a',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/64dca036b320b2f70340f7d648ed3c00.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '375e05593e8aa5f99a1ce2814af68dae',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/dffaeffc0431f601ab0473d3389ca5a7.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3a8ed379b81afb0978fb36a33f6da97',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/e7e68bf90f87bc8a99c9f2e6840efdd4.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48aa7060608b9c8474957e19c71b80ce',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/72cdde5accb514ea089548a459ae4b8c.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0445fec8343c70a8a213a4118571897c',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/700ffa532ec4f837679b6fa09c3f717f.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '90b54d3ca73af42e2dd3b29784498e19',
      'native_key' => NULL,
      'filename' => 'modCategory/a6675810740fd08b9a163bff4c6aa06e.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);