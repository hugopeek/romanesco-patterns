<?php
$modx->lexicon->load('romanescobackyard:default');