<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'adc81d3cbb1923d3f3494df3db5ecbf9',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/a8b74c5356de34c4a7fbe8bc285cd14e.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42b91152e402cef78c61012c1237ab08',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/0d3105595db9843f13d104306d1be0a2.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ed4e8bd0bc7f3e0dd415d4be2ea3fba',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/f16a6c7dc32c14dbc914d6a4c77c575e.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddaaf43533687bf90db75ab069f812e4',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/3e9af9b75d329d375b4d2181d8eeb3a2.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23850ddd94e58b2629260c32beb7992f',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/9ebd86dc9a227ef4f62b5dd79df440f2.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6101714fbc190436c5b1b455990843e0',
      'native_key' => NULL,
      'filename' => 'modCategory/e626dd7a56fe60f82c198c47605bb724.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);