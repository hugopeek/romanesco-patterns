<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8363fb53fc013a2a6bf3891a5e5f98bb',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/3857e7a425cbbd43e5506dea53c7b188.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a7b352fe73f5633ac5a75b8d97f167f',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/99208d55e597a02d2b20ef244ffca267.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c60bebc7e4bffb9fa53b1ee94841ad8e',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/9039aefea221b4e835c664e7e5977fd5.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '686316837a7550db7b8a2645e530d727',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/6ea40f47e039b1fdcf5fec4f5773e928.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '608a04f84f86d5a9e7c58e047922a7cd',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/b03a948f9ddaf8107a089383e9d7e44e.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44cf099bda85c004b4f64d8aebb1f76f',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/78598d7680da8f61db10b2248b259f33.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a5c28d3abd6f9b9f61bc05a7231e59',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/7ac29b0f57169db09dd363b3825a6542.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce5f1e4c09d007fe0d389e417392d333',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/cac92eace7bb05e481f653ba25e4d1c0.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '336ede47184cd24891d1a4606933fa5f',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/05ff593f3f9415576ebd3cb79f85c471.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c690f331b4d523e652af3bab561c282',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/166ed252a9da66bf16d98434cdd54e3f.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede2318b00158a766be8960a230d9bc1',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/3fc2da0aae915563fb13ae58a196ac0c.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a6e865356ed49a008c97464c8f88066',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/eb411ccc92930a8f348d1c6f12816a36.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57205042b19de03c1c9de63bf2becd3a',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/678436eca5163cb50bae752696e981a9.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bd8957f094d2725a2bb9e1338c9d726',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/b39b53747b91abfacbf9238df7ef9019.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7336608a8ff7d001946f8f9a89c1e97a',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/f435b832ab3af020cdbe9aaa7316e0b3.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdfee333b5f27d30bf43b90aa2df3895',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/9059e66a9d5245e44953c52eb2daac05.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f19f373ffc83be7e858716721dd55480',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/106c78354d86f419edc87b0fdc15a260.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55d596aa764c8d2542af758a917cbff0',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/d2808fe99909da3ce34f63439a9e73d6.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77fcb07fde2b6a3be40f84b6b42523dc',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/07aee7f5275e4238caa4357b7640c5fc.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe6d1fffa09a999e621ae4167b8b54d',
      'native_key' => 'patternlab.global_footer_id',
      'filename' => 'modSystemSetting/453c9e42ed602c7f7935cb6c81112604.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0ef41b7d13c0d76ed47f3fe8df7d38',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/f653b433e4e77a1c29082144031026ab.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14e9a95f06c4601c717a49ce2c636fdd',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/3f78d0d10c776d9ef4bedaf53f3e0bee.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '794deb2727c1e963941eea7de836db3a',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/a3b320c70bf651361c6dc315abe95b69.vehicle',
      'namespace' => 'patternlab',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b65ddeb2ef5a28f768fd2532880138e9',
      'native_key' => NULL,
      'filename' => 'modCategory/8be556e4e6f299a3c5f5d3cc8f53f99b.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);