<?php
$modx->lexicon->load('patternlab:formblocks');