<?php
$modx->controller->addLexiconTopic('patternlab:formblocks');