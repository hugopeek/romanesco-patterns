<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '### GNU GENERAL PUBLIC LICENSE

Version 3, 29 June 2007

Copyright (C) 2007 Free Software Foundation, Inc.
<https://fsf.org/>

Everyone is permitted to copy and distribute verbatim copies of this
license document, but changing it is not allowed.

### Preamble

The GNU General Public License is a free, copyleft license for
software and other kinds of works.

The licenses for most software and other practical works are designed
to take away your freedom to share and change the works. By contrast,
the GNU General Public License is intended to guarantee your freedom
to share and change all versions of a program--to make sure it remains
free software for all its users. We, the Free Software Foundation, use
the GNU General Public License for most of our software; it applies
also to any other work released this way by its authors. You can apply
it to your programs, too.

When we speak of free software, we are referring to freedom, not
price. Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

To protect your rights, we need to prevent others from denying you
these rights or asking you to surrender the rights. Therefore, you
have certain responsibilities if you distribute copies of the
software, or if you modify it: responsibilities to respect the freedom
of others.

For example, if you distribute copies of such a program, whether
gratis or for a fee, you must pass on to the recipients the same
freedoms that you received. You must make sure that they, too, receive
or can get the source code. And you must show them these terms so they
know their rights.

Developers that use the GNU GPL protect your rights with two steps:
(1) assert copyright on the software, and (2) offer you this License
giving you legal permission to copy, distribute and/or modify it.

For the developers\' and authors\' protection, the GPL clearly explains
that there is no warranty for this free software. For both users\' and
authors\' sake, the GPL requires that modified versions be marked as
changed, so that their problems will not be attributed erroneously to
authors of previous versions.

Some devices are designed to deny users access to install or run
modified versions of the software inside them, although the
manufacturer can do so. This is fundamentally incompatible with the
aim of protecting users\' freedom to change the software. The
systematic pattern of such abuse occurs in the area of products for
individuals to use, which is precisely where it is most unacceptable.
Therefore, we have designed this version of the GPL to prohibit the
practice for those products. If such problems arise substantially in
other domains, we stand ready to extend this provision to those
domains in future versions of the GPL, as needed to protect the
freedom of users.

Finally, every program is threatened constantly by software patents.
States should not allow patents to restrict development and use of
software on general-purpose computers, but in those that do, we wish
to avoid the special danger that patents applied to a free program
could make it effectively proprietary. To prevent this, the GPL
assures that patents cannot be used to render the program non-free.

The precise terms and conditions for copying, distribution and
modification follow.

### TERMS AND CONDITIONS

#### 0. Definitions.

"This License" refers to version 3 of the GNU General Public License.

"Copyright" also means copyright-like laws that apply to other kinds
of works, such as semiconductor masks.

"The Program" refers to any copyrightable work licensed under this
License. Each licensee is addressed as "you". "Licensees" and
"recipients" may be individuals or organizations.

To "modify" a work means to copy from or adapt all or part of the work
in a fashion requiring copyright permission, other than the making of
an exact copy. The resulting work is called a "modified version" of
the earlier work or a work "based on" the earlier work.

A "covered work" means either the unmodified Program or a work based
on the Program.

To "propagate" a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except executing it on a
computer or modifying a private copy. Propagation includes copying,
distribution (with or without modification), making available to the
public, and in some countries other activities as well.

To "convey" a work means any kind of propagation that enables other
parties to make or receive copies. Mere interaction with a user
through a computer network, with no transfer of a copy, is not
conveying.

An interactive user interface displays "Appropriate Legal Notices" to
the extent that it includes a convenient and prominently visible
feature that (1) displays an appropriate copyright notice, and (2)
tells the user that there is no warranty for the work (except to the
extent that warranties are provided), that licensees may convey the
work under this License, and how to view a copy of this License. If
the interface presents a list of user commands or options, such as a
menu, a prominent item in the list meets this criterion.

#### 1. Source Code.

The "source code" for a work means the preferred form of the work for
making modifications to it. "Object code" means any non-source form of
a work.

A "Standard Interface" means an interface that either is an official
standard defined by a recognized standards body, or, in the case of
interfaces specified for a particular programming language, one that
is widely used among developers working in that language.

The "System Libraries" of an executable work include anything, other
than the work as a whole, that (a) is included in the normal form of
packaging a Major Component, but which is not part of that Major
Component, and (b) serves only to enable use of the work with that
Major Component, or to implement a Standard Interface for which an
implementation is available to the public in source code form. A
"Major Component", in this context, means a major essential component
(kernel, window system, and so on) of the specific operating system
(if any) on which the executable work runs, or a compiler used to
produce the work, or an object code interpreter used to run it.

The "Corresponding Source" for a work in object code form means all
the source code needed to generate, install, and (for an executable
work) run the object code and to modify the work, including scripts to
control those activities. However, it does not include the work\'s
System Libraries, or general-purpose tools or generally available free
programs which are used unmodified in performing those activities but
which are not part of the work. For example, Corresponding Source
includes interface definition files associated with source files for
the work, and the source code for shared libraries and dynamically
linked subprograms that the work is specifically designed to require,
such as by intimate data communication or control flow between those
subprograms and other parts of the work.

The Corresponding Source need not include anything that users can
regenerate automatically from other parts of the Corresponding Source.

The Corresponding Source for a work in source code form is that same
work.

#### 2. Basic Permissions.

All rights granted under this License are granted for the term of
copyright on the Program, and are irrevocable provided the stated
conditions are met. This License explicitly affirms your unlimited
permission to run the unmodified Program. The output from running a
covered work is covered by this License only if the output, given its
content, constitutes a covered work. This License acknowledges your
rights of fair use or other equivalent, as provided by copyright law.

You may make, run and propagate covered works that you do not convey,
without conditions so long as your license otherwise remains in force.
You may convey covered works to others for the sole purpose of having
them make modifications exclusively for you, or provide you with
facilities for running those works, provided that you comply with the
terms of this License in conveying all material for which you do not
control copyright. Those thus making or running the covered works for
you must do so exclusively on your behalf, under your direction and
control, on terms that prohibit them from making any copies of your
copyrighted material outside their relationship with you.

Conveying under any other circumstances is permitted solely under the
conditions stated below. Sublicensing is not allowed; section 10 makes
it unnecessary.

#### 3. Protecting Users\' Legal Rights From Anti-Circumvention Law.

No covered work shall be deemed part of an effective technological
measure under any applicable law fulfilling obligations under article
11 of the WIPO copyright treaty adopted on 20 December 1996, or
similar laws prohibiting or restricting circumvention of such
measures.

When you convey a covered work, you waive any legal power to forbid
circumvention of technological measures to the extent such
circumvention is effected by exercising rights under this License with
respect to the covered work, and you disclaim any intention to limit
operation or modification of the work as a means of enforcing, against
the work\'s users, your or third parties\' legal rights to forbid
circumvention of technological measures.

#### 4. Conveying Verbatim Copies.

You may convey verbatim copies of the Program\'s source code as you
receive it, in any medium, provided that you conspicuously and
appropriately publish on each copy an appropriate copyright notice;
keep intact all notices stating that this License and any
non-permissive terms added in accord with section 7 apply to the code;
keep intact all notices of the absence of any warranty; and give all
recipients a copy of this License along with the Program.

You may charge any price or no price for each copy that you convey,
and you may offer support or warranty protection for a fee.

#### 5. Conveying Modified Source Versions.

You may convey a work based on the Program, or the modifications to
produce it from the Program, in the form of source code under the
terms of section 4, provided that you also meet all of these
conditions:

-   a) The work must carry prominent notices stating that you modified
    it, and giving a relevant date.
-   b) The work must carry prominent notices stating that it is
    released under this License and any conditions added under
    section 7. This requirement modifies the requirement in section 4
    to "keep intact all notices".
-   c) You must license the entire work, as a whole, under this
    License to anyone who comes into possession of a copy. This
    License will therefore apply, along with any applicable section 7
    additional terms, to the whole of the work, and all its parts,
    regardless of how they are packaged. This License gives no
    permission to license the work in any other way, but it does not
    invalidate such permission if you have separately received it.
-   d) If the work has interactive user interfaces, each must display
    Appropriate Legal Notices; however, if the Program has interactive
    interfaces that do not display Appropriate Legal Notices, your
    work need not make them do so.

A compilation of a covered work with other separate and independent
works, which are not by their nature extensions of the covered work,
and which are not combined with it such as to form a larger program,
in or on a volume of a storage or distribution medium, is called an
"aggregate" if the compilation and its resulting copyright are not
used to limit the access or legal rights of the compilation\'s users
beyond what the individual works permit. Inclusion of a covered work
in an aggregate does not cause this License to apply to the other
parts of the aggregate.

#### 6. Conveying Non-Source Forms.

You may convey a covered work in object code form under the terms of
sections 4 and 5, provided that you also convey the machine-readable
Corresponding Source under the terms of this License, in one of these
ways:

-   a) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by the
    Corresponding Source fixed on a durable physical medium
    customarily used for software interchange.
-   b) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by a
    written offer, valid for at least three years and valid for as
    long as you offer spare parts or customer support for that product
    model, to give anyone who possesses the object code either (1) a
    copy of the Corresponding Source for all the software in the
    product that is covered by this License, on a durable physical
    medium customarily used for software interchange, for a price no
    more than your reasonable cost of physically performing this
    conveying of source, or (2) access to copy the Corresponding
    Source from a network server at no charge.
-   c) Convey individual copies of the object code with a copy of the
    written offer to provide the Corresponding Source. This
    alternative is allowed only occasionally and noncommercially, and
    only if you received the object code with such an offer, in accord
    with subsection 6b.
-   d) Convey the object code by offering access from a designated
    place (gratis or for a charge), and offer equivalent access to the
    Corresponding Source in the same way through the same place at no
    further charge. You need not require recipients to copy the
    Corresponding Source along with the object code. If the place to
    copy the object code is a network server, the Corresponding Source
    may be on a different server (operated by you or a third party)
    that supports equivalent copying facilities, provided you maintain
    clear directions next to the object code saying where to find the
    Corresponding Source. Regardless of what server hosts the
    Corresponding Source, you remain obligated to ensure that it is
    available for as long as needed to satisfy these requirements.
-   e) Convey the object code using peer-to-peer transmission,
    provided you inform other peers where the object code and
    Corresponding Source of the work are being offered to the general
    public at no charge under subsection 6d.

A separable portion of the object code, whose source code is excluded
from the Corresponding Source as a System Library, need not be
included in conveying the object code work.

A "User Product" is either (1) a "consumer product", which means any
tangible personal property which is normally used for personal,
family, or household purposes, or (2) anything designed or sold for
incorporation into a dwelling. In determining whether a product is a
consumer product, doubtful cases shall be resolved in favor of
coverage. For a particular product received by a particular user,
"normally used" refers to a typical or common use of that class of
product, regardless of the status of the particular user or of the way
in which the particular user actually uses, or expects or is expected
to use, the product. A product is a consumer product regardless of
whether the product has substantial commercial, industrial or
non-consumer uses, unless such uses represent the only significant
mode of use of the product.

"Installation Information" for a User Product means any methods,
procedures, authorization keys, or other information required to
install and execute modified versions of a covered work in that User
Product from a modified version of its Corresponding Source. The
information must suffice to ensure that the continued functioning of
the modified object code is in no case prevented or interfered with
solely because modification has been made.

If you convey an object code work under this section in, or with, or
specifically for use in, a User Product, and the conveying occurs as
part of a transaction in which the right of possession and use of the
User Product is transferred to the recipient in perpetuity or for a
fixed term (regardless of how the transaction is characterized), the
Corresponding Source conveyed under this section must be accompanied
by the Installation Information. But this requirement does not apply
if neither you nor any third party retains the ability to install
modified object code on the User Product (for example, the work has
been installed in ROM).

The requirement to provide Installation Information does not include a
requirement to continue to provide support service, warranty, or
updates for a work that has been modified or installed by the
recipient, or for the User Product in which it has been modified or
installed. Access to a network may be denied when the modification
itself materially and adversely affects the operation of the network
or violates the rules and protocols for communication across the
network.

Corresponding Source conveyed, and Installation Information provided,
in accord with this section must be in a format that is publicly
documented (and with an implementation available to the public in
source code form), and must require no special password or key for
unpacking, reading or copying.

#### 7. Additional Terms.

"Additional permissions" are terms that supplement the terms of this
License by making exceptions from one or more of its conditions.
Additional permissions that are applicable to the entire Program shall
be treated as though they were included in this License, to the extent
that they are valid under applicable law. If additional permissions
apply only to part of the Program, that part may be used separately
under those permissions, but the entire Program remains governed by
this License without regard to the additional permissions.

When you convey a copy of a covered work, you may at your option
remove any additional permissions from that copy, or from any part of
it. (Additional permissions may be written to require their own
removal in certain cases when you modify the work.) You may place
additional permissions on material, added by you to a covered work,
for which you have or can give appropriate copyright permission.

Notwithstanding any other provision of this License, for material you
add to a covered work, you may (if authorized by the copyright holders
of that material) supplement the terms of this License with terms:

-   a) Disclaiming warranty or limiting liability differently from the
    terms of sections 15 and 16 of this License; or
-   b) Requiring preservation of specified reasonable legal notices or
    author attributions in that material or in the Appropriate Legal
    Notices displayed by works containing it; or
-   c) Prohibiting misrepresentation of the origin of that material,
    or requiring that modified versions of such material be marked in
    reasonable ways as different from the original version; or
-   d) Limiting the use for publicity purposes of names of licensors
    or authors of the material; or
-   e) Declining to grant rights under trademark law for use of some
    trade names, trademarks, or service marks; or
-   f) Requiring indemnification of licensors and authors of that
    material by anyone who conveys the material (or modified versions
    of it) with contractual assumptions of liability to the recipient,
    for any liability that these contractual assumptions directly
    impose on those licensors and authors.

All other non-permissive additional terms are considered "further
restrictions" within the meaning of section 10. If the Program as you
received it, or any part of it, contains a notice stating that it is
governed by this License along with a term that is a further
restriction, you may remove that term. If a license document contains
a further restriction but permits relicensing or conveying under this
License, you may add to a covered work material governed by the terms
of that license document, provided that the further restriction does
not survive such relicensing or conveying.

If you add terms to a covered work in accord with this section, you
must place, in the relevant source files, a statement of the
additional terms that apply to those files, or a notice indicating
where to find the applicable terms.

Additional terms, permissive or non-permissive, may be stated in the
form of a separately written license, or stated as exceptions; the
above requirements apply either way.

#### 8. Termination.

You may not propagate or modify a covered work except as expressly
provided under this License. Any attempt otherwise to propagate or
modify it is void, and will automatically terminate your rights under
this License (including any patent licenses granted under the third
paragraph of section 11).

However, if you cease all violation of this License, then your license
from a particular copyright holder is reinstated (a) provisionally,
unless and until the copyright holder explicitly and finally
terminates your license, and (b) permanently, if the copyright holder
fails to notify you of the violation by some reasonable means prior to
60 days after the cessation.

Moreover, your license from a particular copyright holder is
reinstated permanently if the copyright holder notifies you of the
violation by some reasonable means, this is the first time you have
received notice of violation of this License (for any work) from that
copyright holder, and you cure the violation prior to 30 days after
your receipt of the notice.

Termination of your rights under this section does not terminate the
licenses of parties who have received copies or rights from you under
this License. If your rights have been terminated and not permanently
reinstated, you do not qualify to receive new licenses for the same
material under section 10.

#### 9. Acceptance Not Required for Having Copies.

You are not required to accept this License in order to receive or run
a copy of the Program. Ancillary propagation of a covered work
occurring solely as a consequence of using peer-to-peer transmission
to receive a copy likewise does not require acceptance. However,
nothing other than this License grants you permission to propagate or
modify any covered work. These actions infringe copyright if you do
not accept this License. Therefore, by modifying or propagating a
covered work, you indicate your acceptance of this License to do so.

#### 10. Automatic Licensing of Downstream Recipients.

Each time you convey a covered work, the recipient automatically
receives a license from the original licensors, to run, modify and
propagate that work, subject to this License. You are not responsible
for enforcing compliance by third parties with this License.

An "entity transaction" is a transaction transferring control of an
organization, or substantially all assets of one, or subdividing an
organization, or merging organizations. If propagation of a covered
work results from an entity transaction, each party to that
transaction who receives a copy of the work also receives whatever
licenses to the work the party\'s predecessor in interest had or could
give under the previous paragraph, plus a right to possession of the
Corresponding Source of the work from the predecessor in interest, if
the predecessor has it or can get it with reasonable efforts.

You may not impose any further restrictions on the exercise of the
rights granted or affirmed under this License. For example, you may
not impose a license fee, royalty, or other charge for exercise of
rights granted under this License, and you may not initiate litigation
(including a cross-claim or counterclaim in a lawsuit) alleging that
any patent claim is infringed by making, using, selling, offering for
sale, or importing the Program or any portion of it.

#### 11. Patents.

A "contributor" is a copyright holder who authorizes use under this
License of the Program or a work on which the Program is based. The
work thus licensed is called the contributor\'s "contributor version".

A contributor\'s "essential patent claims" are all patent claims owned
or controlled by the contributor, whether already acquired or
hereafter acquired, that would be infringed by some manner, permitted
by this License, of making, using, or selling its contributor version,
but do not include claims that would be infringed only as a
consequence of further modification of the contributor version. For
purposes of this definition, "control" includes the right to grant
patent sublicenses in a manner consistent with the requirements of
this License.

Each contributor grants you a non-exclusive, worldwide, royalty-free
patent license under the contributor\'s essential patent claims, to
make, use, sell, offer for sale, import and otherwise run, modify and
propagate the contents of its contributor version.

In the following three paragraphs, a "patent license" is any express
agreement or commitment, however denominated, not to enforce a patent
(such as an express permission to practice a patent or covenant not to
sue for patent infringement). To "grant" such a patent license to a
party means to make such an agreement or commitment not to enforce a
patent against the party.

If you convey a covered work, knowingly relying on a patent license,
and the Corresponding Source of the work is not available for anyone
to copy, free of charge and under the terms of this License, through a
publicly available network server or other readily accessible means,
then you must either (1) cause the Corresponding Source to be so
available, or (2) arrange to deprive yourself of the benefit of the
patent license for this particular work, or (3) arrange, in a manner
consistent with the requirements of this License, to extend the patent
license to downstream recipients. "Knowingly relying" means you have
actual knowledge that, but for the patent license, your conveying the
covered work in a country, or your recipient\'s use of the covered work
in a country, would infringe one or more identifiable patents in that
country that you have reason to believe are valid.

If, pursuant to or in connection with a single transaction or
arrangement, you convey, or propagate by procuring conveyance of, a
covered work, and grant a patent license to some of the parties
receiving the covered work authorizing them to use, propagate, modify
or convey a specific copy of the covered work, then the patent license
you grant is automatically extended to all recipients of the covered
work and works based on it.

A patent license is "discriminatory" if it does not include within the
scope of its coverage, prohibits the exercise of, or is conditioned on
the non-exercise of one or more of the rights that are specifically
granted under this License. You may not convey a covered work if you
are a party to an arrangement with a third party that is in the
business of distributing software, under which you make payment to the
third party based on the extent of your activity of conveying the
work, and under which the third party grants, to any of the parties
who would receive the covered work from you, a discriminatory patent
license (a) in connection with copies of the covered work conveyed by
you (or copies made from those copies), or (b) primarily for and in
connection with specific products or compilations that contain the
covered work, unless you entered into that arrangement, or that patent
license was granted, prior to 28 March 2007.

Nothing in this License shall be construed as excluding or limiting
any implied license or other defenses to infringement that may
otherwise be available to you under applicable patent law.

#### 12. No Surrender of Others\' Freedom.

If conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License. If you cannot convey a
covered work so as to satisfy simultaneously your obligations under
this License and any other pertinent obligations, then as a
consequence you may not convey it at all. For example, if you agree to
terms that obligate you to collect a royalty for further conveying
from those to whom you convey the Program, the only way you could
satisfy both those terms and this License would be to refrain entirely
from conveying the Program.

#### 13. Use with the GNU Affero General Public License.

Notwithstanding any other provision of this License, you have
permission to link or combine any covered work with a work licensed
under version 3 of the GNU Affero General Public License into a single
combined work, and to convey the resulting work. The terms of this
License will continue to apply to the part which is the covered work,
but the special requirements of the GNU Affero General Public License,
section 13, concerning interaction through a network will apply to the
combination as such.

#### 14. Revised Versions of this License.

The Free Software Foundation may publish revised and/or new versions
of the GNU General Public License from time to time. Such new versions
will be similar in spirit to the present version, but may differ in
detail to address new problems or concerns.

Each version is given a distinguishing version number. If the Program
specifies that a certain numbered version of the GNU General Public
License "or any later version" applies to it, you have the option of
following the terms and conditions either of that numbered version or
of any later version published by the Free Software Foundation. If the
Program does not specify a version number of the GNU General Public
License, you may choose any version ever published by the Free
Software Foundation.

If the Program specifies that a proxy can decide which future versions
of the GNU General Public License can be used, that proxy\'s public
statement of acceptance of a version permanently authorizes you to
choose that version for the Program.

Later license versions may give you additional or different
permissions. However, no additional obligations are imposed on any
author or copyright holder as a result of your choosing to follow a
later version.

#### 15. Disclaimer of Warranty.

THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND
PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE
DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR
CORRECTION.

#### 16. Limitation of Liability.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR
CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT
NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR
LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM
TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER
PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

#### 17. Interpretation of Sections 15 and 16.

If the disclaimer of warranty and limitation of liability provided
above cannot be given local legal effect according to their terms,
reviewing courts shall apply local law that most closely approximates
an absolute waiver of all civil liability in connection with the
Program, unless a warranty or assumption of liability accompanies a
copy of the Program in return for a fee.

END OF TERMS AND CONDITIONS

### How to Apply These Terms to Your New Programs

If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these
terms.

To do so, attach the following notices to the program. It is safest to
attach them to the start of each source file to most effectively state
the exclusion of warranty; and each file should have at least the
"copyright" line and a pointer to where the full notice is found.

        <one line to give the program\'s name and a brief idea of what it does.>
        Copyright (C) <year>  <name of author>

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License, or
        (at your option) any later version.

        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <https://www.gnu.org/licenses/>.

Also add information on how to contact you by electronic and paper
mail.

If the program does terminal interaction, make it output a short
notice like this when it starts in an interactive mode:

        <program>  Copyright (C) <year>  <name of author>
        This program comes with ABSOLUTELY NO WARRANTY; for details type `show w\'.
        This is free software, and you are welcome to redistribute it
        under certain conditions; type `show c\' for details.

The hypothetical commands \\`show w\' and \\`show c\' should show the
appropriate parts of the General Public License. Of course, your
program\'s commands might be different; for a GUI interface, you would
use an "about box".

You should also get your employer (if you work as a programmer) or
school, if any, to sign a "copyright disclaimer" for the program, if
necessary. For more information on this, and how to apply and follow
the GNU GPL, see <https://www.gnu.org/licenses/>.

The GNU General Public License does not permit incorporating your
program into proprietary programs. If your program is a subroutine
library, you may consider it more useful to permit linking proprietary
applications with the library. If this is what you want to do, use the
GNU Lesser General Public License instead of this License. But first,
please read <https://www.gnu.org/licenses/why-not-lgpl.html>.
',
    'readme' => '',
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 1.0.0-beta12
Released on April 10, 2023

New features:
- Add setting to hide ContentBlocks fields

Fixes and improvements:
- Modify hide advanced feature to accept list of CB settings
- Add Dashboard template to template list
- Invert Table and Steps elements inside inverted segments
- Add URL parameter to invert layouts in Backyard
- Fix image quality overrides being ignored
- Use HTML value in email report if field label is empty
- Add field width option for inline form fields
- Fix nested fields not being processed in form report
- Fix non-alpha characters breaking titles in inline SVGs
- Fix repeated values in form fieldset IDs
- Fix repeated values in form validation prompts
- Fix inverted headings and buttons inside forms with light background
- Remove role="main" from main tags
- Fix various image alt tags
- Improve controls for inlining SVGs
- Prevent Organization logos becoming too big on smaller screens
- Remove comma after last entry in responsive img sizes attribute
- Improve primary / secondary button styling on colored backgrounds
- Forward missing text_size and show_rating setting in Testimonial overviews
- Add ability to change divider heading level
- Allow title format override at template level

## Romanesco Patterns 1.0.0-beta11
Released on February 2, 2023

Fixes and improvements:
- Replace Squoosh command with libvips
- Add property for changing alt field in imgOverview chunks
- Fix Squoosh command failing with escaped path variable
- Rename GenerateStaticCSS snippet to GenerateSiteCSS
- Improve clearing of custom cache
- Include layout ID in overview placeholder prefix
- Rename Tool Shed to Project Data
- Include modified Hits snippet, to prevent fatal errors in PHP 8
- Turn footer type TV into selector, to accommodate larger lists
- Only activate mousewheel scrolling on focus in rendered Leaflet map

## Romanesco Patterns 1.0.0-beta10
Released on October 28, 2022

New features:
- Add ability to submit forms via Ajax (Experimental)
- Add template for generating BackstopJS regression test configuration

Fixes and improvements:
- Load Leaflet assets directly (without CDN)
- Define variables that could potentially be empty (for PHP 8 compatibility)
- Disable Jquery fallback and only load from local source in dev mode
- Cache form validation elements
- Exclude empty templates when generating critical CSS
- Remove parallel option from generate CSS commands
- Execute Squoosh optimization via runCommand (Symfony Process)
- Fix images being optimized with empty quality setting
- Fix thumbnail errors when x/y value is negative
- Prevent optimising of images without valid path
- Minify CSS via task queue (if Scheduler is installed)
- Validate CSS before saving Global Backgrounds
- Fix open in new window option in Image with Link CB
- Add option to show CB table rows as cards on mobile
- Add chunks for Table CB templates
- Change button to bottom attached in Card CB
- Fix slider after updating Swiper to v8
- Check for autoloaded HtmlPageDom class in plugins
- Fix broken references in status grid and project timeline
- Load overview images with chunk (resolves repeating image issue in fluid tpl)
- Add overviewRowImageBasicOverlay chunk to config
- Use navbar_size setting to define dropdown ToC size
- Add cases for loading Toast and Flag assets
- Use custom dist path to fetch Form and Calendar CSS
- Hide local submenu level up link if parent is hidden in menu
- Apply alignment to content element in card overviews

## Romanesco Patterns 1.0.0-beta9
Released on May 24, 2022

New features:
- Add option to show sidebar on mobile (below content)
- Add option to show CTA in sidebar
- Add local submenu variant (only shows children of current page)
- Add reusable buttons for social connections and sharing

Fixes and improvements:
- Deprecate social media TVs
- Add FormBlocks dropdown row for resources
- Rename element categories for consistency and prefix TV categories
- Minify custom CSS regardless of configuration setting
- Invert secondary menu inside segments with inverted background
- Load frontend lexicon OnHandleRequest
- Load FormBlocks forms only in specific context if placed in subfolder
- Collapse or expand target container when reloading Show/Hide option
- Don\'t disable completed steps when backtracking in multi-step forms
- Fix frontend validation not working in multi-step forms
- Add option to hide advanced CB features in manager
- Add missing setBackground modifier to rich text segment and several layouts
- Update patterns and structure in specific overviewRowFluid templates
- Prevent Overview classes placeholders from leaking their values
- Replace remaining If isnull comparisons with iselement
- Add TV to select which heading levels are included in the ToC menu
- Add layout options for dropdown and list views in ToC CB
- Fix empty srcset values when using the same image more than once on a page
- Load buttons, content images and card rows with chunk (instead of outputAsTpl)
- Don\'t load image tag if Gallery or Cards image is empty
- Add ability to define custom render hooks in FormBlocks forms 
- Add ability to choose different value type when using Input Options in forms
- Add option to FormBlocks fields to override the name attribute in HTML
- Add caching and optimize requests for Youtube and Vimeo thumbnails
- Remove nested troublemakers from headings in ToC menu
- Add error messages to date range fields 
- Add improved readability layout width (with normal text size)
- Add controls for inflated titles in main layout columns and CTAs
- Load jQuery from local source when offline
- Trim whitespace from edges if using clipString without value
- Fix Romanesco class not being loaded when creating automatic references
- Fix uid for imgResponsive chunks inside Image CBs

## Romanesco Patterns 1.0.0-beta8
Released on November 19, 2021

New features:
- Add option to automatically link to external references in content
- Add ability to crop regular content images
- Add widget to collect feedback from client browser (currently using Ybug)
- Add isEditor snippet to check if user is logged in to manager

Fixes and improvements:
- Add box shadow to Markdown images
- Turn external links TV into MIGXdb grid [BC]
- Don\'t generate critical CSS for Downloads
- Fix issue where slider would break if slides are separate Image CBs
- Prevent content in Presentation template from being turned into a slider
- Add relevant settings from regular overview CBs to 2 column fluid overview
- Rename incorrect cols field to content_width in 2 column fluid overview [BC]
- Add quality override setting for global background image
- Optimize distribution of breakpoint values for responsive image srcsets
- Apply responsive image sizing to Cards CB
- Don\'t load SVG images with srcset and sizes in galleries
- Improve accuracy of responsive image sizes for stackable and doubling grids
- Improve structure of content and gallery image patterns
- Always round max height pixel values up to next whole number
- Make sure decimal separator is a \'.\' when rounding numbers
- Calculate correct thumb height in Open Graph image metadata
- Limit Open Graph metadata to 1 image
- Remove submit class from submit button container in forms
- Make front-end form validation compatible with Recaptcha v3
- Load headAdditional and footerAdditional chunks directly, if present
- Place rel element at front of external CSS links
- Defer loading of Leaflet JS
- Add missing rel stylesheet element to Leaflet CSS link
- Explicitly enable front-end validation in FormBlocks forms
- Abort optimization if image type is SVG
- Fix image optimization in srcset rows

## Romanesco Patterns 1.0.0-beta7
Released on October 21, 2021

New features:
- Add front-end validation to FormBlocks
- Add option to use Recaptcha v3 in forms
- Add ContentBlock with Table of Contents menu
- Add output modifier for pThumb to optimize image and generate WebP version

Fixes and improvements:
- Make sure inverted path configuration settings don\'t trigger CSS rebuild
- Fix scenario where getImageDimensions would not return width and height
- Make sure AjaxUpload scripts are run after jQuery is loaded
- Add missing upload_limit and max_file_size CB settings in AjaxUpload snippet
- Rename formblocks.antispam setting to formblocks.antispam_hooks
- Wait with loading Recaptcha v2 until form becomes active
- Move honeypot and recaptcha elements to separate (overridable) chunk
- Fix responsive content image sizes in stackable on tablet grids
- If grids are stackable on tablet, also show/hide designated mobile elements
- Use placeholder to detect ToC instead of toc_enabled_templates system setting
- Show ToC submenu in dropdown on tablet and mobile
- Move shared overview settings to separate molecules
- Fix regClient scripts not being parsed in Markdown pages on first load
- Load external JS from head with defer
- Load all conditional assets through a single snippet
- Don\'t use tag label variant anywhere (excluded from default semantic.css)
- Add SUI list class to ul and ol tags in Markdown (only at first level)
- Remove conditionals for empty logo paths (to clear media source path)
- Add theme variables for inverted logo paths
- Only load alternative_tracking_code if Google Analytics is empty
- Rename matomo_tracking_code to alternative_tracking_code
- Move Leaflet asset paths and integrity hashes to system settings
- Move img_breakpoints to system settings
- Add img_quality as system setting too (baseline for optional post-processing)
- Fix icon buttons in generated tab navigation
- Only preload backgrounds.css if critical CSS is enabled
- Add missing ID to FormBlocks dropdown select and math question fields
- Add lazy load setting to Overview Fluid layout

## Romanesco Patterns 1.0.0-beta6
Released on August 30, 2021

New features:
- Use Markdown content with any template

Fixes and improvements:
- Fix lists with connected patterns in front-end library
- Add class to empty grid columns
- Load conditional CSS assets and Google fonts asynchronously
- Load Google fonts with direct link and v2 syntax [BREAKING CHANGE]
- Add cbLayoutCTA chunk (not referenced directly)
- Make sure width or height is not 0 in fixed overview and gallery images
- Fix scenario where mobile-only slider would not return to original state
- Fix issues with slides not receiving correct width when initialized 
- Rename toolbarKnowledgeBase to toolbarNote
- Rename HeaderVertical templates to BasicVertical
- Merge NoteMarkdown and NoteContentBlocks templates
- Add option to show pages with hidden alias in breadcrumbs
- Rename cbOverviewRowImg chunks to imgOverview [BREAKING CHANGE]
- Fix critical CSS not being shared between templates (if configured)
- Set pagetitle as fallback for overview image ALT text

## Romanesco Patterns 1.0.0-beta5
Released on June 10, 2021

Fixes and improvements:
- Set default responsive image scaling value to 51
- Fix email not being sent when using dynamic emailTo (and empty regular field)
- Make sure placeholder prefixes are unique when generating background CSS
- Properly display MODX outer tags from Markdown files (if they\'ve been split)
- Add option to generate critical CSS for pages behind htpasswd wall
- Fix returnFirstHit snippet skipping over hits
- Add gallery lightbox after the footer (and not inside)
- Make Fibonacci sequence generator more flexible
- Let MODX clear overview cache if custom cache is disabled

## Romanesco Patterns 1.0.0-beta4
Released on April 19, 2021

New features:
- Add ability to schedule critical CSS generation
- Look for masthead chunk in header
- Add TV for overriding subtitle in Overviews
- Implement cache buster for static assets
- Add output modifier for replacing regex pattern

Fixes and improvements:
- Preload critical CSS file from HTML (disable HTTP/2 server push)
- Allow theme override for structured organization data
- Don\'t render theme chunks before checking if they exist
- Add iselement condition to modifiedIf
- Also manipulate DOM of Markdown resources
- Remove nested block level elements from heading tags
- Move most common subtitles out of heading tags
- Rename all headingHierarchy chunks to headingOverview [BREAKING CHANGE]
- Remove YAML front matter from Markdown notes
- Accept semantic version numbers for generated styling assets
- Move off-canvas navigation above content wrapper to prevent redraw in JS
- Add warning not to edit site.css directly
- Don\'t display globally excluded resources in Overviews either
- Prevent bad link tag errors from CTAs that don\'t have a link

## Romanesco Patterns 1.0.0-beta3
Released on February 20, 2021

New features:
- Load patterns dynamically in front-end library
- Add elements for displaying Vimeo embeds
- Add preview and status properties to all elements

Fixes and improvements:
- Center copyright footer content on mobile
- Add small credits badge with information popup to copyright footer
- Skip own element properties in returnFirstHit snippet
- Add option to adjust column size to content width in CB settings
- Scroll back to top after using pagination in overviews (can be disabled)
- Only display avatar image in publication elements if author page exists
- Add overview image template for ImagePlus with fixed dimensions
- Don\'t show hidden forms, CTAs, backgrounds and footers in CB selectors
- Fix behaviour and styling glitches in FormBlocks checkbox / radio fields
- Fix footer and footer CTA backgrounds referenced by ID
- Make sure unique_idx placeholder in overviews is actually unique
- Add system setting for defining templates with ToC
- Load Leaflet map assets via chunk
- Add ability to turn Cards CB into a slider
- Fix quality placeholder not being forwarded to responsive images srcsets
- Modify getElementDescription snippet to get other fields or property values
- Add raw placeholder chunks for tag and label
- Change HTML tag of footer CTA from footer to aside
- Load SUI form component asynchronous if critical CSS is enabled
- Fix issue where processor sometimes used stale alias in critical CSS snippet
- Save resource in critical CSS snippet, to generate TV value with file path
- Generate critical CSS with correct multi-context Configuration settings
- Correct depth and offset placeholders in overviews

## Romanesco Patterns 1.0.0-beta2
Released on November 3, 2020

Fixes and improvements:
- Remove head tag from head chunk [BREAKING CHANGE]
- Use Matomo by inserting full tracking code directly
- Make background in note templates transparent
- Fix leaking placeholders in global backgrounds CSS
- Fall back gracefully when critical CSS file not found
- Store full path to critical CSS file in a hidden TV
- Don\'t use minified SUI / project assets if Configuration setting is off
- Fix cols placeholder in overviews
- Limit overview grids to 2 rows in manager previews
- Accept additional responsive image scales
- Allow templates to override the critical CSS file of the page
- Add option to generate critical CSS in sequence instead of parallel
- Handle context aware configuration settings in critical CSS plugin
- Disable deprecated global backgrounds using MIGX TV

## Romanesco Patterns 1.0.0-beta1
Released on August 27, 2020

New features:
- Add ability to generate critical CSS for each resource

Fixes and improvements:
- Prevent empty logo path in Configuration from triggering a CSS rebuild
- Fix placeholder for due date in status grid
- Accept overview fallback images for each image type
- Don\'t transform input to lowercase in removeDuplicateLines snippet
- Don\'t add header class to content headers if they already have one
- Replace hardcoded Menu text in main nav with lexicon key
- Add classes with placeholder in main accordion navigation
- Fix background in article template introduction segment
- Fix path to default context CSS in GenerateStaticCSS
- Add ability to place slider controls outside of container
- Turn lightbox into fullscreen modal and lazy load images
- Make Gallery images sizes responsive
- Add option to lazy load Gallery images
- Add link rel options to Button and Image CBs
- Fix path to custom context CSS in GenerateStaticCSS

## Romanesco Patterns 0.16.4
Released on July 1, 2020

Fixes and improvements:
- Refactor main accordion menu
- Fix broken favicon file names and colors
- Add setting for custom favicon path
- Add option to activate FormSource in FormBlocks reports
- Add ability to change custom CSS path (per context, if needed)
- Create absolute path for CSS backgrounds that won\'t be thumbnailed
- Rename Semantic assets paths in system settings
- Correctly escape double quote and backslash characters in JSON-LD output

## Romanesco Patterns 0.16.3
Released on June 15, 2020

Fixes and improvements:
- Add scrolldir.js for displaying menu on mobile when scrolling up
- Add ability to override headerTitles chunk
- Load CB image settings with chunks
- Add caption and credits to Image CB
- Add positioning and sizing options to Image CB
- Point to separate gulpfile when generating CSS per context
- Update Jquery to v3.5.1
- Fix static downloads not having any content
- Write theme.variables output directly to file
- Make UpdateStyling plugin work with context-aware Configuration settings
- Fix form redirectTo placeholder not always returning correct value
- Add returnFirstHit snippet
- Break comma separated lists into rows in form emails
- Fix submission of \'other\' values in all forms
- Look for menu title first when adding multi-step form headings
- Fix sort order of field data in multi-step form emails
- Fix reapplying checkbox values and \'other\' fields in multi-step forms
- Add row templates for autogenerated form fields based on input options
- Fix faulty multi-step placeholder in form CB
- Add rawAlias placeholder chunk
- Load custom form assets through fbLoadAssets (if present)

## Romanesco Patterns 0.16.2
Released on April 20, 2020

New features:
- Add elements for displaying FAQs with structured markup

Fixes and improvements:
- Add option to embed Youtube video directly
- Add option to manually correct aspect ratio of Youtube embed
- Ensure highest resolution thumbnail is fetched for Youtube embed placeholder
- Switch to JSON-LD for structured breadcrumbs data
- Improve structured data JSON-LD snippet in head
- Reorganize data elements folder structure
- Use uniform placeholders in Accordions, Cards and Tabs
- Add heading level to accordions
- Don\'t let ToC menu include headings outside of content area

## Romanesco Patterns 0.16.1
Released on April 14, 2020

Fixes and improvements:
- Inherit comment toggle and article author TV values
- Prevent background from appearing if responsive crop is not defined
- Improve layout of publication templates
- Add button templates for creating neighbor menu
- Add class to content headers without class name
- Conditionally load assets for registration forms
- Remove form class from search field
- Implement multi-page form functionality into FormBlocks
- Add options to adjust type, size and alignment of form buttons
- Fix finding value in multidimensional array with jsonGetValue
- Add first and last placeholders to splitString snippet
- Add class to video embed, to initialize them separately from other embeds

## Romanesco Patterns 0.16.0
Released on March 30, 2020

New features:
- Add ability to create multi-page forms (manually)
- Add social connect button for WhatsApp
- Add social share button for sharing URLs via email
- Add steps navigation to show the completion status of an activity
- Add TV input option for selecting a country (or countries)

Fixes and improvements:
- Load CSS/JS assets for modal, step and form components only if used on page
- Add ability to identify the last placeholder of splitString output
- Add TV to control save form option per form
- Remove Google+ elements
- Make sure spam submissions will also fail on 2nd attempt in forms
- Switch to fbFormReport for generating email messages
- Grab required form fields directly from CB properties array for validation
- Add field template for input options to form dropdowns and options
- Add multiple select option to form dropdowns
- Add option to center align buttons individually
- Call setUserPlaceholders cached in article overviews
- Improve layout and visibility of sharing widget in articleTraditional sidebar
- Make header backgrounds context sensitive in generated CSS
- Regenerate static CSS when changing a header background
- Fix timeline in project hub by referencing the correct classname

## Romanesco Patterns 0.15.3
Released on March 10, 2020

Fixes and improvements:
- Allow using a Global Background image without defining any crops
- Set higher event priority for generateStaticCSS plugin
- Prevent fatal error in jsonGetObject when JSON input is not present or invalid

## Romanesco Patterns 0.15.2
Released on March 3, 2020

Fixes and improvements:
- Add keyboard control to slider
- Switch to Swiper in Presentation template
- Use medium class instead of empty value for field sizes
- Don\'t initialize slider if there aren\'t enough slides
- Fix calculation of max thumb height in lazy load placeholders
- Fix lazy loading of images in slider
- Add system default setting for CB layout backgrounds
- Add non-white class to body if custom background is set

## Romanesco Patterns 0.15.1
Released on January 29, 2020

Fixes and improvements:
- Improve styling of off-canvas mobile menu
- Replace Slick slider with Swiper
- Move Overview pagination wrapper to chunk tpl

## Romanesco Patterns 0.15.0
Released on January 14, 2020

New features:
- Add layout for creating sliders with content elements
- Add template for creating presentations
- Add pagination with AJAX support
- Add lazy loading to Image CB and image overviews

Fixes and improvements:
- Rename slider classes to avoid collisions with new FUI slider module
- Convert new lines to line breaks in Quotes
- Add suffix with version number to main CSS and JS assets
- Optimize caching of chunks in Overview templates
- Generate responsive content images with srcset and sizes
- Add round and removeDuplicateLines snippets
- Use alias to specify ID in form template
- Use system setting to specify title format in head
- Manage background availability inside selectors
- Generate static CSS file with Global Backgrounds (per context if needed)
- Reference Global Backgrounds by template ID when loading custom CSS
- Add system settings for Mapbox username and style_id

## Romanesco Patterns 0.14.7
Released on December 17, 2019

New features:
- Add Date and Date Range fields to FormBlocks

Fixes and improvements:
- Fix special characters breaking FB option labels
- Optimize FormBlocks validation processing
- Improve inheritance of FormBlocks label position settings
- Load home breadcrumb with tpl chunk
- Fix structured data errors in breadcrumbs
- Fix illegal regex sequences

## Romanesco Patterns 0.14.6
Released on November 19, 2019

New features:
- Add jsonGetObject snippet for templating JSON output with chunks
- Add ability to center content when stacked on mobile or tablet
- Add circular button option
- Add circular and bordered image options

Fixes and improvements:
- Refactor Global Backgrounds component
- Add ability to search for multiple instances of key in jsonGetValue
- Fix fallback icon in avatar when an article has no author
- Fix memory exhausted issues when rebuilding content with ContentBlocks
- Fix visibility toggles in front-end pattern library
- Limit reverse column order setting to mobile only
- Rename InjectInvertedClasses plugin to ManipulateDOM
- Rename MarkdownMimeType plugin to ProcessMarkdown
- Remove rows from grids that have a reversed column order on mobile
- Remove .md extension from Markdown links and turn them into button if desired
- Add language class to Markdown code blocks that do not specify a language
- Turn Markdown tables into Semantic UI tables

## Romanesco Patterns 0.14.5
Released on October 12, 2019

Hotfix: forward missing prefix to setBoxTypeTheme snippet

## Romanesco Patterns 0.14.4
Released on October 10, 2019

New features:
- Integrate visual regression tests (with BackstopJS)
- Add snippet for creating static HTML file of resource
- Add responsive options to main layouts and overviews

Fixes and improvements:
- Fix incorrect syntax in Google webfont requests
- Define exact aspect ratio for Overview images
- Add inverted class to logo in vertical menu
- Fix image URLs and display size in Markdown output
- Mute rogue path output in manager for Redactor too
- Remove http:// in Youtube embed placeholder URL
- Update resourceTVInputOptions to respect possible context settings
- Fix broken avatar image in compact article overviews
- Fix incorrect path in CSS to global backgrounds SVG
- Correctly retrieve (possible) context setting for FormBlocks container ID
- Correctly retrieve (possible) context setting for CB and TV options
- Load full off-canvas navigation if main menu is not a dropdown menu

## Romanesco Patterns 0.14.3
Released on July 16, 2019

New features:
- Allow credits to be added to an image or icon
- Add Free variant to Overview images (no fixed aspect ratio)
- Add Commento as commenting option

Fixes and improvements:
- Isolate content images and increase the distance from element below
- Show top level parent in vertical sub navigation
- Add alignment option to all Overview CBs
- Add text_size, show_subtitle and show_rating options to Testimonial overviews
- Make overviewRowImageBasic template more basic
- Improve sorting in Overviews (reverse sort direction, alphabetic sort order)
- Add basic icon chunk
- Add tertiary button style (Fomantic UI feature)
- Add option to place button on new line
- Fix issue with rogue 0 output from getImageDimensions breaking SUI build
- Fix quirk where TVs couldn\'t be rendered in layouts anymore
- Prevent leaking of data from srcset placeholder in overview images
- Allow theme additions to global backgrounds
- Return after a setBoxType override was found
- Lower minimum width for all image TVs
- Apply img_quality configuration setting to all images
- Only load certain assets (CSS/JS) when they are needed
- Small caching optimizations in Overview templates
- Rename and refactor Knowledge Base into Notes
- Tickets integration is now deprecated


## Romanesco Patterns 0.14.2
Released on April 15, 2019

Fixes and improvements:
- Prevent MIGXdb fields with default value of NULL from being set to 0
- Allow otherwise duplicate TV category names to be prefixed with _ in projects
- Add option to embed Google Analytics with gtag.js
- Add option to embed Matomo Analytics
- Fix not being able to set image type in Publication and Portfolio overviews
- Fix binary download types (such as PDFs) not having content
- Fix Global Backgrounds TV not loading its MIGX config from file
- Use nvm-exec to run Gulp from PHP (prevents gulp not found errors)
- Add fullname parameter to Registration template
- Point to correct math validator in Registration template
- Add empty error message div to forms (for SUI front-end validation)
- Allow recipient email TV to be empty in forms (i.e. when using a custom hook)
- Fix inheritance of form label layout settings
- Add label to honeypot fields
- Only load Youtube videos after play button is clicked


## Romanesco Patterns 0.14.1
Released on February 10, 2019

New features:
- Add TV input option for selecting Fibonacci numbers
- Add math question anti-spam option to forms
- Load Semantic UI styles inside CB preview containers

Fixes and improvements:
- Rearrange snippet folders and import a few new ones from projects
- Fix Overview headings displayed as regular links being too large
- Fix Registration template not validating password correctly
- Exclude resources with unchecked "Use alias in URI" from breadcrumbs
- Make icons work inside CB chunk previews
- Make check for detecting SeoTab plugin watertight


## Romanesco Patterns 0.14.0
Released on January 18, 2019

New features:
- Add main navigation with dropdown submenus
- Add template with Table of Contents menu (instead of submenu)
- Add template for Downloads
- Add Kanban layout for Content Purpose elements

Fixes and improvements:
- Update status grid to incorporate new / altered TV values
- Add optional anti-spam hook to forms
- Add option to select background for rich text segments too


## Romanesco Patterns 0.13.0
Released on November 15, 2018

New features:
- Add content purpose TVs
- Add TVs for external links, file attachments and related content
- Add ability to create input options
- Add ability to create crosslinks between resources
- Add re-purpose component, for creating content "flows" inside a central topic
- Add after save hooks for MIGXdb configs
- Add JSON import for input options

Fixes and improvements:
- Add chunk for dynamically generating TV input options from database rows
- Load project timeline through Backyard package and store data in db
- Rearrange TV categories and add rank
- Replace Grunt task for generating GPM config with PHP script
- Make tvToJSON output suitable for use in GPM configs
- Disable CSS background images for Tiled overviews
- Fix sidebar not showing on largest screen on Team and Client pages
- Fix link in Instagram social button


## Romanesco Patterns 0.12.3
Released on October 4, 2018

New features:
- Add OpenGraph metadata to head
- Add snippet for clipping characters from start or end of string
- Add plugin for injecting inverted classes into content (requires HtmlPageDom)
- Add options for controlling footer and bottom CTA content

Fixes and improvements:
- Include homepage in basic template list, so they also have Overview TVs
- Fix author image in compact article overview template
- Disable Disqus comment count in overviews (was acting buggy)
- Prevent decimals in calculated image dimensions from breaking variables file
- Allow overrides for head and footer chunks in all templates
- Fix issues when using multiple file upload fields in form
- Sort available forms by menuindex in Forms CB


## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)


## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- Add CB field for displaying map with marker
- Add snippets for creating repeating input fields to FormBlocks

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- Add ability to use alternate option value in form HTML
- Add ability to choose help text position in form (above or below input)
- Add ability to force fieldset to always display as segment in forms
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- Add multiple file upload field to FormBlocks

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- Add ability to set dynamic redirect ID in form
- Add row template for auto-generated select options to FormBlocks
- Combine Select Dropdown and Select Options form fields
- Fix Other and Collapsible fields in forms
- Use fieldset / legend markup again in form HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TVs to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BC]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '09a1b8a37af479a6cad3e1265e392af2',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/f5ace68c770890714fb76e52909ac463.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bbb0dde40b84b982b771a0766476c9a',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/b42dc9ecbbf2b9778526a77a8428bda6.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4903c93921760fc833de848ea9c2a580',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/e610418b600c4387cb457779e9d889bf.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1bac7f72b3e3c46f0a4d3eca4801bdc',
      'native_key' => 'romanesco.manager_feedback',
      'filename' => 'modSystemSetting/5ce862b5d3737d6a05f3dd2a4b309dab.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f23c9d729f92c6d510be3fea255ae8b6',
      'native_key' => 'romanesco.ybug_project_id',
      'filename' => 'modSystemSetting/c92f5e2077150b9869d5c244b2c1f941.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7539c7db88bdefbb14893a5fb4d23176',
      'native_key' => 'romanesco.title_format',
      'filename' => 'modSystemSetting/c950aecff98788edd8648538496c8650.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '438af00d960deab06ef3e6a6c323f467',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/6fac0e03a6216abb222879d9e91060ee.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb39f4f42d922f167b89d443656571ef',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/37e7a17f649ff52a50dbd10c93d12201.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbe1bc8a4c9fcbcf2d313b54d5cb767a',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/7bc91d7f3df2b8f48fbb880cd4a510a0.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbc5118c470f31cf88c694e78897fa72',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/9bfd89bb614f1e4c4fd2460700cf3236.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34634454cca746766a8ba9a2a3e32a02',
      'native_key' => 'romanesco.env_path',
      'filename' => 'modSystemSetting/076bacf1a4aa5cac802cd88a2f56c719.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1af64b918d2b45d4774a2355c8cdc9e',
      'native_key' => 'romanesco.htpasswd_user',
      'filename' => 'modSystemSetting/014388eeab6fbabd3b1c76fcc4ad40ce.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20483c659a49ed9720fbd666ff2efcda',
      'native_key' => 'romanesco.htpasswd_pass',
      'filename' => 'modSystemSetting/3a495a8a6d4ed5b82bfb22c1d0741f24.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5429357a33dd1f178b7e77be403819b7',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/088f870ea029765ce9f2c32c1c21a22b.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06d35f58b7a08180f262288b24e1101b',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/59b6382facfca50071170008bf4eabf5.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79f20dc0ac350f8ee5bcd8af0f2136c5',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/dcc1a7fe23712471955d487854e4fb4f.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1590690199c8a45f95bfb8e5a723ffbf',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/2eab08e897fd2628c73a461892f4e2eb.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec84db19aecb4db93804c302e4ab8945',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/2dadaea28f9c98ee125f921f231d1e9d.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0a23a8e6d9dc80b40455e9a52a44d23',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/9f8117b37696c3001ab07f9b1f9d0f2e.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1c7806ce4ac3e49da39da7c2f5f0db9',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/e8bafd1c613434068863f88d33308339.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '820734dc1ad79e5d1bbdf46b16baf4bb',
      'native_key' => 'romanesco.mapbox_username',
      'filename' => 'modSystemSetting/2d112436611fc027e12d38a0120973bf.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14d7a785e7f209d5e420f76488609dad',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/d95a8c89544203213dd6072866dca1bd.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7168ad709ae3d777d72aed76aa83cb8e',
      'native_key' => 'romanesco.mapbox_style_id',
      'filename' => 'modSystemSetting/19054a3b18511d9ec0aa3408653a13e7.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '350f50733b84d288127e07ed446bdd7e',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/ae1c891da2169963b27baf3df18e9ecf.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89d61a8ee2b312f12986df42753c2ad2',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/dfac49facbbc69d3d62c620df7f4e746.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2325310cd34df764b1ec5c2a441c6603',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/e636ecf30cdd7291105c51702c75f309.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c08ce26213316a6d83e6d5f155f76458',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/2fad9e1050112c1a04edcea5045dab70.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b7a2bf116e1e0db32521437a4878513',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/db226d4f2c74fd8b6d772ec73110851e.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a6edd46d0ca1621b21e8a9e6c2efbe6',
      'native_key' => 'romanesco.img_breakpoints',
      'filename' => 'modSystemSetting/b1636a4b2c506daa2ecd725a442e8c77.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c0690efc03bba5ab9b1f5015e81615b',
      'native_key' => 'romanesco.img_quality',
      'filename' => 'modSystemSetting/5d1072f0a83e508f7e65424b60b19eec.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e6526b027ee8e5883a24b673f72d020',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/992cfade60ab6eabc9e84f18e5064bdc.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeef80208930b77ca42443f794d0934b',
      'native_key' => 'romanesco.semantic_css_path',
      'filename' => 'modSystemSetting/d1a13c893fd4546f694b740738feb1d7.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9040eee9bde1d453877ed5549d457dee',
      'native_key' => 'romanesco.semantic_js_path',
      'filename' => 'modSystemSetting/b9deb41cb3a29246b310b11cfdc6d213.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a826092804a17e912ddfcaaa65640860',
      'native_key' => 'romanesco.semantic_font_path',
      'filename' => 'modSystemSetting/341bbb368fd59ab99d1501b238d055e8.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5560f635da1c2c5d5d8b550dc45336eb',
      'native_key' => 'romanesco.semantic_vendor_path',
      'filename' => 'modSystemSetting/d16ba2ecc0320c56a693253696e22d40.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f383e5621fcd8549f2b8d4dd87886e',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/57f3f672e04597811fa7b1e57d11439b.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '767f398b3ca3253c75e168f6b2f56dc9',
      'native_key' => 'romanesco.favicon_path',
      'filename' => 'modSystemSetting/bd5024ee80914ac568acd205952766b4.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1ba4d9439099b2f0af0e82e95e390eb',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/5c39a2d404cfa65713bbe60a48a196bc.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9b870064883729dcfab227cce73c892',
      'native_key' => 'romanesco.assets_version_css',
      'filename' => 'modSystemSetting/2a7a875230100e34cd05606e1b1f0847.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcbfed3a414355b6b04a0a0f9c0af832',
      'native_key' => 'romanesco.assets_version_js',
      'filename' => 'modSystemSetting/7f86bcd801348eb7201645a87f56ce3b.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '894fe88a29de11d82f438cc6c1f9e506',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/50a963c096a82b39ae48f5f20c0ede5b.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7186e56c2dd6f9cd874e8f98a8f35f74',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/98ac0dfe7fffd42719b249fb8e85b13b.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d0aeddf3f85d627fd31a94aa6f9f539',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/8fc00c69e5b512818fc1b5a09c1757f6.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89b495bfe38b46642410ce349353352c',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/22b4dd0436326b8769cbf6643bb1d36d.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228ce6f7eef0a3b1724e3bf6aec6d97e',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/166bdd323472b3683113318dff6cf9a7.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f6ee009b60c91db5fae057add5dfee9',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/0b7456012e31be758cb0390bb6f670d3.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea2af0756c789d578c4c662edd088019',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/c392be2881b6439c4c1f12a932943010.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d37698b2411048c196bb0656312bd59',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/74408a2364c8404f3d2df7028196b0d5.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c9e495936561b0b4cbc675f3f73f379',
      'native_key' => 'romanesco.cb_field_faq_id',
      'filename' => 'modSystemSetting/fdf698e89d8d3257054df35f5b8141df.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eac1bb19adc0f2b1b73896f37c52152',
      'native_key' => 'romanesco.cb_hide_settings',
      'filename' => 'modSystemSetting/a1a0b1666f0566dd44bdab565ba9f077.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16848301be5131f14ee5e77e42ad3568',
      'native_key' => 'romanesco.cb_hide_fields',
      'filename' => 'modSystemSetting/13b4d9e85a2f97c28c39cac04d2427e5.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb714ac24196892d727fba6b40339717',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/d28421a7f7e51c45b5f3e601360e33f1.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a0bbf832d8cb3c8c338b156f3379416',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/ef5766614010403492c8c58b49ac9de1.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c517904abf95c6ec832914e83dd4f71',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/51bbd07ae2e126d8b1c10fd1986ca775.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f344e5c145b1b101b997641021eb3ee',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/a3515f6b22e47409f4abfca8470a08da.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0df66d4b0675a286e94a2b3dcbac60d0',
      'native_key' => 'formblocks.honeypot_field',
      'filename' => 'modSystemSetting/38d1c253a97249ee6a7fc706f8706c83.vehicle',
      'namespace' => 'romanesco',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0afc69f49209ca196b0848697765068',
      'native_key' => 'formblocks.antispam_hooks',
      'filename' => 'modSystemSetting/b9c5c677ac5200312c01d38209d09fd2.vehicle',
      'namespace' => 'romanesco',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8f70abd58c4882c5e32909f706a5bbe',
      'native_key' => 'formblocks.frontend_validation',
      'filename' => 'modSystemSetting/8aa76e1443d45c4d8f8e4e7cfcb3193d.vehicle',
      'namespace' => 'romanesco',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ef3bd433f4ab523c1a76fecd53245e0',
      'native_key' => 'formblocks.ajax_mode',
      'filename' => 'modSystemSetting/79af9d8f115889a7867ae108e4b41528.vehicle',
      'namespace' => 'romanesco',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2186d32441a5cfc447ffd5c4047dc7b9',
      'native_key' => 'formblocks.formsource',
      'filename' => 'modSystemSetting/d599f60114decdb1808730809c976494.vehicle',
      'namespace' => 'romanesco',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9e88ab0d59ca78435a5f9a273c38368',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/d0a6c5d4fe31bbf726a195bff2398c3a.vehicle',
      'namespace' => 'romanesco',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '498a5e187ef71e9cb8d03d9dcc74b46b',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/a0d9762a7d6c19cf64bc27e95ecb7b8a.vehicle',
      'namespace' => 'romanesco',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e50c8a36888480893115598c945fe1bb',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/c5f68a21510412d67d19c3f7283f61aa.vehicle',
      'namespace' => 'romanesco',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffbabb87d958db1500c57e3093312236',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/e36977cbb46744887caac2c289316914.vehicle',
      'namespace' => 'romanesco',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52dc82f4704ee794fa279b61ff1b7dc6',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/aceecacd75e1bc14caa43400a652ce06.vehicle',
      'namespace' => 'romanesco',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fd9f98b8b3842b20d18cda08eaed5c7',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/85d9ce5fb35e2bb10cb165373ad9bc37.vehicle',
      'namespace' => 'romanesco',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b97506029ef1cf6179c71c810494ad94',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/242c8957343665f84b0f62ba6338664f.vehicle',
      'namespace' => 'romanesco',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a63d20233cafb61e4ff1828c7c992c',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/dae16ed93e796742c2dbc8241a30ae2a.vehicle',
      'namespace' => 'romanesco',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8330fe55012448b46ffc0ccefd61343',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/587be416cc1c7ce3eed59b12540e1f95.vehicle',
      'namespace' => 'romanesco',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51124a90e13bf270acca126b5b45d1fd',
      'native_key' => 'formblocks.cb_input_date_id',
      'filename' => 'modSystemSetting/203412d3d79b3ff9145037b05c7757f6.vehicle',
      'namespace' => 'romanesco',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c536ecf08fec51d92d060ba0e333a402',
      'native_key' => 'formblocks.cb_input_date_range_id',
      'filename' => 'modSystemSetting/a9247e6472c9e28d3dd1555bb5c9a555.vehicle',
      'namespace' => 'romanesco',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0ffbc7ad3692c92218a1982fadafbd9',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/c384c4a695d8514a6e587d77ba49ea6e.vehicle',
      'namespace' => 'romanesco',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d6c26d21cf7ffa7e1a52f08787eea4',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/9948a4ca26bcb2bcc107f2217578f3d9.vehicle',
      'namespace' => 'romanesco',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e32b3194e3fd9348113d1da9f0face0',
      'native_key' => 'formblocks.cb_nested_fieldset_id',
      'filename' => 'modSystemSetting/596c73f5e90640743bbf5b81a0c49087.vehicle',
      'namespace' => 'romanesco',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '026154a7f13dc8c166e36fea8763712c',
      'native_key' => NULL,
      'filename' => 'modCategory/2852ffb06c9f448a7692defba459b705.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);