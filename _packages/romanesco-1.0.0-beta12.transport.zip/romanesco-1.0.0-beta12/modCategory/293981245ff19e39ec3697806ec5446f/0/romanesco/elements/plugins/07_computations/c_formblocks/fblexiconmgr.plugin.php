<?php
/**
 * fbLexiconManager
 *
 * Load FormBlocks lexicon in MODX manager.
 *
 * @var modX $modx
 * @package romanesco
 */

$modx->controller->addLexiconTopic('romanescobackyard:formblocks');