<?php
$assetsPath = 'assets/components/patternlab/';

// Load JS in footer
$modx->regClientScript($assetsPath.'js/formblocks.js');

return '';