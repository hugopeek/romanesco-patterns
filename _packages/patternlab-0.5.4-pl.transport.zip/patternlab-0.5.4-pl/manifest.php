<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f68529d4120ea78510ebfce026299d97',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/688c80782a6bcf53455a58a030f54691.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afcd52db927774014d0ded558b626ef2',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/67325573555e0940695f43e3fa19dc22.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b3d12761b7e9eeee19c662475faa93',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/b65adfa3c9d9561e0e92c35739240650.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249bad60456234a2f0c52126669ac714',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/74ac4afdda437136ca29347a9a540c40.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b81ce8fb6c51f5dcb75cf77ac002b23',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/cbad2771a019fb2a1a523f295ddfd936.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83ef208c8c63b784ccdf3e23c29b18a7',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/3bb1d644a9dccde2cc2d2e9df48c0e13.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eebadbf821c790195c942f28ae98ba9d',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/5085139fc772e8f9786f848eb566967e.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aed0493c45de6da47283bd2ed138f47',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/c6d72b2b37daedd4480967544c2b5ab7.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f182f2c51f38d670ec156ebfca469db',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/6b62681cce8217bdc152fb3619e74928.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96000795668ed713279114a41a28f73d',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/63cf6f1acfd5cc98c5eff17733777d02.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dcdf61faea4bd36867476b712c02f8f',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/0636889ff9259f82cd12aa61fd2f359d.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd83b063aa4d7d13c016f618d87f3542',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/1ad721f9fcfb2c8de51b0bbee5f3e183.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3e293872d4481e8e6051ef412ef9e65',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/5e9c939913e5e1d5bde0ed68659ba95d.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee56571c11d50090473bc4efb4752ba0',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/ef5d44a4dd0961eaa73e468df2d1e361.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a55272f155fa92f0d98be7ec95f1ea',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/13be72cc1294843144b83a88ac3af275.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0d14cb032d9cf8ac29dac4caf6ac179',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/a5efe3a2bbb5dd63b62d3b6eddb976b5.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7ea52136ae03fbca73bedf836977bef',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/0eab73c930dbc41566f39f09f882755f.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0381d3c222d76cc5249a8ed1ee88fd',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/b82b3ca0dc3dbe35047bff3b9eadf8dc.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1ac875b0dc07cd00f0a0058b73c8b3',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/46603f2a95e421b8d4b8d7a8f2706c92.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9822273ab459a692b9ed63fff6e130b7',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/524b2b4ed5d59497484aa03c643ceae5.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd88518a6f3d2bd21e5b3f9575fe284cd',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/a9467381bb430bc16987683ab778a250.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19352509ffe449398272eefacb48d9f2',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/13b067ef8b8a10f7a09570acfebebad8.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2f2168e6c3b1c0495fb08e02549fb75d',
      'native_key' => NULL,
      'filename' => 'modCategory/0512b651465a6df7da2333f999df05cf.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);