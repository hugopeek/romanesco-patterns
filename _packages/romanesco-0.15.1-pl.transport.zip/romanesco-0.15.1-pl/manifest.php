<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bef3220a196c24aab9197fc085c04808',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/90539379c8c3e1e7ce1c3de49c00e365.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9af1f5d3ba3e5ad74d1a77916072fd49',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/15ad41e8bb32e1f99d9e34ffe51ba513.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b3251c5043a083a90f3f84bb9218da9',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/9bbede280236aa024a1663f26339fe5a.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '657ba98687af044c3c82ddec2567b4ae',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/201fd35e7ff429ebc67ae16f86bd38b7.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b723e3fa80fa3b9415bb5e4b7d2abda',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/f3e87e6c0498c42d3d80d7ba5bfbd176.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05a7cfc42e73bfeffd89445a5b4c7fbd',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/2ec1a9e568ebf7224c183f7f507349c9.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0b0142fbcf0a947829c7c6683fef68',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/6733e2d5037d6ab67c4061e1a5b9bacf.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7998f02366a2f5325e88020306a8845',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/c718cd51ec15a5bf59940975ada5a7b0.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd91c4a7a6da2114c504756a5e998140d',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/83d61000d61b19474a3b5439dac64d53.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d9a6abb0f3e44cb5ff1a2403aa37aed',
      'native_key' => 'romanesco.title_format',
      'filename' => 'modSystemSetting/f7280df5f65c6edcad2403250bbf63b2.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65bf2c1e5132bf34e980448a2787598b',
      'native_key' => 'romanesco.custom_css_per_context',
      'filename' => 'modSystemSetting/5b2451bb297f3c53035e5354bfb7849a.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bcda8cbab1cfab63affcbdc40af4961',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/beba57cef4984e8e9283d9a376d7d80d.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b9ea49dfe5212497234db382956c52b',
      'native_key' => 'romanesco.disqus_div_id',
      'filename' => 'modSystemSetting/d8e41195cac16a3103180059c1d401bc.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd21f41d1d94cd1697c72b65b2ad23a86',
      'native_key' => 'romanesco.commento_div_id',
      'filename' => 'modSystemSetting/fe283cc0cf0e1b2bc7d7d2f0ca2625d0.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70204f70fe1c4f5572ebefd0a7e2fd0c',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/5cb885b42d0e6c11c87e103241f9512a.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7577d8de2a92abbe142b553a011910c',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/a94a7dee5a1da25b5ef405985c550180.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e1b7afa8f026415db3f1f9082cf05e6',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/1433931facae42834c1f608c5a32d4e1.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d77303d15072e923f873785157995be',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/6e49bac0669bde2d4ecde8ea100e3b7a.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd0a7c0c52a8dfb1635b3cde90dc00c5',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/6a1f908ed06d4288042929eccd76082d.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faa69b75744c871cb9d02a053a5ce293',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/ef1da20d9bb31c4eb9507eb529d74b82.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd97c188c1955a2f07b1090e143fda20',
      'native_key' => 'romanesco.backstop_reference_url',
      'filename' => 'modSystemSetting/4ba6365acfd30fa7f6c22ef6bf49b5fd.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0989b5fec0cd8719a77718c6da19f508',
      'native_key' => 'romanesco.mapbox_username',
      'filename' => 'modSystemSetting/62679be85e873fe0003083374d218489.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7483633d1ab7079cda4fe3f1c5af756',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/21635855e98be53dcb95c3bb568708f4.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b45f1c030a7e5f85c23cb15c098e5aa6',
      'native_key' => 'romanesco.mapbox_style_id',
      'filename' => 'modSystemSetting/b734c3daa75d31dc384ee79ef56a49f8.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c35ff064de5caf6fe15a9cd1ef1178d0',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/9bc57060411e5ab2b0fe966d6a7d0393.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1b340f64f3672006c124b7f3397fc30',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/b2cde8177cdfaa11ab94884b27a5008b.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd44904758db10abe4c3a7b7858e0db28',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/0d184208ff3b91258f33b04a06867492.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cc97693453305cc2c9a071d7883c8db',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/b434636de2e1b49f9f83f731c58f4208.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4f12217a3cdf6568b5e6504b212bcd9',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/5574adc26f6ea7a7d277938ef31527ad.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f84a0355e115a35a1b23b7701a40f867',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/888628c07562f2007189b7db2e74f333.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85454b758b640a8697b54be021010114',
      'native_key' => 'romanesco.assets_version_css',
      'filename' => 'modSystemSetting/ccc1d3f88a9250fee1c6aca6fe2b0114.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '900aca494ba96d5d312a671d3db67782',
      'native_key' => 'romanesco.assets_version_js',
      'filename' => 'modSystemSetting/5aa15ec44f38eb29aee0f5575be67638.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86876abc32636546d378a44dd7f10f1a',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/b98b1f3d06d92131fc0eb0f66702d3cf.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46a0660a42d5c44bc71765ab783a5d93',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/37d9436443d2e41faa3cd9af78b293d1.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b93753821abad6cd32aeb17a526475c',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/12c36b097146b07db37c9a643bd65eb7.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ab6b60c9d3b8459c7320c350d3ee583',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/0d7b3d5519f581b86a17d86098a55262.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5652476f06f3ef125e5d520f3e41df5',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/2d7a57e2e9e1d66060ed2d761f1a393c.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23b645fb1d6ca61d66043d65dfdb06f2',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/d05db7cd93c7820fa23731ec217b40c5.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c467e7789b34d28cfaa7794b13ce58f4',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/8bd4d828287b572494da230aa9c8725f.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24223f6c349134cc5a22ec93ef7dc1c1',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/f1eb100fc7b725cc12bae35287c00625.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '845a72e0e36f0cf8069782eb338dceec',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/0b9954a7db493905620dc6574715ccfd.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4340c4483e0cea12348c2758e826567',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/a6877ef81b6a47357621516382673abf.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0807af37982c0ac0f9151cd72eddb660',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/938ce36c4b90e8f29a5b0156c19c6c97.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67ae33fe2e8f528decd1ba1f148d1b5b',
      'native_key' => 'romanesco.cb_field_map_id',
      'filename' => 'modSystemSetting/3ed598e9da6551255f05040b2ab5f223.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c9ca3d2b1a05f81ae4aeb75b7b3f6a5',
      'native_key' => 'romanesco.cb_field_background_id',
      'filename' => 'modSystemSetting/00fb024b7efe88ee7953577db63af339.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c423d62c3ecda5ac33971138856b05ec',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/d60120f11068497daaa153af3846683f.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c6e64624f57a6164f8f4fcbad7c61e0',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/3d0cc5a133dbcdc9c899d940d3450aa5.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d913c2fd2864a44e717f351559c24ac',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/97d2ee08031a0cbe07a66ba71f7d43a0.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c47713c05bfe93e7dc3c4f91c2175b87',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/6fb48221676e98693bb89669c0196857.vehicle',
      'namespace' => 'romanesco',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffbfb1288500db5398f3cdf21ced3716',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/9ae742529499f112f4ed922fb85931b3.vehicle',
      'namespace' => 'romanesco',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40a1c0851a2cf46831506b1f8f4a1180',
      'native_key' => 'formblocks.activation_resource_id',
      'filename' => 'modSystemSetting/c2013810a019949e221046bec7b86c2c.vehicle',
      'namespace' => 'romanesco',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25349355085ab6b250c1c1a60e215328',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/93e884b6c81083a653d1bb3c069b09f2.vehicle',
      'namespace' => 'romanesco',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd97cdc5ea1be765f6a1cd78da73ac4c9',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/a120a8292af527c78ac05aff5d50e13c.vehicle',
      'namespace' => 'romanesco',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f33e15c8979002d3a4fa8df7b0de39d',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/92c70e3f605d1c244df32a569d4eba30.vehicle',
      'namespace' => 'romanesco',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dda34a181bf403d890de1e6292e15161',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/a49cf86c95ee80c126ee218a7d3b55fe.vehicle',
      'namespace' => 'romanesco',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '390c73c36ccb01440bc209ce0fdb4d66',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/0da752c224c8afd3fe865efdf091b32c.vehicle',
      'namespace' => 'romanesco',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31ae1d499a26fd4d7e7b66101e4e0fd6',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/403d6807c4bec56572144306afab5fdc.vehicle',
      'namespace' => 'romanesco',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0d2f460e5907638db9f55014ae8f615',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/bf5fced6695e7730097f1f35cf7b386e.vehicle',
      'namespace' => 'romanesco',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39087d463c9c2d41a6c14b2c0eee4e5a',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/1c2648bb4f45ae83608b23e3a4a75889.vehicle',
      'namespace' => 'romanesco',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdd4b8a196a99e3daa64c2af318ec980',
      'native_key' => 'formblocks.cb_input_date_id',
      'filename' => 'modSystemSetting/c455a5e9f359d133faf9de3db2b75cab.vehicle',
      'namespace' => 'romanesco',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4ac4dd59b864a01f60b3b8f6eb8fd22',
      'native_key' => 'formblocks.cb_input_date_range_id',
      'filename' => 'modSystemSetting/ea3a643e1e29086eb5093323f85035f2.vehicle',
      'namespace' => 'romanesco',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1080883d2b272651bd7d3bd41289577',
      'native_key' => 'formblocks.cb_math_question_id',
      'filename' => 'modSystemSetting/742524b0e720f33455aa414b49d4ae53.vehicle',
      'namespace' => 'romanesco',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e48ec5ec6e93f9449fcc012856e574fa',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/e54b53da8d020c04bcc1be8410915982.vehicle',
      'namespace' => 'romanesco',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2124afbf7a0ab3a80cfb5570b3ce0881',
      'native_key' => NULL,
      'filename' => 'modCategory/50d5ee0181577f6cc8773b21553728eb.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);