<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2ecf053b2921284158b6fb5375c327e3',
      'native_key' => 'patternlab',
      'filename' => 'modNamespace/bd059a7014819a5aed0984f91007b64a.vehicle',
      'namespace' => 'patternlab',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf72d72cce0d7bf3c2cf6bce0e1fc43',
      'native_key' => 'patternlab.semantic_dist_path',
      'filename' => 'modSystemSetting/90b89ff869f15fb5e5961b467a494c59.vehicle',
      'namespace' => 'patternlab',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b2daa807c9ef28db2aecf73e3693326',
      'native_key' => 'patternlab.custom_css_path',
      'filename' => 'modSystemSetting/613db59a758d104f2afd34ec6b7bd36d.vehicle',
      'namespace' => 'patternlab',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6f150ee1cc48fc5733ec52653b18e4f',
      'native_key' => 'patternlab.custom_js_path',
      'filename' => 'modSystemSetting/9f903b5a21d2cd87126d2c465f4f1a79.vehicle',
      'namespace' => 'patternlab',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ce05cd6200bb1625d03edb9965c3877',
      'native_key' => 'patternlab.dev_mode',
      'filename' => 'modSystemSetting/b67d00f054eaf57e53c9711c6906c945.vehicle',
      'namespace' => 'patternlab',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c2e67bc5f9edc601b1a7a304f49b6ef',
      'native_key' => 'patternlab.user_team_id',
      'filename' => 'modSystemSetting/fbf80619a5e5ef4d2764dbd22644db8c.vehicle',
      'namespace' => 'patternlab',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbdd5f45b4741dbb18977f3654cc3185',
      'native_key' => 'patternlab.blog_container_id',
      'filename' => 'modSystemSetting/60593ed06fdf7b07702db9813731466d.vehicle',
      'namespace' => 'patternlab',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ad29dbe288dac4b6d2b2f7edc86d07a',
      'native_key' => 'patternlab.cta_container_id',
      'filename' => 'modSystemSetting/74e8201ee6ef31c8286cdd66f062a1a2.vehicle',
      'namespace' => 'patternlab',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '920d895872a27ad3a87e6339ec41f6ef',
      'native_key' => 'patternlab.fb_container_id',
      'filename' => 'modSystemSetting/dfde8f8c20c9c558c0e9e4497858bb8b.vehicle',
      'namespace' => 'patternlab',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '585a4d4a8ea77cb90cfac5df517e5482',
      'native_key' => 'patternlab.fb_save_form',
      'filename' => 'modSystemSetting/9bd71a52663c1cd377f5e842022b1330.vehicle',
      'namespace' => 'patternlab',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2eabd1cc8c4d160013aae5e50beb7db',
      'native_key' => 'patternlab.fb_input_textfield_id',
      'filename' => 'modSystemSetting/83a6214ce9067aefc233715b12a3f705.vehicle',
      'namespace' => 'patternlab',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ceb1ace0248c9917d67331495fb4e77',
      'native_key' => 'patternlab.fb_input_textarea_id',
      'filename' => 'modSystemSetting/d9995e05cb61c79e25eb9c653f050496.vehicle',
      'namespace' => 'patternlab',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22015b4065e86169cfc8f1c406719ba5',
      'native_key' => 'patternlab.fb_input_email_id',
      'filename' => 'modSystemSetting/dd0a385356250d7030cc999d2a6f9cb7.vehicle',
      'namespace' => 'patternlab',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb62210b30eca93402f727b5ba8b0f6e',
      'native_key' => 'patternlab.fb_select_option_id',
      'filename' => 'modSystemSetting/91cc76193c7e96ad3f15dafeddf137ca.vehicle',
      'namespace' => 'patternlab',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0ebd10c5551348ed5bbfd0678685c46',
      'native_key' => 'patternlab.fb_select_option_collapse_id',
      'filename' => 'modSystemSetting/614ec8ab090b0eb18eb7df16c5ea0933.vehicle',
      'namespace' => 'patternlab',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa5e99f3f94cedc5ef2f65443c18568d',
      'native_key' => 'patternlab.fb_select_dropdown_id',
      'filename' => 'modSystemSetting/538162941ab8cad6c8850bc8f07b490a.vehicle',
      'namespace' => 'patternlab',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b833db5d32fc9e75867bae91179da39',
      'native_key' => 'patternlab.fb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/135d578f0496f48a720cf0e81bc46e83.vehicle',
      'namespace' => 'patternlab',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22ec0cd3819583397509fe17a9b9b59a',
      'native_key' => 'patternlab.fb_accept_terms_id',
      'filename' => 'modSystemSetting/2ec5d19f15bed65c2160c62c5100013a.vehicle',
      'namespace' => 'patternlab',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ebe6d4f8ff12f03223333ec9ebe7ad6',
      'native_key' => 'patternlab.global_backgrounds_id',
      'filename' => 'modSystemSetting/6245844b28e5b9d39560a4f3ccd8dd71.vehicle',
      'namespace' => 'patternlab',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '632ca32c4004180a6175996c8353a356',
      'native_key' => 'patternlab.news_container_id',
      'filename' => 'modSystemSetting/4a84dd5863b782e4cf5ad21cc1c6f873.vehicle',
      'namespace' => 'patternlab',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6822049c4ff41a034431a0dcf70eed27',
      'native_key' => 'patternlab.team_container_id',
      'filename' => 'modSystemSetting/130e7aec58cdcf1d3ccf92ac0a067d96.vehicle',
      'namespace' => 'patternlab',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c65b6d469afeb970687a479f966c132f',
      'native_key' => 'patternlab.testimonial_container_id',
      'filename' => 'modSystemSetting/143d7e6cf6ed299dd41cf4e852cd897c.vehicle',
      'namespace' => 'patternlab',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '05a734eb2ba0ac05c5220e5b92d7919e',
      'native_key' => NULL,
      'filename' => 'modCategory/7545d289d6c5513ee887fceee7f17ee8.vehicle',
      'namespace' => 'patternlab',
    ),
  ),
);