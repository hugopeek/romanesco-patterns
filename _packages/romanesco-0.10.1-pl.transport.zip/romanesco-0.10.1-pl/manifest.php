<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

## Romanesco 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5069f50e6d69f0b712d3a194c0b05338',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/b7fbe3bdc5141a3b88c5ba780c8c987f.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a665d4bf20540184d19b140ee86a2dcd',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/6f5efe47fd88acccf6b4c33ef29cb3aa.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0eed6dea49182ebc63ad3bbcf1b0449e',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/82dea88d7b28eff20e500c81bcbe5925.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d230e47842c268b66ea2f4afd0cc492',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/c61ae951e4293131a9ee9d897ab294f0.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a097503e6139d9c4a84a745df7648a6a',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/b93327883b2a0c8480c395949ab264f7.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '440d36004b7b8da2f3c7fcdad0346dde',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/57091edda7338f359ccad4101452b203.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd71b9fa5cdd3cab2163b3c32db686e2b',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/8bd08afe5977f3ef555aa6be71ad1c4e.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '575acebd6aa7aafe9a9ac0ea7aa7fe75',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/2937d5cb218ff8e241e78d2b005be145.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1606b5d8e8b92a594ae64929c30d82c7',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/e6f8097b42efdab37e846497ec3120fb.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12bf55b7484a9210898994236505b45c',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/92a15e57f7e98a4fa8ad85d552851a77.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f138f8a1a3b17eeb18c01801bc6f6a18',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/e59b690d0fb4dde2a9ebb1125372facc.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0e96cd53896a05207cf9c05cd61e9bd',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/0e13b6492690ff8ef9b5e44473cc9c84.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f1667a3895427be983200e96b6afa4a',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/fda260022e59d26e394a82f0bfe287ab.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be5070fd4383594e5d1fe3028bb6dc9e',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/d09b259aaf9191f0020a5de01f4b38e0.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae13297708f64cc5361732285cd48cf9',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/ee1bc284862a1bb72e2578d020d1774e.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6870ba5732620f7b2bc94f86b98758a3',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/70b909475ed031dcf3533b23f9d191fd.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34c65cad31dbc49aabb289a72249f5d9',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/97246fa146c08e34147a48fc1784286b.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f326cd55ca4dd209902d5e713fa2b7d',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/f50f259d99cb8cbfe43a01ca85d88ece.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72957aa7dd80d8f5693aebc669f6d1e7',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/387407f15abdb8c40ea5d7f6c00f98dc.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '917b84e2f180ff5f89cb2767e108766f',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/4a15deaae4a578ce5483f3bcae30cc31.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f95570d0b1b36508a919ba2b6479ca28',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/e29c9ecb6815282b6b9312a9a7425155.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f38f6dfa9fa76dcbd611ca0b6d56b6e1',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/a7d008fae94a15f051b418e6fd191312.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6499efc015661f73bb14828f9034efb8',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/5271819e436c49389f6563a63ffb6f45.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '880c9a69e3a9641aec0576b3890ab3a8',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/39e14077b7abac4e6023e64caa47d8b0.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d06684c17f29911e411365c657cb0f1',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/654a18c96cd66e1a70cb7bfd4cb084e7.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '838ab0f20f431a841cb0f97793088007',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/9c2cef21fdf75be6fc6ac12dece8d4ec.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a8c7494b62819ede0728b4a00249b1e',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/58a4d044ea111d77e6292e0169057a4c.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e0d8a6b25fa9f3513fca584cb6a81b5',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/e471c9421382d4f7a7752b78c8e6247c.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66989fc3f5bf299cdd39499fdea66bdd',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/3bc6e82dbe1527355ba07d625e11ec79.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71455b70674452385c99e60d09fd67fe',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/606bd9ec0ed8ddfa4edb87d73e3f8cad.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '831936f7da9e608d014c6e35560b7f08',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/bfb7e3737bbd0133ffba30261e4ff700.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81f6178e5f3145b40c442f0d9d9e5a6e',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/8655342206f0f04dd8cddbc11ba1d4dd.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1123f81d324970c89743ffb7a8bbf97f',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/17abd9656321120678c80c5bc8489b06.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4690f8df0849816fdb57147b1bf42dc',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/604e63813840646930bee2bad3c97085.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad06d5c79befa7621571dec8a207108c',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/bc80ba56b774fc270fab8b1e89d6be25.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '882c2f4d504b2a73ed3dc51c3478cea8',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/a0de12e2730de0f67b806af5664d99b7.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab9eb625993141c044370e423678dcb9',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/333123deb092ff1be5932cec2dc6ff7d.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1e4f41741f5b650f08bb91124646ed74',
      'native_key' => NULL,
      'filename' => 'modCategory/d3a3bee5737194b78726e3277d534fb6.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);