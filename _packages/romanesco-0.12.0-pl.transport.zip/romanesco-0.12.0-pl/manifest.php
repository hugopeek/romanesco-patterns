<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line

---

## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)

---

## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template

---

## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML

---

## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews

---

## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements

---

## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions

---

## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library

---

## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting

---

## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab

---

## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes

---

## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder

---

## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor

---

## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates

---

## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e42c866c23afa877ddd85ee17cbc4cdb',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/2d6fd5f01c212e925bb2ce2b50462e97.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c68cd65e048986ded3d714fb0181e7f3',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/6b2200458dcdfa00289e0fecf733c33f.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8acf8d13137fb2a6334b9099b467d181',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/e0c888d1f31a5e82571d8409d78464c3.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f2fa50e41426d0a9b96fb70165764a',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/dc26e6a1f2f9f51f265ecdb65d53c6db.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cdc4edd32a98c99a479c47fe55055f5',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/ae5d0a42fc734c30c4909ba1e72f1202.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0c389bb55ae070b447f934a85c7dbd8',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/48eedd8e048049aa40f635194e2dfabb.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c5822ed47e8d8f988cba1b614002748',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/08350fa75cc7071bde28dfc4a2fbcb41.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c2d877382594dea22f72c0ecc4d9a5f',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/bd94654877b8eace288b805724c8d6fb.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4635bb27a140b8aaad81180bd98347f',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/daaf71fbc2a7ae880ff130ecf6801542.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50eb885bf298e8d69caa724137333eb1',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/198e318a53562e6e8906a87d4454868a.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68d181b9e4a6099256a7b17ec772977',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/247b69bc7f2c5c098abd3f941e713741.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19a74e843c75e9ff477e75285d430fd8',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/7ec7dd67ee5707ef1f18004e29c8f095.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf31e2bfe7bdadba1e0ca8b7f45e5b8',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/efcce7196cc7f40bc21e1f224b453781.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0a0d245bbab5735c0cc370a1082cb71',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/158ff4ae702cffd3a1cdf84d179df5c4.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b8cb5ce616489be31b6f1b36062f2af',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/54537f548fab6806ee7fa6adcc01c90a.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e10665b15c5564c33dca54d4196ec602',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/f1a48c7fbdc30d9749afa18ad1017526.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b27f515d03b01e934c59aa3168fc67b',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/5ffa1371add33c25f86bc5819c64b85f.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '352b14ecfa806457d7db2a89a2acf5cf',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/e2d9826e2147dd58209207f0e8396c36.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b66eb440a5bc87112cd22a09064c0ea',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/308d80e4d16f4df9f2317264aceff658.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c57e0607c43075c8cd42af3e411be25',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/d22348a0c7dee354b7cd42cfeb84b495.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96d26b83b9473ab3b5e27951d556a07b',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/ac06ecd84da874eea80f59b2ed16dfa4.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91ed44f40db0bf2f4b6e812ca9845171',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/b1ae58c317e972adbc51f0bd254fdccb.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6295b89a29a42142a0d53df8197633ee',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/034b83439d2617b4ac7044ea92a37951.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f33ce10987565f128d9233077e1cdc',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/f3dc30bd60c0f1a18afa54dbbafdfacc.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f511576b8508f456711b8e5f14ef9f2b',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/951857eecdcf5756a964f2501c2a3825.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99d2ffbc5a67710164a33c6524dad9f4',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/5ecadf71250bb09cdd6891e2912739c2.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b1cc26c0d69ccfe61e06982883256f4',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/7c46d238cc63c4819c8f78c955236bdf.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c50b8d476ec8f3b27a0699caf240fb8',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/9de41832451f576ee3e965382aa318c6.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9764ee4c8951207361103f47906ac20',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/b4e55fd13a22e93ae82abf0d380d09b4.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f73aebe9c2a9059796f283bd3202fda6',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/265956f8a80f3aaf2e3d8ef7be94a334.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c7ca89deffa1190a8359de74ef677b7',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/19fa15706c21910765d893003d27a96c.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5834534209ab5c09db18741845f5c9f',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/70f8065c31207a23ac64e9472fee61e4.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '481c56949223bce1bd20b267dd9b2eb0',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/5f5e5b53a19ca8e68a7d8e15237e9f49.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b795ccc87121e910518711952d1ab10',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/82e383d92250753910f6e423b755ccaa.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03818eccc180972825230e0780d530dd',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/89a2e9d5daee59e217d3018bc0b5261d.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99870bdc9dce45cbc30f9e8b9a93599b',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/2d50c954ceddc5e8f5dcce7277679120.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb3cbf81aa0c8740b1c9c865ca88b19',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/636fccaf1cc3df54e31b37ff17b96577.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4126972249944e47c952af2ab5f85d43',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/1a54e837081f441f37a6aefd2dcf672b.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d7b7b9f1c52c038fbb5713787a0cee9',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/77be94df3e0e099a9f584db41cdffc07.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ea22c69b20dbfeb82f40363d57be185',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/a6ca505c7126d274996a19f87ac95205.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a8a27cea5cc398cb98da9219d105848',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/922be5983bd298319fdfd1600957d465.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e146d17d181fd5084af5716d2bad8070',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/5effcf5e10570c6129035df01bdbaad2.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85f3fd6c27050d675e4e8ebf0e8b3bd4',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/ecdda619ff28b43b629ece3a097464fe.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8c84ca9c11679356e9c9428b60f0d671',
      'native_key' => NULL,
      'filename' => 'modCategory/12c17dcec1f532b1e604a6059fb3e238.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);