<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for the Romanesco pattern library

## Romanesco Patterns 0.14.0
Released on January 17, 2019

New features:
- Add main navigation with dropdown submenus
- Add template with Table of Contents menu (instead of submenu)
- Add template for Downloads
- Add Kanban layout for Content Purpose elements

Fixes and improvements:
- Update status grid to incorporate new / altered TV values
- Add optional anti-spam hook to forms
- Add option to select background for rich text segments too


## Romanesco Patterns 0.13.0
Released on November 15, 2018

New features:
- Add content purpose TVs
- Add TVs for external links, file attachments and related content
- Add ability to create input options
- Add ability to create crosslinks between resources
- Add re-purpose component, for creating content "flows" inside a central topic
- Add after save hooks for MIGXdb configs
- Add JSON import for input options

Fixes and improvements:
- Add chunk for dynamically generating TV input options from database rows
- Load project timeline through Backyard package and store data in db
- Rearrange TV categories and add rank
- Replace Grunt task for generating GPM config with PHP script
- Make tvToJSON output suitable for use in GPM configs
- Disable CSS background images for Tiled overviews
- Fix sidebar not showing on largest screen on Team and Client pages
- Fix link in Instagram social button


## Romanesco Patterns 0.12.3
Released on October 4, 2018

New features:
- Add OpenGraph metadata to head
- Add snippet for clipping characters from start or end of string
- Add plugin for injecting inverted classes into content (requires HtmlPageDom)
- Add options for controlling footer and bottom CTA content

Fixes and improvements:
- Include homepage in basic template list, so they also have Overview TVs
- Fix author image in compact article overview template
- Disable Disqus comment count in overviews (was acting buggy)
- Prevent decimals in calculated image dimensions from breaking variables file
- Allow overrides for head and footer chunks in all templates
- Fix issues when using multiple file upload fields in form
- Sort available forms by menuindex in Forms CB


## Romanesco Patterns 0.12.2
Released on September 18, 2018

Fixes and improvements:
- Add option to wrap CTAs in segment
- Add size and layout_type settings to Quote CB
- Add titles to button links
- Always set first value in form dropdown as empty default option
- Change CB message size setting to generic field size and use for Quote
- Add inverted layout type to Accordions
- Fix empty subtitles returning as NULL in Tab headers
- Fix fallback image in publication overviews
- Better explanation for Label position setting in forms
- Remove hideEmptyTVCategories plugin (hidden by default in MODX 2.6)


## Romanesco Patterns 0.12.1
Released on July 27, 2018

New features:
- Add registration form template to FormBlocks
- Allow resource / member groups with exclusive access rights to be added
- Exclude members only submenu items in vertical nav and KB overviews

Fixes and improvements:
- Shorten element descriptions to 191 characters (this changed in MODX 2.6)
- Disable raw code tag in pattern examples (this broke in MODX 2.6)
- Add Github to social buttons (and some other small tweaks)
- Add setting to make project hub private (requires Login)
- Load Google Analytics if configuration / context setting is set
- Fix object not found handling in latest plugins
- Fix snippet not found errors for empty fastField tags in MODX 2.6
- Regulate MIME type of Markdown resources with plugin


## Romanesco Patterns 0.12.0
Released on June 6, 2018

New features:
- Add elements for creating a Knowledge Base
- Add option to disable page header
- Add option to disable or override toolbar


## Romanesco Patterns 0.11.3
Released on January 16, 2018

New features:
- Add UpdateStyling plugin to change styling theme from config settings
- Add getImageDimensions snippet to retrieve width and height from image files
- Add splitString snippet to divide output or placeholder into multiple sections

Fixes and improvements:
- Enable editor to add custom (pre)hooks to FormBlocks forms
- Add option to set form layout in Form CB itself
- Mute strange and elusive ImagePlus output line


## Romanesco Patterns 0.11.2
Released on December 20, 2017

New features:
- Add Cards CBs for presenting content inside a set of cards
- Add functionality to automatically reduce Tabs to Accordions on mobile

Fixes and improvements:
- Enable theme overrides for setBoxType snippet
- Add option to manually assign an ID to a Maps CB
- Add IDs to first level CB layouts for better targeting
- Allow smaller profile pictures of persons and organizations
- Add option to select tags to form selection fields
- Add more display variations to Tabs organism
- Add option to select Tab menu position (top, right, bottom or left)
- Add option to select Tab menu heading level (h2,h3,h4,h5,h6,span)


## Romanesco Patterns 0.11.1
Released on July 25, 2017

New features:
- [ContentBlocks] Add CB field for displaying map with marker
- [FormBlocks] Add snippets for creating repeating input fields

Fixes and improvements:
- Add ability to use an SVG as global background
- Replace popup class with tooltip to avoid collisions [#82]
- [FormBlocks] Add ability to use alternate option value in HTML
- [FormBlocks] Add ability to choose help text position (above or below input)
- [FormBlocks] Add ability to force fieldset to always display as segment
- Add numeric operator to modifiedIf
- Add outputAsTpl option to modifiedIf (for using then/else value as chunk)
- Fix null result not actually returning false in getContextSetting [#83]
- Fix TV output options being reset to default on GPM build [#80]
- [FormBlocks] Prevent form submission failing when cb_input_file_id is empty
- Configure grid settings for all Overviews with setBoxType snippet [#79]
- Add id to HTML tag with context_key
- Add inner container to all segments inside ArticleTraditional template


## Romanesco Patterns 0.11.0
Released on April 30, 2017

New features:
- Add CB layout + field for wrapping content in Semantic UI segments
- [FormBlocks] Add multiple file upload field

Fixes and improvements:
- Responsive images through srcset and sizes attributes
- Cache each Overview type in its own custom cache partition
- Add icon size and de-emphasize options to Icon SVG
- Refactor gallery / slider combo and add captions
- Prevent collisions between Tab and regular segment types
- Add ability to override Google Analytics tracking code per context
- Add submenus to HeaderVertical navigation
- Add CTAs in HeaderVertical templates through hero unit in header
- Add more aliases for custom templates (for assigning TVs with GPM)
- Add fallbacks to placeholders inside some patterns
- Correct field types and descriptions of some information electrons
- Start adding descriptions to all elements
- [FormBlocks] Add ability to set dynamic redirect ID
- [FormBlocks] Add row template for auto-generated select options
- [FormBlocks] Combine Select Dropdown and Select Options fields
- [FormBlocks] Fix Other and Collapsible fields
- [FormBlocks] Use fieldset / legend markup again in HTML


## Romanesco Patterns 0.10.6
Released on February 22, 2017

New features:
- Add template and patterns for displaying header vertically

Fixes and improvements:
- Improve footer layout on mobile
- Improve structure of Backyard information segments
- Allow image type to be controlled by a setting in Overviews


## Romanesco Patterns 0.10.5
Released on January 26, 2017

New features:
- Add system setting for specifying Project Dashboard resource ID
- Add system setting for specifying Pattern Library container ID
- Add firstChildID snippet for fetching... the first child ID

Fixes and improvements:
- Refactor Button CB to incorporate icon buttons [BC]
- Fix first key not being rendered by jsonToHTML snippet
- Include extension when searching for matching pattern URIs
- Rename / re-purpose ProjectHub template to ProjectDashboard
- Minor tweaks and fixes to Hub elements


## Romanesco Patterns 0.10.4
Released on January 12, 2017

Fixes and improvements:
- Add scripts for included/referring Bosons (ContentBlocks)
- Optimize existing included/referring snippets for more accurate results
- Use prefixes in all included/referring snippets to avoid collisions


## Romanesco Patterns 0.10.3
Internal build only

New features:
- Add option to show an icon inside buttons and tags
- Ability to add anchors inside basic headers
- Add basic styling variant to Tabs CBs

Fixes and improvements:
- Add specific CB layout for patterns in front-end library


## Romanesco Patterns 0.10.2
Released on November 23, 2016

New features:
- Add tools for listing included and referring patterns in front-end library

Fixes and improvements:
- Combine Accordion and Tabs CBs
- Rearrange some electrons in new Connections category
- Hide empty TV categories after moving TVs with FC
- Fix broken path in fbLoadAssets snippet
- Fix broken prism.js code highlighting


## Romanesco Patterns 0.10.1
Released on November 6, 2016

Fixes and improvements:
- Remove remaining TV prefixes from overview tpls
- Change prefixes in main Atomic category names
- Move Status TV\'s to separate tab


## Romanesco Patterns 0.10.0
Released on October 19, 2016

New features:
- Add option to divide CB layout columns
- Add template to view Testimonials as logo
- Add justified alignment setting to CB field options
- Add alignment setting to heading chunk

Fixes and improvements:
- Split PatternLab package into Romanesco Patterns and Backyard [BC]
- Change prefix of FormBlocks system settings [BC]
- Change / fix all paths related to old PatternLab package [BC]
- Name changes to improve overall logic [BC]
- Fix nested layout grids in detail templates receiving incorrect margins
- Fix TV names in Person and Article overviews
- Fix caching of nested chunks in Testimonial overviews
- Fix common pages menu in footer
- Remove auto-calculated height from gallery image thumbnails
- Remove / refactor parts that where too project-specific
- Add ID to hero container, to allow for more accurate targeting in CSS
- Add some missing class names
- Various other minor fixes


## Romanesco Patterns 0.9.1
Released on June 28, 2016

New features:
- Add Slider / Gallery combo CB

Fixes and improvements:
- Organize front-end dependencies in assets/vendor folder


## Romanesco Patterns 0.9.0
Released on June 22, 2016

New features:
- Add front-end pattern library
- Add templates for Team and Testimonial
- Add templates for Clients and Portfolio

Fixes and improvements:
- Refactor overview elements for better reusability [BREAKING CHANGES]
- Load FormBlocks fieldset layout with chunk
- Display syntax highlighted code snippets with Prism.js
- Fix layout backgrounds not working on subdomains
- Fix adding tables and links with Redactor


## Romanesco Patterns 0.8.1
Released on May 5, 2016

New features:
- Add status grid for keeping track of progress per page

Fixes and improvements:
- Use snippets in JSON config files for assigning templates


## Romanesco Patterns 0.8.0
Released on May 5, 2016

New features:
- Add content blocks for arranging content in tabs
- Add Twitter content block

Fixes and improvements:
- Add changelog
- Add symlink for backgrounds.css to web context
- Flexible sidebar width on CB layouts containing a sidebar
- Assign categories to CB elements
- Fix header image and title inheritance
- Fix broken image sliders
- Update jQuery to 2.1.4 and add local fallback for CDN',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cccc7a7586c8117e794db82ed35e7c29',
      'native_key' => 'romanesco',
      'filename' => 'modNamespace/05b927f8dff7848929a5d2c39c67735d.vehicle',
      'namespace' => 'romanesco',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef96013dec7910ed8dec41854a015ed6',
      'native_key' => 'romanesco.semantic_dist_path',
      'filename' => 'modSystemSetting/4488cb9d90c291b61ac8c9eac5805b13.vehicle',
      'namespace' => 'romanesco',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '317de0a5b56d6cb0b04d89db6e3f3e75',
      'native_key' => 'romanesco.custom_css_path',
      'filename' => 'modSystemSetting/a3421deccae7634c5633cd1f7e71e91e.vehicle',
      'namespace' => 'romanesco',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6de275399c44f2e773c5ec46f0ba1e55',
      'native_key' => 'romanesco.custom_js_path',
      'filename' => 'modSystemSetting/891e7d1530ee1622575795a684ac4af2.vehicle',
      'namespace' => 'romanesco',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '875fd9637338a81ac60cc14d8e9c8256',
      'native_key' => 'romanesco.custom_vendor_path',
      'filename' => 'modSystemSetting/45b6d9dd46a0a35b7b302fd17671082c.vehicle',
      'namespace' => 'romanesco',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c06472346f862318048bcc98e40c112',
      'native_key' => 'romanesco.date_format_short',
      'filename' => 'modSystemSetting/3b2948267efad860e82ab47a8dab70b8.vehicle',
      'namespace' => 'romanesco',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b6951d77fbc45f0ca2d531f8dcee865',
      'native_key' => 'romanesco.date_format_medium',
      'filename' => 'modSystemSetting/e340b1ab2d204a21c88c987a305deecc.vehicle',
      'namespace' => 'romanesco',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db9f4ba8cee84391ee40d40f357208e0',
      'native_key' => 'romanesco.date_format_long',
      'filename' => 'modSystemSetting/bc4b29d4094a784c5383e24dcad43b8a.vehicle',
      'namespace' => 'romanesco',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10744add864300fb0e340a706f688d1e',
      'native_key' => 'romanesco.date_format_full',
      'filename' => 'modSystemSetting/744ddcf84cb096449d9720659194f895.vehicle',
      'namespace' => 'romanesco',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc3a620d8865079228396227b687b303',
      'native_key' => 'romanesco.dev_mode',
      'filename' => 'modSystemSetting/1246ab9005ca65aa96561f326f21c1bd.vehicle',
      'namespace' => 'romanesco',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c7debcb7d381851119f9c71b3aa60e3',
      'native_key' => 'romanesco.global_backgrounds_id',
      'filename' => 'modSystemSetting/f33424e26d3d5f6efbf51d898b61ea4e.vehicle',
      'namespace' => 'romanesco',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bb1213bf2d350e291a43c96b4190c13',
      'native_key' => 'romanesco.global_footer_id',
      'filename' => 'modSystemSetting/3f373b4c7d2a0f581c0cc5814be77ae0.vehicle',
      'namespace' => 'romanesco',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cdf9ca2e874b71bd4c889cc0878c677',
      'native_key' => 'romanesco.dashboard_id',
      'filename' => 'modSystemSetting/c8eb7793517f5ac70d9693bd3e1b6280.vehicle',
      'namespace' => 'romanesco',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c94d62dd96be79c3c9833989155c871',
      'native_key' => 'romanesco.pattern_container_id',
      'filename' => 'modSystemSetting/1aeb22250c285129444715f94692e28f.vehicle',
      'namespace' => 'romanesco',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c41ca051d094fba53667ad315ca9328',
      'native_key' => 'romanesco.backyard_container_id',
      'filename' => 'modSystemSetting/4962e073382068b9b9999e2d63800674.vehicle',
      'namespace' => 'romanesco',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11b7576c149104917da08fd35444da43',
      'native_key' => 'romanesco.private_backyard',
      'filename' => 'modSystemSetting/cd1723bae22af1f1dea7fd2566b4fd12.vehicle',
      'namespace' => 'romanesco',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8cb6aa912a2fafb4c54d070f2875815',
      'native_key' => 'romanesco.mapbox_access_token',
      'filename' => 'modSystemSetting/0784a3e2a4fb610defcf16ad2e5f6444.vehicle',
      'namespace' => 'romanesco',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cd7776b62473ef77b6fb47814f8c56d',
      'native_key' => 'romanesco.publication_container_id',
      'filename' => 'modSystemSetting/f25f110b77d33669435e388ce2816612.vehicle',
      'namespace' => 'romanesco',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '144bf396845ffe9c531d1680ccf7cc4e',
      'native_key' => 'romanesco.team_container_id',
      'filename' => 'modSystemSetting/71a36cd3688eb665009bd409c29758a0.vehicle',
      'namespace' => 'romanesco',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb7263f0daeeea47f511d1b34eadb027',
      'native_key' => 'romanesco.testimonial_container_id',
      'filename' => 'modSystemSetting/383b6daac0f75043fb1189c5d97bd9ee.vehicle',
      'namespace' => 'romanesco',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99ac4b2b541e68914e06aba8e2b9c22f',
      'native_key' => 'romanesco.portfolio_container_id',
      'filename' => 'modSystemSetting/112b5c1916aac78c7c1b5de787b007c8.vehicle',
      'namespace' => 'romanesco',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55434097d3cd2935d03200fc3275e938',
      'native_key' => 'romanesco.client_container_id',
      'filename' => 'modSystemSetting/eaf7574fc9f5bab2d09333615c947146.vehicle',
      'namespace' => 'romanesco',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '526e98469b43e930c76db4a1c772c61a',
      'native_key' => 'romanesco.favicon_version',
      'filename' => 'modSystemSetting/3a34a48e4ff2a8fa4e2695119d2b2a9e.vehicle',
      'namespace' => 'romanesco',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '675f37fae6e16ec1a3653465cd534cdc',
      'native_key' => 'romanesco.search_add_to_menu',
      'filename' => 'modSystemSetting/1149fae7f2eeed1ae6b0acb928c53f52.vehicle',
      'namespace' => 'romanesco',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '899d60ac42d3603082cc38b37bfb22d6',
      'native_key' => 'romanesco.search_result_id',
      'filename' => 'modSystemSetting/4c3fb8b662eded3fdbf96a89906a6364.vehicle',
      'namespace' => 'romanesco',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41bb2dd6f05a7f9e770645e9b0c99aaa',
      'native_key' => 'romanesco.search_result_limit',
      'filename' => 'modSystemSetting/2401e7ab925b73daeee2f736f65e29e6.vehicle',
      'namespace' => 'romanesco',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99120612c1cf5eb9bcd2c8500258aa00',
      'native_key' => 'romanesco.social_twitter',
      'filename' => 'modSystemSetting/6666162681e224f7c9e85bd2a0f25aaf.vehicle',
      'namespace' => 'romanesco',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c98b1416d739f04c0dfbf6df0b18c169',
      'native_key' => 'romanesco.twitter_consumer_key',
      'filename' => 'modSystemSetting/cf65efa1212c97861f5416128703cd61.vehicle',
      'namespace' => 'romanesco',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f554e8fb98c70f538c9ac7419dadb006',
      'native_key' => 'romanesco.twitter_consumer_secret',
      'filename' => 'modSystemSetting/51759536b9d3352d49fc417f3b646cdc.vehicle',
      'namespace' => 'romanesco',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfddb1149e3b13a52eccc04b40c993d6',
      'native_key' => 'romanesco.twitter_access_token',
      'filename' => 'modSystemSetting/654a9edd339e255c953442b7b002e150.vehicle',
      'namespace' => 'romanesco',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f1d0d068ab6e1b2aeab380571f71214',
      'native_key' => 'romanesco.twitter_access_token_secret',
      'filename' => 'modSystemSetting/501c2e5fa4ddac42bcbc83d5820c3311.vehicle',
      'namespace' => 'romanesco',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e447cc3ce5138ed75361abed11efcb4',
      'native_key' => 'romanesco.member_groups_frontend',
      'filename' => 'modSystemSetting/a01b0026696be77b2df3b66c2b17e48e.vehicle',
      'namespace' => 'romanesco',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ba31ef0fc98141c3b43ab3ec4d683e5',
      'native_key' => 'romanesco.member_groups',
      'filename' => 'modSystemSetting/7d74a73e3720e55f684089efe7b84225.vehicle',
      'namespace' => 'romanesco',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7c32697a34277f9a2a7ab41938fb2bf',
      'native_key' => 'romanesco.cb_field_code_id',
      'filename' => 'modSystemSetting/3e28ee65c62b0df30e224e7f78af6ef2.vehicle',
      'namespace' => 'romanesco',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e4294c1c93b4a3b1d9753d59f7da377',
      'native_key' => 'romanesco.cta_container_id',
      'filename' => 'modSystemSetting/931d2e6dd5a5115dccd60f82062970c7.vehicle',
      'namespace' => 'romanesco',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8a9627dd76c20e1f17c1a567fb4d542',
      'native_key' => 'romanesco.footer_container_id',
      'filename' => 'modSystemSetting/06f13c34afd2fba12b6193845524f0bb.vehicle',
      'namespace' => 'romanesco',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e15a3b90c22d7555b3f93bb4edcd0f9',
      'native_key' => 'formblocks.container_id',
      'filename' => 'modSystemSetting/2c961e5abed77e1b057145dc756830ff.vehicle',
      'namespace' => 'romanesco',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58c0f6d68d5bdd6b9d387451ccbaf23f',
      'native_key' => 'formblocks.save_form',
      'filename' => 'modSystemSetting/83e48bfd493f3e626b6f2cb6e0c222bb.vehicle',
      'namespace' => 'romanesco',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbc19d9fb427a7d1cc6e36d45f3aadb4',
      'native_key' => 'formblocks.antispam',
      'filename' => 'modSystemSetting/81f604fdbb0790942e691b03f868970d.vehicle',
      'namespace' => 'romanesco',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c79e89d6db7d0f270c9a4231bb0c7b7b',
      'native_key' => 'formblocks.cb_input_textfield_id',
      'filename' => 'modSystemSetting/8c6d2501ffdc411f4f2a6582fc566b32.vehicle',
      'namespace' => 'romanesco',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eafb770cca514b22c8792f35188a6c2c',
      'native_key' => 'formblocks.cb_input_textarea_id',
      'filename' => 'modSystemSetting/9ba1e5c4004eb8a5528f3edd702e9fb5.vehicle',
      'namespace' => 'romanesco',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9409e7fd92a5018a99f3f3b311583673',
      'native_key' => 'formblocks.cb_input_email_id',
      'filename' => 'modSystemSetting/56e19800a9958ed177308b23c976f39a.vehicle',
      'namespace' => 'romanesco',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68a09b55546db18d97e4dd39e81e9756',
      'native_key' => 'formblocks.cb_select_option_id',
      'filename' => 'modSystemSetting/8e99df1c80c1f97fc82fac1ad2399fa1.vehicle',
      'namespace' => 'romanesco',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a777e8e3c1a53f13ba6a1560652d48e6',
      'native_key' => 'formblocks.cb_select_option_collapse_id',
      'filename' => 'modSystemSetting/3ea2adfa96ef0a16ae11797fdc0d1b32.vehicle',
      'namespace' => 'romanesco',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7763ebb44a7c92e6e5b8b62d51f1f39d',
      'native_key' => 'formblocks.cb_select_dropdown_id',
      'filename' => 'modSystemSetting/fb9d76740001b8490ef08165e8067a13.vehicle',
      'namespace' => 'romanesco',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '805c6770e323e2521542c9dbad8040d9',
      'native_key' => 'formblocks.cb_select_dropdown_auto_id',
      'filename' => 'modSystemSetting/b66a96fa3128554e9b44ef14a698a6df.vehicle',
      'namespace' => 'romanesco',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0908cd02749e8a637e210df24c6b6800',
      'native_key' => 'formblocks.cb_input_file_id',
      'filename' => 'modSystemSetting/b6ffa7012f18ece3a440148071bbd8c2.vehicle',
      'namespace' => 'romanesco',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e5d7b5f1882161ced53ec9ee61972f2',
      'native_key' => 'formblocks.cb_accept_terms_id',
      'filename' => 'modSystemSetting/430f664dd51f1b1c2a7ed3217700ae26.vehicle',
      'namespace' => 'romanesco',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9d19d3001faf3e1cc6c5ad810b00c457',
      'native_key' => NULL,
      'filename' => 'modCategory/440f4b5c116c55004d9e6cf8ced53c6a.vehicle',
      'namespace' => 'romanesco',
    ),
  ),
);